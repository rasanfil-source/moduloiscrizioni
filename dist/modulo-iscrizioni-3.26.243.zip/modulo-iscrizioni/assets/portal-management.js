(() => {
  const registrationSortOptions=[['name','Cognome','A–Z'],['created_at','Data iscrizione','Più recenti prima']];
  const registrationSortStorageKey='mi-registration-sort';
  const readRegistrationSort=()=>{try{const value=localStorage.getItem(registrationSortStorageKey);return registrationSortOptions.some(option=>option[0]===value)?value:'created_at';}catch(error){return 'created_at';}};
  const saveRegistrationSort=value=>{try{localStorage.setItem(registrationSortStorageKey,value);}catch(error){/* La scelta resta valida per la sessione corrente. */}};
  function applyAttendanceSort(context,available){
    const enabled=!!available;
    if(context.attendanceAvailable!==enabled&&(enabled||context.attendanceAvailable===true)){
      context.sort=enabled?'name':readRegistrationSort();
      context.direction=context.sort==='created_at'?'desc':'asc';
      context.shown=30;
    }
    context.attendanceAvailable=enabled;
  }
  function registrationSortMenu(current,onChange){
    const menu=document.createElement('details');menu.className='mi-registration-sort';menu.dataset.orderMenu='';
    menu.innerHTML='<summary>Ordina <span aria-hidden="true">▾</span></summary><div class="mi-registration-sort-options">'+registrationSortOptions.map(([key,label,hint])=>'<button type="button" data-order-choice="'+key+'" aria-pressed="false"><span>'+label+'</span><small>'+hint+'</small></button>').join('')+'</div>';
    menu.sync=key=>{menu.querySelectorAll('[data-order-choice]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.orderChoice===key)));menu.querySelector('summary').title='Ordina: '+(registrationSortOptions.find(option=>option[0]===key)?.[1]||'Personalizzato');};
    menu.sync(current);
    menu.addEventListener('click',e=>{const choice=e.target.closest('[data-order-choice]');if(!choice)return;menu.sync(choice.dataset.orderChoice);menu.open=false;menu.querySelector('summary').focus();onChange(choice.dataset.orderChoice);});
    menu.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();menu.open=false;menu.querySelector('summary').focus();}});
    return menu;
  }
  document.addEventListener('click',e=>document.querySelectorAll('[data-order-menu][open]').forEach(menu=>{if(!menu.contains(e.target))menu.open=false;}));
  // Minimal OOXML workbook, packaged locally as a standard uncompressed ZIP.
  // Il testo viene impostato esplicitamente: i numeri conservano gli zeri iniziali e il foglio non interpreta il valore come formula.
  function reportWorkbook(rows) {
    if(!rows.length||rows.length>1048576||rows.reduce((n,r)=>Math.max(n,r.length),0)>16384)throw new Error('Il rapporto supera i limiti Excel.');
    const xml=v=>String(v??'').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\ufffe\uffff]/g,'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
    const column=n=>{let s='';for(n++;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;};
    const width=rows[0].length,end=column(width-1)+rows.length;
    const sheet='<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><dimension ref="A1:'+end+'"/><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>'+rows[0].map((_,i)=>'<col min="'+(i+1)+'" max="'+(i+1)+'" width="24" customWidth="1"/>').join('')+'</cols><sheetData>'+rows.map((row,r)=>'<row r="'+(r+1)+'">'+row.map((v,c)=>{const ref=column(c)+(r+1),style=r===0?1:0;if(typeof v==='number'&&Number.isFinite(v))return '<c r="'+ref+'" s="'+style+'"><v>'+v+'</v></c>';if(String(v??'').length>32767)throw new Error('Un dato supera i 32767 caratteri consentiti da Excel.');return '<c r="'+ref+'" s="'+style+'" t="inlineStr"><is><t xml:space="preserve">'+xml(v)+'</t></is></c>';}).join('')+'</row>').join('')+'</sheetData><autoFilter ref="A1:'+end+'"/></worksheet>';
    const files={
      '[Content_Types].xml':'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>',
      '_rels/.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
      'xl/workbook.xml':'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Rapporto partecipanti" sheetId="1" r:id="rId1"/></sheets></workbook>',
      'xl/_rels/workbook.xml.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
      'xl/styles.xml':'<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE8F1FC"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>',
      'xl/worksheets/sheet1.xml':sheet
    };
    const encoder=new TextEncoder(),parts=[],directory=[];let offset=0;
    const header=(size,signature)=>{const bytes=new Uint8Array(size);new DataView(bytes.buffer).setUint32(0,signature,true);return bytes;};
    for(const [name,content] of Object.entries(files)){
      const filename=encoder.encode(name),data=encoder.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'+content);let crc=0xffffffff;
      for(const byte of data){crc^=byte;for(let bit=0;bit<8;bit++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}crc=(crc^0xffffffff)>>>0;
      const local=header(30,0x04034b50),l=new DataView(local.buffer);l.setUint16(4,20,true);l.setUint16(12,33,true);l.setUint32(14,crc,true);l.setUint32(18,data.length,true);l.setUint32(22,data.length,true);l.setUint16(26,filename.length,true);
      const central=header(46,0x02014b50),d=new DataView(central.buffer);d.setUint16(4,20,true);d.setUint16(6,20,true);d.setUint16(14,33,true);d.setUint32(16,crc,true);d.setUint32(20,data.length,true);d.setUint32(24,data.length,true);d.setUint16(28,filename.length,true);d.setUint32(42,offset,true);
      parts.push(local,filename,data);directory.push(central,filename);offset+=local.length+filename.length+data.length;
    }
    const endRecord=header(22,0x06054b50),e=new DataView(endRecord.buffer);e.setUint16(8,6,true);e.setUint16(10,6,true);e.setUint32(12,directory.reduce((n,b)=>n+b.length,0),true);e.setUint32(16,offset,true);
    return new Blob([...parts,...directory,endRecord],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
  }
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const requestId = () => globalThis.crypto?.randomUUID ? globalThis.crypto.randomUUID() : Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
  const personName = person => [person?.last_name,person?.first_name].filter(Boolean).join(' ');
  const downloadExcel=(filename,rows)=>{const url=URL.createObjectURL(reportWorkbook(rows));const link=document.createElement('a');link.href=url;link.download=filename;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
  const depositText=b=>b.deposit_plan?(b.deposit_due===null?'Caparre individuali da verificare':'Caparra prevista '+money(b.deposit_due)+' · Ancora da coprire '+money(b.deposit_missing)+(b.deposit_covered&&(b.balance??b.balance_cents)>0?' · Caparra coperta, saldo da completare':b.deposit_due===0?' · Nessuna caparra richiesta':'')):'';
  const depositDetailText=b=>b.deposit_plan?(b.deposit_due===null?'Caparre individuali da verificare':'Caparra prevista '+money(b.deposit_due)+(b.deposit_covered&&(b.balance??b.balance_cents)>0?' · Caparra coperta, saldo da completare':b.deposit_due===0?' · Nessuna caparra richiesta':'')):'';
  const money = n => (Number(n || 0)/100).toLocaleString('it-IT',{style:'currency',currency:'EUR'});
  const emailContact = email => email ? '<a class="mi-contact-icon" href="mailto:'+esc(email)+'" title="Scrivi a '+esc(email)+'" aria-label="Scrivi a '+esc(email)+'"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 5.5h17v13h-17zM4 6l8 6 8-6"/></svg></a>' : '';
  const phoneContact = phone => phone ? '<a class="mi-contact-icon" href="tel:'+esc(phone).replace(/[^+0-9]/g,'')+'" title="Chiama '+esc(phone)+'" aria-label="Chiama '+esc(phone)+'"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3.5 4.7 5.8c-.7.7-.9 1.8-.5 2.7 2.1 5 5.9 8.8 10.9 10.9.9.4 2 .2 2.7-.5l2.3-2.3-3.5-3.5-2.2 1.5c-1.5-.8-2.8-2.1-3.6-3.6l1.5-2.2z"/></svg></a>' : '';
  const presentDialog=(dialog,previous,done)=>{
    document.body.append(dialog);
    const finish=value=>{dialog.remove();previous?.focus();done(value);};
    if(dialog.showModal){dialog.addEventListener('close',()=>finish(dialog.returnValue||'cancel'),{once:true});dialog.showModal();return;}
    const backdrop=document.createElement('div');backdrop.className='mi-management-confirm-backdrop';backdrop.dataset.miPortalScope='reserved';document.body.insertBefore(backdrop,dialog);
    const hidden=[...document.body.children].filter(element=>element!==dialog&&element!==backdrop).map(element=>({element,aria:element.getAttribute('aria-hidden'),inert:element.inert}));
    hidden.forEach(({element})=>{element.setAttribute('aria-hidden','true');element.inert=true;});
    const restore=value=>{hidden.forEach(({element,aria,inert})=>{if(aria===null)element.removeAttribute('aria-hidden');else element.setAttribute('aria-hidden',aria);element.inert=inert;});backdrop.remove();finish(value);};
    const focusable=()=>[...dialog.querySelectorAll('button:not([disabled]),[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled])')];
    dialog.dataset.miFallbackDialog='';dialog.setAttribute('open','');dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');
    dialog.addEventListener('click',event=>{const button=event.target.closest('button');if(!button)return;event.preventDefault();restore(button.value||'cancel');});
    dialog.addEventListener('submit',event=>{event.preventDefault();restore(event.submitter?.value||'cancel');});
    dialog.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();restore('cancel');return;}if(event.key!=='Tab')return;const items=focusable();if(!items.length)return;const first=items[0],last=items.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}});
    (dialog.querySelector('[autofocus]')||focusable()[0]||dialog).focus();
  };
    async function ask(message,action='Continua') {
      const previous=document.activeElement,dialog=document.createElement('dialog');dialog.className='mi-management-confirm'+(/^(Annulla|Elimina|Rimuovi)/i.test(action)?' mi-management-confirm--danger':'');
    dialog.dataset.miPortalScope='reserved';
    dialog.innerHTML='<form method="dialog" novalidate><h2>Conferma operazione</h2><p></p><button value="cancel" autofocus>Torna indietro</button> <button value="accept"></button></form>';
    dialog.querySelector('p').textContent=message;dialog.querySelector('[value=accept]').textContent=action;
    const title='mi-confirm-'+requestId();dialog.querySelector('h2').id=title;dialog.setAttribute('aria-labelledby',title);
    return new Promise(resolve=>presentDialog(dialog,previous,value=>resolve(value==='accept')));
  }
  // Le conferme sono usate anche dai moduli di eventi e gruppi al di fuori della gestione.
  const confirmingForms = new WeakSet(), approvedForms = new WeakSet();
  document.addEventListener('submit', async event => {
    const form = event.target;
    if (!form.matches('form[data-mi-confirm]')) return;
    if (approvedForms.has(form)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (confirmingForms.has(form)) return;
    confirmingForms.add(form);
    const submitter = event.submitter;
    try {
      if (await ask(form.dataset.miConfirm, submitter?.textContent.trim() || 'Conferma')) {
        approvedForms.add(form);
        try { form.requestSubmit(submitter || undefined); }
        finally { approvedForms.delete(form); }
      }
    } finally { confirmingForms.delete(form); }
  }, true);
  function initGroupAttendance(root) {
    if(root.dataset.ready)return;root.dataset.ready='1';
    async function request(operation,data){
      const response=await fetch(root.dataset.endpoint,{method:'POST',credentials:'same-origin',cache:'no-store',body:new URLSearchParams({action:'mi_portal_management',nonce:root.dataset.nonce,operation,...data})});
      const json=await response.json();if(!response.ok||!json.success)throw new Error(json.data?.message||'Operazione non riuscita.');return json.data;
    }
    const annualButton=root.querySelector('[data-load-annual]');
    if(annualButton)annualButton.onclick=async()=>{
      const annualStatus=root.querySelector('[data-annual-status]'),host=root.querySelector('[data-annual-results]');
      const group=root.dataset.group,minimum=root.querySelector('[data-annual-minimum]');
      if(!group||!minimum.checkValidity()){annualStatus.textContent='Indica un numero minimo valido.';return;}
      annualButton.disabled=true;annualStatus.textContent='Caricamento delle presenze registrate…';
      try{const result=await request('annual_report',{group_id:group,minimum:minimum.value});host.innerHTML='<table><thead><tr><th>Persona (nomi nelle iscrizioni collegate)</th><th>Eventi frequentati</th><th>Eventi</th><th>Iscrizioni di riferimento</th></tr></thead><tbody>'+result.items.map(person=>'<tr><td>'+esc(person.names.join(' / '))+'</td><td>'+person.count+'</td><td>'+person.events.map(esc).join('<br>')+'</td><td>'+person.records.map(record=>esc(record.code)+' · '+esc(record.name)+' (#'+record.id+')').join('<br>')+'</td></tr>').join('')+'</tbody></table>';annualStatus.textContent=result.items.length+' persone con almeno '+result.minimum+' eventi dal mese '+result.from_month+' al mese '+result.to_month+'. '+result.unrecorded+' iscrizioni individuali senza presenza rilevata. Le presenze sono riunite in base al cellulare personale.';const exportButton=document.createElement('button');exportButton.type='button';exportButton.textContent='Esporta rapporto Excel';exportButton.onclick=()=>downloadExcel('presenze-'+result.from_month+'-'+result.to_month+'-gruppo-'+group+'.xlsx',[['Persona','Eventi frequentati','Eventi','Riferimenti'],...result.items.map(person=>[person.names.join(' / '),person.count,person.events.join(' · '),person.records.map(record=>record.code+' #'+record.id).join(' · ')])]);host.append(exportButton);}catch(error){host.replaceChildren();annualStatus.textContent='Rapporto non disponibile. '+error.message;}finally{annualButton.disabled=false;}
    };
  }
  function init(root) {
    if(root.dataset.ready)return;root.dataset.ready='1';
    const content=root.querySelector('[data-management-content]'),status=root.querySelector('[data-management-status]'),select=root.querySelector('[data-event-select]');
    let event=Number(root.dataset.event)>0?root.dataset.event:'',order=root.dataset.order,booking=null,busy=false,generation=0,pending=null,dirty=false,dirtyForm=null;
    const periodSelect=root.querySelector('[data-period-select]'),eventOptions=[...select.options].map(option=>option.cloneNode(true));
    let period=periodSelect?.value||'current';
    let printList=null,listResize=null,currentPerson=null,returnEvent=event,allQuery='',allClosed=false,allStatus='',allSort=readRegistrationSort();
    const eventActions=root.querySelector('[data-event-actions]');
    const mobileLayout=window.matchMedia('(max-width:760px)');
    const eventSelectors=root.querySelector('.mi-management-event-selectors');
    let eventContext=null;
    if(eventSelectors&&!eventSelectors.hidden){
      eventContext=document.createElement('div');eventContext.className='mi-management-event-context';
      eventSelectors.before(eventContext);eventContext.append(eventSelectors);
      const eventLabel=select.closest('label');
      if(eventLabel){
        eventLabel.classList.add('mi-management-event-label');
        for(const node of [...eventLabel.childNodes])if(node.nodeType===Node.TEXT_NODE&&node.textContent.trim()){
          const caption=document.createElement('span');caption.className='mi-management-event-caption';node.replaceWith(caption);caption.append(node);
        }
      }
      select.setAttribute('aria-label','Evento');
    }
    const updateEventContext=()=>{if(eventContext)select.title=select.selectedOptions[0]?.textContent||'Tutti gli eventi';};
    const arrangeManagement=()=>{
      const focused=document.activeElement;
      if(eventContext){
        const eventLabel=select.closest('label'),periodLabel=periodSelect?.closest('label');
        if(eventLabel&&periodLabel){if(mobileLayout.matches)eventSelectors.prepend(eventLabel);else eventSelectors.prepend(periodLabel);}
        updateEventContext();
        if(eventSelectors.contains(focused))focused.focus();
      }
      const summaryPanel=content.querySelector('.mi-management-summary');
      const primary=content.querySelector('[data-new-registration]'),bar=content.querySelector('.mi-management-actionbar');
      if(primary&&summaryPanel&&bar){const restoreFocus=primary.contains(focused);if(mobileLayout.matches)summaryPanel.before(primary);else bar.append(primary);if(restoreFocus)focused.focus();}
    };
    if(mobileLayout.addEventListener)mobileLayout.addEventListener('change',arrangeManagement);else mobileLayout.addListener(arrangeManagement);
    const printButton=root.querySelector('[data-print]');
    const parkPanels=()=>{if(eventActions){if(printButton)eventActions.append(printButton);eventActions.hidden=false;root.insertBefore(eventActions,content);}};
    let listContext={query:'',filter:'all',state:'',orderService:'',requests:'',deadline:'',room:'',service:'',sort:readRegistrationSort(),view:'people',shown:30},listEvent=event;
    const filterEvents=()=>{if(!periodSelect)return;select.replaceChildren(...eventOptions.filter(option=>!option.value||option.dataset.period===period).map(option=>option.cloneNode(true)));select.value=event;};
    filterEvents();
    arrangeManagement();
    const updateLocation=()=>{const url=new URL(location.href);url.searchParams.set('mi_portal_period',period);url.searchParams.set('mi_portal_event',event);url.searchParams.delete('mi_order');url.searchParams.delete('mi_sheet_sync');history.replaceState(null,'',url);};
    if(event&&!order&&!new URL(location.href).searchParams.has('mi_portal_event')){const url=new URL(location.href);url.searchParams.set('mi_portal_event',event);url.searchParams.set('mi_portal_period',period);history.replaceState(null,'',url);}
    if(periodSelect)periodSelect.onchange=async()=>{const next=periodSelect.value;if(!await canLeave()){periodSelect.value=period;return;}period=next;event='';filterEvents();updateLocation();await summary();if(select.options.length===1)say(period==='past'?'Non ci sono eventi passati.':'Non ci sono eventi attivi.');};
    const say=t=>{
      const text=String(t),error=/(non disponibile|non confermat[oa]|non riuscit[oa]|non salvat[oeia]|non completat[oa]|errore|impossibile|riprova|controlla|interrott[oa])/i.test(text);
      const busy=!error&&/^(caricamento|salvataggio|calcolo|sincronizzazione|aggiornamento)[\s…\.]/i.test(text);
      status.textContent=text;
      status.classList.toggle('mi-management-updated',text.startsWith('Aggiornato: '));
      status.classList.toggle('mi-management-status--error',error);
      status.classList.toggle('mi-management-status--busy',busy);
      status.classList.toggle('mi-management-status--success',!error&&!busy&&/^(dati aggiornati|salvataggio completato|assegnazioni salvate|presenze salvate|esportati\b)/i.test(text));
    };
    const attendanceRetries=new Map();
    async function request(operation,data={}) {
      const attendanceKey=operation==='attendance_bulk'?event+'|'+data.data:null;
      if(attendanceKey){
        if(!attendanceRetries.has(attendanceKey))attendanceRetries.set(attendanceKey,requestId());
        data={...data,request_id:attendanceRetries.get(attendanceKey)};
      }
      const abort=new AbortController(),timeout=setTimeout(()=>abort.abort(),operation==='open_sheet'?240000:90000);
      try{const response=await fetch(root.dataset.endpoint,{method:'POST',credentials:'same-origin',cache:'no-store',signal:abort.signal,body:new URLSearchParams({action:'mi_portal_management',nonce:root.dataset.nonce,event_id:event,order_code:order,operation,...data})});
      const json=await response.json();if(!response.ok||!json.success)throw new Error(json.data?.message||'Operazione non riuscita.');
      if(attendanceKey){
        const savedIds=new Set(JSON.parse(data.data).map(person=>Number(person.id)));
        for(const key of attendanceRetries.keys()){
          const separator=key.indexOf('|');
          if(key.slice(0,separator)===String(event)&&JSON.parse(key.slice(separator+1)).some(person=>savedIds.has(Number(person.id))))attendanceRetries.delete(key);
        }
      }
      const sheetLink=root.querySelector('[data-open-sheet]');
      if(sheetLink&&Object.hasOwn(json.data||{},'sheet_url')){const url=json.data?.sheet_url||'';let valid=false;try{const link=new URL(url,location.href);valid=!!url&&link.origin===location.origin&&link.searchParams.has('mi_open_sheet');}catch(error){}sheetLink.hidden=!valid;if(!sheetLink.hidden)sheetLink.href=url;else sheetLink.removeAttribute('href');}
      if(['participant','room_save','room_delete','change_options','identity_link','adjust_due','attendance','attendance_bulk','request_review','cancel','sheet_save','room_swap','room_assign','event_room_save','event_room_delete'].includes(operation)&&json.data?.saved!==false)document.dispatchEvent(new Event('mi:operational-saved'));
      return json.data;}finally{clearTimeout(timeout);}
    }
    const sheetButton=root.querySelector('[data-open-sheet]');
    const sheetSyncButton=root.querySelector('[data-sheet-sync]');
    const sheetMenu=root.querySelector('[data-sheet-menu]');
    if(sheetMenu){
      document.addEventListener('click',e=>{if(!sheetMenu.contains(e.target))sheetMenu.open=false;});
      sheetMenu.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();sheetMenu.open=false;sheetMenu.querySelector('summary').focus();}});
      sheetMenu.querySelector('.mi-sheet-menu__panel').addEventListener('click',e=>{if(e.target.closest('a,button')){sheetMenu.open=false;sheetMenu.querySelector('summary').focus();}});
    }
    if(sheetSyncButton)sheetSyncButton.addEventListener('click',syncSheet);
    function updateSheetSyncVisibility(ticket,eventId){
      if(ticket!==generation||String(event)!==String(eventId))return;
      if(sheetSyncButton)sheetSyncButton.hidden=!sheetButton||sheetButton.hidden;
      if(sheetMenu){sheetMenu.hidden=!sheetButton||sheetButton.hidden;if(sheetMenu.hidden)sheetMenu.open=false;}
    }
    if(sheetButton)sheetButton.addEventListener('click',async e=>{
      e.preventDefault();
      const sheetWindow=window.open('', '_blank');
      if(!sheetWindow){say('Apertura non completata. Consenti le finestre popup per aprire il foglio.');return;}
      if(!await canLeave()||busy){try{sheetWindow.close();}catch(closeError){}return;}
      const openingEvent=event;busy=true;sheetButton.setAttribute('aria-disabled','true');
      say('Aggiornamento del foglio in corso…');
      try {
        let token='';
        for(;;){
          const result=await request('open_sheet',{event_id:openingEvent,token});
          if(result.ready){
            const url=new URL(result.url);
            if(url.origin!=='https://docs.google.com'||!url.pathname.startsWith('/spreadsheets/d/'))throw new Error('Collegamento al foglio non valido.');
            busy=false;sheetWindow.location.href=url.href;return;
          }
          if(!result.token)throw new Error('Aggiornamento incompleto. Riprova.');
          token=result.token;
          if(result.retry_after){say(result.message||'Aggiornamento Google in corso…');await new Promise(resolve=>setTimeout(resolve,Math.min(5,Math.max(1,Number(result.retry_after)))*1000));}
        }
      }catch(error){try{sheetWindow.close();}catch(closeError){}say('Apertura non completata. '+(error.name==='AbortError'?'Aggiornamento non completato in tempo. Riprova con Apri.':error.message));}
      finally{busy=false;sheetButton.removeAttribute('aria-disabled');}
    });
    const paymentDraft=()=>!!content.querySelector('[data-payment-draft="1"]');
    root.addEventListener('mi:before-booking-navigation',e=>{if(dirty||pending||busy||paymentDraft()){e.preventDefault();say('Salva le modifiche oppure scarta la bozza prima di uscire dalla scheda.');}});
    const resolveDraft=()=>new Promise(resolve=>{const dialog=document.createElement('dialog'),previous=document.activeElement;dialog.className='mi-management-confirm';dialog.dataset.miPortalScope='reserved';dialog.innerHTML='<form method="dialog" novalidate><h2>Modifiche non salvate</h2><p>Vuoi salvare le modifiche prima di proseguire?</p><button value="stay" autofocus>Continua a modificare</button> <button value="discard">Annulla modifiche</button> <button value="save">Salva</button></form>';const title='mi-draft-'+requestId();dialog.querySelector('h2').id=title;dialog.setAttribute('aria-labelledby',title);presentDialog(dialog,previous,value=>resolve(['stay','discard','save'].includes(value)?value:'stay'));});
    const personalBaselines=new WeakMap();
    const personalValues=form=>JSON.stringify([...new FormData(form).entries()]);
    const trackEdit=e=>{
      if(e.target.closest('[data-mi-payments]'))return;
      e.target.removeAttribute('aria-invalid');const edited=e.target.closest('form');if(!edited)return;
      const changed=!personalBaselines.has(edited)||personalValues(edited)!==personalBaselines.get(edited);
      edited.toggleAttribute('data-unsaved-edit',changed);
      if(personalBaselines.has(edited))edited.querySelector('button[type="submit"]').hidden=!changed;
      dirtyForm=changed?edited:content.querySelector('form[data-unsaved-edit]');dirty=!!dirtyForm;
      if(!dirty){say('Nessuna modifica da salvare.');return;}
      say('Modifiche non salvate. Salva il modulo quando hai concluso.');
    };
    content.addEventListener('mi:payment-updated',e=>{const summary=content.querySelector('[data-booking-economics]');if(summary)summary.textContent=e.detail?'Totale '+money(e.detail.totale)+' · Versato '+money(e.detail.versato)+' · Residuo '+money(e.detail.residuo):'Movimento registrato. Aggiorna la scheda per verificare il saldo.';const history=content.querySelector('[data-booking-history]');if(history)history.remove();const deposit=content.querySelector('[data-booking-deposit]');if(deposit&&e.detail)deposit.textContent=depositDetailText({...e.detail,balance:e.detail.residuo});});
    content.addEventListener('input',trackEdit);content.addEventListener('change',trackEdit);
    window.addEventListener('beforeunload',e=>{if(root.isConnected&&(dirty||pending||busy)){e.preventDefault();e.returnValue='';}});
    document.addEventListener('click',async e=>{
      if(!root.isConnected||(!dirty&&!pending&&!busy&&!paymentDraft()))return;
      const target=e.target.closest('a,[data-mi-portal-booking-close],[data-mi-portal-booking-next],[data-mi-portal-booking-previous],[data-open],[data-edit-inventory]');
      if(!target)return;e.preventDefault();e.stopImmediatePropagation();
      if(busy||pending||paymentDraft()){say('Completa o verifica il salvataggio prima di uscire.');return;}
      const choice=await resolveDraft();if(choice==='save'){dirtyForm?.requestSubmit();return;}if(choice==='discard'){dirty=false;dirtyForm=null;target.click();}
    },true);
    document.addEventListener('keydown',e=>{if(root.isConnected&&(dirty||pending||busy||paymentDraft())&&(e.key==='Escape'||(['ArrowLeft','ArrowRight'].includes(e.key)&&!e.target.matches('input,textarea,select')))&&!document.querySelector('dialog[open]')){e.preventDefault();e.stopImmediatePropagation();say('Salva le modifiche oppure usa il comando di chiusura.');}},true);
    async function canLeave(){if(paymentDraft()){say('Completa il movimento in corso prima di uscire dalla scheda.');return false;}if(pending||busy){say('Completa o verifica il salvataggio prima di cambiare pagina.');return false;}if(dirty){const choice=await resolveDraft();if(choice==='save'){dirtyForm?.requestSubmit();return false;}if(choice!=='discard')return false;}dirty=false;dirtyForm=null;return true;}
    async function allPeople(){
      const ticket=generation;currentPerson=null;returnEvent='';
      if(printButton)printButton.hidden=true;
      content.innerHTML='<div class="mi-management-grid"><label>Cerca persona<input type="search" data-all-query placeholder="Nome, cognome, email, cellulare o codice prenotazione" value="'+esc(allQuery)+'"></label><label>Stato prenotazione<select data-all-status>'+[['','Tutti gli stati'],['CONFIRMED','Confermate'],['PENDING_PAYMENT','Da pagare'],['WAITLISTED','Lista d’attesa'],['WAITLIST_OFFERED','Posto proposto'],['CANCELLED','Annullate'],['EXPIRED','Scadute']].map(([value,label])=>'<option value="'+value+'" '+(allStatus===value?'selected':'')+'>'+label+'</option>').join('')+'</select></label><label data-all-closed-label '+(allStatus?'hidden':'')+'><input type="checkbox" data-all-closed '+(allClosed?'checked':'')+'> Includi annullate e scadute</label></div><div data-all-results></div><button type="button" data-all-more hidden>Mostra altre 30</button>';
      const host=content.querySelector('[data-all-results]'),more=content.querySelector('[data-all-more]');let offset=0,sequence=0,timer;
      const load=async(reset=true)=>{const seq=++sequence;if(reset){offset=0;host.replaceChildren();}more.hidden=true;say('Caricamento iscrizioni…');
        try{const data=await request('all_people',{query:allQuery,period,offset,status:allStatus,sort:allSort,include_closed:allClosed?'1':'0'});if(ticket!==generation||seq!==sequence)return;
          const labels={CONFIRMED:'Confermata',PENDING_PAYMENT:'Da pagare',WAITLISTED:'Lista d’attesa',WAITLIST_OFFERED:'Posto proposto',CANCELLED:'Annullata',EXPIRED:'Scaduta'};
          for(const p of data.items){const state=p.status==='CANCELLED'?'CANCELLED':p.booking_status,name=[p.last_name,p.first_name].join(' ');host.insertAdjacentHTML('beforeend','<article class="mi-all-person mi-all-person--openable" data-open="'+esc(p.order_code)+'" data-open-event="'+Number(p.event_id)+'" data-person-focus="'+Number(p.number)+'" tabindex="0" aria-label="Apri la scheda di '+esc(name)+' per '+esc(p.event_title)+'"><div><strong class="mi-participant-open-label">'+esc(name)+' <span class="mi-participant-chevron" aria-hidden="true">›</span></strong><p>'+esc(p.event_title)+'</p><small>Iscrizione del '+esc(String(p.created_at).slice(0,10).split('-').reverse().join('/'))+(labels[state]?' · '+esc(labels[state]):'')+'</small></div></article>');}
          offset+=data.items.length;more.hidden=!data.more;say(offset?'Iscrizioni visualizzate: '+offset+'.':'Nessuna iscrizione trovata.');
        }catch(error){if(ticket===generation&&seq===sequence)say('Ricerca non disponibile. '+error.message);}
      };
      const allFilters=content.querySelector('.mi-management-grid'),searchBar=document.createElement('div');searchBar.className='mi-management-search mi-search-order-row';
      const searchButton=document.createElement('button');searchButton.type='button';searchButton.textContent='Cerca';searchButton.dataset.allSearch='';searchButton.onclick=()=>{clearTimeout(timer);load();};
      const filterButton=document.createElement('button');filterButton.type='button';filterButton.textContent='Filtri';filterButton.dataset.allFiltersToggle='';
      const syncAllFilterCount=()=>{const count=Number(!!allStatus)+Number(!allStatus&&allClosed);filterButton.textContent='Filtri'+(count?' ('+count+')':'');};syncAllFilterCount();
      allFilters.hidden=true;filterButton.setAttribute('aria-expanded','false');filterButton.onclick=()=>{allFilters.hidden=!allFilters.hidden;filterButton.setAttribute('aria-expanded',String(!allFilters.hidden));};
      allFilters.before(searchBar);searchBar.append(content.querySelector('[data-all-query]').closest('label'),searchButton,filterButton,registrationSortMenu(allSort,key=>{allSort=key;saveRegistrationSort(key);clearTimeout(timer);load();}));
      content.querySelector('[data-all-query]').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();clearTimeout(timer);load();}};
      content.querySelector('[data-all-query]').oninput=e=>{allQuery=e.target.value;clearTimeout(timer);sequence++;timer=setTimeout(()=>{if(ticket===generation)load();},250);};
      content.querySelector('[data-all-status]').onchange=e=>{allStatus=e.target.value;content.querySelector('[data-all-closed-label]').hidden=!!allStatus;syncAllFilterCount();clearTimeout(timer);load();};
      content.querySelector('[data-all-closed]').onchange=e=>{allClosed=e.target.checked;syncAllFilterCount();load();};more.onclick=()=>load(false);await load();
    }
    async function summary(){
      updateEventContext();
      if(!await canLeave())return;const ticket=++generation;order='';booking=null;printList=null;parkPanels();content.replaceChildren();const sheetLink=root.querySelector('[data-open-sheet]'),sheetSync=root.querySelector('[data-sheet-sync]');if(sheetLink){sheetLink.hidden=true;sheetLink.removeAttribute('href');}if(sheetSync)sheetSync.hidden=true;if(sheetMenu){sheetMenu.open=false;sheetMenu.hidden=true;}if(!event){await allPeople();return;}say('Caricamento riepilogo…');
      if(printButton){printButton.hidden=false;printButton.textContent='Stampa riepilogo iscritti';}returnEvent=event;currentPerson=null;
      try{const data=await request('summary');if(ticket!==generation)return;
        data.items=data.items||[];data.people=data.people||[];
        const metrics=data.metrics;
        const loadPanel=async(panel)=>{
          if(!data.lazy_panels)return panel==='offers'?{offers:data.items.filter(x=>x.status==='WAITLIST_OFFERED')}:panel==='attendance'?{people:data.people.filter(p=>['CONFIRMED','PENDING_PAYMENT'].includes(p.status))}:data;
          const result=await request('summary_panel',{panel});
          if(ticket!==generation)throw new Error('La selezione è cambiata.');
          return result;
        };
        const lazyPanel=(element,load)=>{
          let loaded=false,loading=false;
          const message=document.createElement('p');message.setAttribute('role','status');element.append(message);
          const run=async()=>{
            if(!element.open||loaded||loading||ticket!==generation)return;
            loading=true;message.textContent='Caricamento…';
            try{await load();if(ticket!==generation)return;loaded=true;message.remove();}
            catch(error){if(ticket!==generation)return;message.textContent='Caricamento non disponibile. '+error.message+' ';const retry=document.createElement('button');retry.type='button';retry.textContent='Riprova';retry.onclick=run;message.append(retry);}
            finally{loading=false;}
          };
          element.addEventListener('toggle',run);
        };
        const attendanceWindow=data.attendance_availability;
        if(attendanceWindow?.enabled&&!attendanceWindow.available&&attendanceWindow.starts_at>attendanceWindow.server_now){
          const activate=()=>{if(ticket!==generation)return;if(busy||dirty){setTimeout(activate,1000);return;}summary();};
          setTimeout(activate,Math.min(2147483647,Math.max(1000,(attendanceWindow.starts_at-attendanceWindow.server_now)*1000)));
        }
        const active=data.items.filter(x=>x.active),sum=k=>metrics?Number(metrics[k]||0):active.reduce((n,x)=>n+Number(x[k]||0),0);
        const people=state=>metrics?Number(metrics.states[state]||0):data.items.filter(x=>x.status===state).reduce((n,x)=>n+x.participants,0);
        const receivable=metrics?metrics.receivable:data.items.filter(x=>x.collectible??['CONFIRMED','PENDING_PAYMENT'].includes(x.status)).reduce((n,x)=>n+x.balance,0);
        const netPaid=metrics?metrics.paid:data.items.reduce((n,x)=>n+x.paid,0);
        const features=data.features||{rooms:true,payments:true,deposit:true};

        const summaryRow=(label,value,attention=false)=>'<tr'+(attention?' class="mi-summary-attention"':'')+'><th scope="row">'+label+'</th><td>'+value+'</td></tr>';
        const summaryGroup=(title,rows)=>'<tbody><tr class="mi-summary-section"><th scope="rowgroup" colspan="2">'+title+'</th></tr>'+rows+'</tbody>';
        const summaryCard=(label,value,detail='',attention=false,key='')=>'<article class="mi-summary-card'+(attention?' mi-summary-card--attention':'')+(key?' mi-summary-card--'+key:'')+'"><span>'+label+'</span><strong>'+value+'</strong>'+(detail?'<small>'+detail+'</small>':'')+'</article>';
        const waitlistRows=(people('WAITLISTED')>0?summaryRow('Persone in lista d’attesa',people('WAITLISTED')):'')+(people('WAITLIST_OFFERED')>0?summaryRow('Persone con posto proposto',people('WAITLIST_OFFERED')):'');
        const registeredPeople=people('CONFIRMED')+people('PENDING_PAYMENT');
        const paymentCounts=data.payment_counts||{};
        const settledPeople=Number(paymentCounts.settled||0),depositCovered=Number(paymentCounts.deposit_covered||0);
        const paidPeopleRows=summaryRow('Persone iscritte',registeredPeople)+(features.deposit&&depositCovered>0?summaryRow('Caparra versata',depositCovered):'')+(settledPeople>0?summaryRow(features.deposit?'Saldo versato':'Persone con pagamento completato',settledPeople):'');
        const peopleRows=(features.payments?paidPeopleRows:summaryRow('Persone confermate',people('CONFIRMED')))+waitlistRows;
        const economicRows=features.payments?summaryGroup('Importi',summaryRow('Da incassare',money(receivable),receivable>0)+'<tr data-net-paid><th scope="row">Versato netto<small>Esclusi rimborsi effettuati</small></th><td>'+money(netPaid)+'</td></tr>'):'';
        const qualityRows=(sum('missing')>0?summaryRow('Partecipanti con dati mancanti',sum('missing'),true):'')+(features.rooms?summaryRow('Partecipanti senza camera',sum('unassigned'),sum('unassigned')>0):'');
        const summaryCards=[summaryCard('Iscritti',registeredPeople,features.deposit?'Caparra versata: '+depositCovered:'Confermati: '+people('CONFIRMED')),features.payments?summaryCard('Da incassare',money(receivable),'Versato netto: '+money(netPaid),receivable>0):'',features.rooms?summaryCard('Senza camera',sum('unassigned'),sum('unassigned')?'Da assegnare':'Nessuna persona',sum('unassigned')>0):'',summaryCard('Dati mancanti',sum('missing'),sum('missing')?'Richiede attenzione':'Dati completi',sum('missing')>0,'missing'),waitlistRows?summaryCard('Lista d’attesa',people('WAITLISTED')+people('WAITLIST_OFFERED'),people('WAITLIST_OFFERED')?'Posti proposti: '+people('WAITLIST_OFFERED'):'Nessuna persona'):'' ].filter(Boolean).join('');
        content.innerHTML=`<section class="mi-management-summary" aria-label="Riepilogo evento"><h3>Riepilogo</h3><div class="mi-management-summary-cards">${summaryCards}</div></section><p data-new-registration><a class="mi-primary mi-new-registration" href="${esc(data.registration_url||'#')}" target="_blank" rel="noopener">Inserisci nuova iscrizione</a></p><label>Cerca nome o codice <input type="search" data-query></label><button data-clear-query>Cancella ricerca</button><div data-list></div>`;
        const newRegistration=content.querySelector('[data-new-registration]');
        if(eventActions){eventActions.hidden=false;const actionBar=document.createElement('div');actionBar.className='mi-management-actionbar';newRegistration.before(actionBar);actionBar.append(eventActions,newRegistration);}
        // I conteggi restano visibili a ogni larghezza senza un riquadro da espandere.
        arrangeManagement();
        if(!features.payments)content.querySelector('[data-net-paid]')?.setAttribute('hidden','');

        if(listEvent!==event){listContext={query:'',filter:'all',state:'',requests:'',deadline:'',room:'',service:'',sort:readRegistrationSort(),view:'people',shown:30};listEvent=event;}
        listContext.view='people';listContext.orderService='';
        applyAttendanceSort(listContext,data.attendance_availability?.available);
        const states={CONFIRMED:'Partecipante',PENDING_PAYMENT:'Pagamento atteso',WAITLISTED:'Lista d’attesa',WAITLIST_OFFERED:'Posto proposto',CANCELLED:'Annullata',EXPIRED:'Scaduta'};
        const stateLabel=row=>{
          if(!features.payments||!['CONFIRMED','PENDING_PAYMENT'].includes(row.status))return states[row.status]||row.status;
          if(row.deposit_plan&&row.deposit_due===null)return 'Caparre da verificare';
          if(row.balance<=0)return 'Saldato';
          if(row.deposit_plan??features.deposit)return row.deposit_missing>0?'Caparra attesa':'Saldo atteso';
          return 'Pagamento atteso';
        };
        const stateClass=row=>({CONFIRMED:'confirmed',PENDING_PAYMENT:'pending',WAITLISTED:'waitlist',WAITLIST_OFFERED:'offered',CANCELLED:'cancelled',EXPIRED:'expired'}[row.status]||'neutral');
        const search=content.querySelector('[data-query]');search.value=listContext.query;
        if(listContext.filter==='balance')listContext.filter='all';
        const criticalOptions=[['all','Tutte le iscrizioni'],['missing','Dati mancanti'],...(features.rooms?[['unassigned','Senza camera']]:[])];
        content.querySelector('[data-list]').insertAdjacentHTML('beforebegin','<label>Manca qualcosa?<select data-critical-filter>'+criticalOptions.map(([value,label])=>'<option value="'+value+'">'+label+'</option>').join('')+'</select></label>');
        const criticalFilter=content.querySelector('[data-critical-filter]');
        if(listContext.deposit===undefined)listContext.deposit='';
        const paymentOptions=[['','Tutti gli iscritti'],...(features.deposit?[['none','Nessun versamento'],['partial','Caparra da completare'],['covered','Caparra versata']]:[['unpaid','Da saldare']]),['settled','Saldato']];
        content.querySelector('[data-list]').insertAdjacentHTML('beforebegin','<label>Stato<select data-deposit-filter>'+paymentOptions.map(([value,label])=>'<option value="'+value+'">'+label+'</option>').join('')+'</select></label>');
        const depositFilter=content.querySelector('[data-deposit-filter]');depositFilter.value=listContext.deposit||'';depositFilter.onchange=()=>{listContext.deposit=depositFilter.value;listContext.shown=30;draw();};
        listContext.state='';
        const utc=value=>{if(!value)return null;const date=new Date(value.includes('T')?value:value.replace(' ','T')+'Z');return Number.isNaN(date.getTime())?null:date;};
        const deadlineLabel=value=>utc(value)?.toLocaleString('it-IT')||'Non indicata';
        content.querySelector('[data-list]').insertAdjacentHTML('beforebegin','<div class="mi-management-grid"><label>Richieste particolari<select data-request-filter><option value="">Tutte le prenotazioni</option><option value="yes">Richieste particolari</option></select></label><label>Scadenza del posto proposto<select data-deadline-filter><option value="">Tutte le scadenze</option><option value="soon">Entro 24 ore</option><option value="expired">Termine trascorso</option></select></label><label>Servizio individuale<select data-service-filter><option value="">Tutti i servizi</option></select></label></div>');
        const requestFilter=content.querySelector('[data-request-filter]'),deadlineFilter=content.querySelector('[data-deadline-filter]'),serviceFilter=content.querySelector('[data-service-filter]');
        content.querySelector('[data-deposit-filter]').closest('label').hidden=!features.payments;
        listContext.room='';
        requestFilter.closest('label').hidden=!(metrics?metrics.has_requests:data.items.some(x=>String(x.requests||'').trim()));
        deadlineFilter.closest('label').hidden=!(metrics?metrics.offers:data.items.some(x=>x.status==='WAITLIST_OFFERED'));
        if(!features.rooms){listContext.room='';if(listContext.filter==='unassigned')listContext.filter='all';}
        if(!features.payments&&listContext.filter==='balance')listContext.filter='all';
        if(!features.payments)listContext.deposit='';
        requestFilter.value=listContext.requests;deadlineFilter.value=listContext.deadline;
        const requestMatch=x=>!listContext.requests||(String(x.requests||'').trim()&&(listContext.requests==='yes'||(listContext.requests==='reviewed'?x.requests_reviewed:!x.requests_reviewed)));
        const deadlineMatch=x=>{if(!listContext.deadline)return true;if(x.status!=='WAITLIST_OFFERED')return false;const deadline=utc(x.offer_expires_at);if(!deadline)return false;const remaining=deadline.getTime()-Date.now();return listContext.deadline==='expired'?remaining<=0:remaining>0&&remaining<=86400000;};
        const personLogistics=p=>(!listContext.room||(listContext.room==='unassigned'?!p.room:p.room===listContext.room.slice(5)))&&(!listContext.service||(p.options||[]).some(o=>(o.code||o.name)===listContext.service&&Number(o.quantity)>0));
        let roomPeople=data.people,admitted=roomPeople.filter(p=>['CONFIRMED','PENDING_PAYMENT'].includes(p.status));
        let rooms=data.rooms||[];
        booking={version:data.rooms_version||''};
        const renderRoomPanels=()=>{
        if(features.rooms&&Object.keys(data.room_types||{}).length){
          const types=data.room_types,planner=document.createElement('section');planner.className='mi-room-planner';planner.dataset.roomPlanner='';
          planner.innerHTML='<h3>Assegnazione camere</h3><label><select data-room-type aria-label="Tipo di sistemazione"><option value="">Tutte le sistemazioni</option>'+Object.entries(types).map(([code,type])=>'<option value="'+esc(code)+'">'+esc(type.name)+' ('+esc(type.prefix)+')</option>').join('')+'</select></label><div data-room-assignments></div>';
          content.querySelector('[data-new-registration]').after(planner);
          const typeSelect=planner.querySelector('[data-room-type]'),host=planner.querySelector('[data-room-assignments]');
          typeSelect.closest('label').insertAdjacentHTML('afterend','<label><select data-room-assignment-filter aria-label="Stato assegnazione camere"><option value="all">Tutti gli stati</option><option value="assigned">Assegnate</option><option value="unassigned">Da assegnare</option><option value="partial">Da riempire</option><option value="partial_unassigned">Da riempire e da assegnare</option></select></label>');
          const assignmentFilter=planner.querySelector('[data-room-assignment-filter]');
          const roomFilters=document.createElement('div');roomFilters.className='mi-room-filters';host.before(roomFilters);roomFilters.append(typeSelect.closest('label'),assignmentFilter.closest('label'));
          listContext.roomAssignment=listContext.roomAssignment||'all';assignmentFilter.value=listContext.roomAssignment;
          if(!types[listContext.roomType])listContext.roomType='';typeSelect.value=listContext.roomType;
          const renderAssignments=()=>{
            const selectedType=typeSelect.value;
            const assignedType=p=>p.room&&Object.entries(types).find(([,candidate])=>new RegExp('^'+candidate.prefix+'[1-9][0-9]{0,5}$').test(p.room));
            const requestedType=p=>(p.options||[]).find(o=>types[o.code]&&Number(o.quantity)>0)?.code||'';
            const typeFor=p=>assignedType(p)?.[0]||requestedType(p);
            const isPartial=p=>{const room=rooms.find(candidate=>candidate.code===p.room);return !!(room&&Number(room.occupied)<Number(room.capacity));};
            const persons=admitted.filter(p=>{const code=typeFor(p),state=assignmentFilter.value;return code&&(!selectedType||code===selectedType)&&(state==='all'||(state==='assigned'?!!p.room:state==='unassigned'?!p.room:state==='partial'?isPartial(p):(isPartial(p)||!p.room)));});
            if(!persons.length){host.innerHTML='<p>Nessuna persona corrisponde ai filtri scelti.</p>';return;}
            const groups=new Map();for(const person of persons){const typeCode=typeFor(person),key=typeCode+'|'+(person.room||'');if(!groups.has(key))groups.set(key,{typeCode,code:person.room||'',people:[]});groups.get(key).people.push(person);}
            const ordered=[...groups.values()].sort((a,b)=>{const typeOrder=types[a.typeCode].name.localeCompare(types[b.typeCode].name,'it');if(typeOrder)return typeOrder;const rank=group=>{const room=rooms.find(r=>r.code===group.code);return !group.code?1:(room&&Number(room.occupied)<Number(room.capacity)?0:2);},rankOrder=rank(a)-rank(b);if(rankOrder)return rankOrder;return !a.code?-1:!b.code?1:a.code.localeCompare(b.code,'it',{numeric:true});});
            let previousType='';host.innerHTML='<p>Se si vuole cambiare tipo di alloggio (per es. da doppia a tripla), andare sotto, alla sezione <strong>Cambia tipo di abitazione</strong>.</p><p>Assegna lo stesso numero alle persone che condividono una camera. I numeri già completi non sono accettati.</p><p class="mi-room-assignment-key"><span class="mi-room-key--unassigned">Senza camera</span><span class="mi-room-key--partial">Camera da completare</span></p><form data-room-assign-form novalidate><div class="mi-room-assignment-table" tabindex="0" role="region" aria-label="Assegnazioni camere"><table><thead><tr><th>Sistemazione</th><th>Numero</th><th>Persona</th></tr></thead><tbody>'+ordered.map((group,groupIndex)=>{
              const type=types[group.typeCode],room=rooms.find(r=>r.code===group.code),partial=room&&room.occupied<room.capacity;
              const heading=group.typeCode===previousType?'':'<tr class="mi-room-type-heading"><th colspan="3">'+esc(type.name)+'</th></tr>';previousType=group.typeCode;const availableNumbers=p=>{const matching=rooms.filter(candidate=>new RegExp('^'+type.prefix+'[1-9][0-9]{0,5}$').test(candidate.code)),used=matching.map(candidate=>Number(candidate.code.slice(type.prefix.length))),choices=matching.filter(candidate=>candidate.available>0||candidate.code===p.room).map(candidate=>Number(candidate.code.slice(type.prefix.length))),highest=Math.max(0,...used);let next=1;while(used.includes(next))next++;choices.push(next,highest+1);return [...new Set(choices)].sort((a,b)=>a-b);};const peopleRows=group.people.sort((a,b)=>a.name.localeCompare(b.name,'it')).map((p,index)=>{
                const match=(p.room||'').match(new RegExp('^'+type.prefix+'([1-9][0-9]{0,5})$')),number=match?match[1]:'';
                return '<tr class="mi-room-member mi-room-band-'+(groupIndex%2)+(partial?' mi-room-needs-occupant':'')+(!group.code?' mi-room-unassigned':'')+'" data-room-key="'+esc(group.code||'unassigned')+'"><td data-room-preview>'+esc(type.prefix+(number||'—'))+'</td><td><select data-room-person="'+p.id+'" data-room-type="'+esc(group.typeCode)+'" data-initial="'+number+'" aria-label="Numero '+esc(type.name)+' per '+esc(p.name)+'"><option value="">—</option>'+availableNumbers(p).map(candidate=>'<option value="'+candidate+'" '+(String(candidate)===number?'selected':'')+'>'+candidate+'</option>').join('')+'</select></td><td>'+esc(p.name)+'</td></tr>';
              }).join('');const vacancy=partial?'<tr class="mi-room-vacancy"><td colspan="3">'+(Number(room.capacity)-Number(room.occupied))+' '+(Number(room.capacity)-Number(room.occupied)===1?'posto libero':'posti liberi')+'</td></tr>':'';return heading+peopleRows+vacancy;
            }).join('')+'</tbody></table></div><p>Lascia il numero vuoto per togliere l’assegnazione. La sistemazione richiesta è il criterio dell’assegnazione.</p><div class="mi-room-assignment-actions mi-room-sticky-actions"><span data-room-assignment-status>Nessuna modifica</span><button type="button" data-discard-room-assignments>Annulla</button><button type="submit" class="mi-primary">Salva assegnazioni</button></div></form>';
            const form=host.querySelector('form');
            const validateNumber=el=>{const type=types[el.dataset.roomType],number=el.value,target=number?type.prefix+Number(number):'',person=persons.find(p=>String(p.id)===el.dataset.roomPerson),room=rooms.find(r=>r.code===target),proposed=[...form.querySelectorAll('[data-room-person]')].filter(other=>{const otherPerson=persons.find(p=>String(p.id)===other.dataset.roomPerson);return other!==el&&other.dataset.roomType===el.dataset.roomType&&other.value===number&&otherPerson.room!==target;}).length,already=(room?admitted.filter(p=>p.room===target&&p.id!==person.id).length:0);el.setCustomValidity(number&&((type.individual&&already+proposed>0)||(!type.individual&&already+proposed>=Number(type.capacity)))?'Questo numero corrisponde a una camera già completa.':'');};
            const updateAssignmentStatus=()=>{const changed=[...form.querySelectorAll('[data-room-person]')].filter(el=>el.value!==el.dataset.initial).length;form.querySelector('[data-room-assignment-status]').textContent=changed?(changed+' '+(changed===1?'assegnazione modificata':'assegnazioni modificate')):'Nessuna modifica';};
            form.onchange=e=>{if(!e.target.matches('[data-room-person]'))return;const input=e.target,type=types[input.dataset.roomType];validateNumber(input);input.closest('tr').querySelector('[data-room-preview]').textContent=input.value?type.prefix+input.value:'Da assegnare';updateAssignmentStatus();};
            form.querySelector('[data-discard-room-assignments]').onclick=()=>{if(busy||pending)return;dirty=false;dirtyForm=null;content.querySelectorAll('[data-draft-locked]').forEach(el=>{el.disabled=false;delete el.dataset.draftLocked;});renderAssignments();say('Assegnazioni ripristinate. Nessuna modifica registrata.');};
            form.onsubmit=e=>{
              e.preventDefault();e.stopPropagation();if(busy||pending)return;
              form.querySelectorAll('[data-room-person]').forEach(validateNumber);const invalid=[...form.querySelectorAll('[data-room-person]')].find(el=>!el.checkValidity());if(invalid){invalid.reportValidity();return;}
              const changes=[];for(const el of form.querySelectorAll('[data-room-person]')){
                if(el.value===el.dataset.initial)continue;const person=persons.find(p=>String(p.id)===el.dataset.roomPerson);
                const type=types[el.dataset.roomType];changes.push({order_code:person.code,number:person.number,key:'room',before:person.room||'',after:el.value?type.prefix+Number(el.value):'',type:el.dataset.roomType});
              }
              if(!changes.length){dirty=false;dirtyForm=null;content.querySelectorAll('[data-draft-locked]').forEach(el=>{el.disabled=false;delete el.dataset.draftLocked;});say('Nessuna assegnazione da modificare.');return;}
              if(changes.length>500){say('Salva al massimo 500 assegnazioni alla volta.');return;}
              mutate('room_assign',changes);
            };
          };
          assignmentFilter.onchange=()=>{if(dirty||pending||busy){assignmentFilter.value=listContext.roomAssignment;say('Salva o scarta le assegnazioni prima di cambiare filtro.');return;}listContext.roomAssignment=assignmentFilter.value;renderAssignments();};
          typeSelect.onchange=()=>{if(dirty||pending||busy){typeSelect.value=listContext.roomType||'';say('Salva o scarta le assegnazioni prima di cambiare sistemazione.');return;}listContext.roomType=typeSelect.value;renderAssignments();};renderAssignments();
          if(!features.room_inventory){const demandNames={'alloggio-singola':['singola','singole'],'alloggio-doppia-separati':['doppia con letti separati','doppie con letti separati'],'alloggio-doppia-matrimoniale':['doppia matrimoniale','doppie matrimoniali'],'alloggio-tripla':['tripla','triple'],'alloggio-multipla':['multipla','multiple']};const demand=Object.entries(types).map(([code,type])=>{const people=admitted.filter(p=>(p.options||[]).some(o=>o.code===code&&Number(o.quantity)>0));if(!people.length)return '';const roomsNeeded=type.individual?people.length:Math.ceil(people.length/Number(type.capacity)),names=demandNames[code]||[String(type.name).toLowerCase(),String(type.name).toLowerCase()];return '<li><strong>'+roomsNeeded+' '+esc(names[roomsNeeded===1?0:1])+'</strong> ('+people.length+' '+(people.length===1?'persona':'persone')+')</li>';}).join('');if(demand)planner.insertAdjacentHTML('beforeend','<section class="mi-accommodation-demand"><h4>Riepilogo prenotazioni camere</h4><p>Numero indicativo di camere da prenotare, calcolato sulle preferenze raccolte.</p><ul>'+demand+'</ul></section>');}
          const changePanel=document.createElement('details');changePanel.dataset.accommodationChange='';
          changePanel.innerHTML='<summary>Cambia tipo di abitazione</summary><p>Seleziona le persone a cui cambiare tipo di alloggio e assegna contestualmente la stanza di destinazione.</p><form data-accommodation-form novalidate><label class="mi-accommodation-search">Cerca persona o sistemazione<input type="search" data-accommodation-search placeholder="Nome, cognome o sistemazione"></label><fieldset><legend>Elenco persone</legend>'+admitted.filter(p=>(p.options||[]).some(o=>String(o.code||'').startsWith('alloggio-')&&Number(o.quantity)>0)).map(p=>'<label class="mi-accommodation-person"><input type="checkbox" name="person" value="'+p.id+'"> '+esc(p.name)+' · '+esc(p.room||'da assegnare')+'</label>').join('')+'</fieldset><label>Nuova sistemazione<select name="type">'+Object.entries(types).map(([code,t])=>'<option value="'+esc(code)+'">'+esc(t.name)+'</option>').join('')+'</select></label><label>Numero della camera esistente (facoltativo)<input name="number" type="number" min="1" max="999999" step="1" placeholder="Nuova camera"></label><p>Per spostare le persone selezionate in una camera esistente, indica il suo numero. Lascia vuoto per creare una nuova camera: condivisa dalle persone selezionate per doppie e triple, con codici individuali per singole e camerate.</p><details data-accommodation-notes><summary>Annotazioni (facoltative)</summary><label>Annotazioni<textarea name="reason" maxlength="500"></textarea></label></details><div data-accommodation-preview aria-live="polite"></div><div class="mi-room-sticky-actions"><span data-accommodation-action-status>Nessuna persona selezionata</span><button type="button" data-discard-accommodation>Annulla</button><button type="submit" class="mi-primary" data-preview-accommodation>Verifica il cambio</button><button type="button" class="mi-primary" data-confirm-accommodation hidden>Conferma cambio e importi</button></div></form>';
          planner.append(changePanel);
          const assignmentPanel=document.createElement('section');assignmentPanel.dataset.roomModePanel='assign';assignmentPanel.className='mi-room-operation-panel';assignmentPanel.innerHTML='<h4>Assegna stanze</h4>';for(const node of [...planner.children])if(node!==changePanel)assignmentPanel.append(node);changePanel.dataset.roomModePanel='change';changePanel.classList.add('mi-room-operation-panel');changePanel.open=true;const modeControls=document.createElement('div');modeControls.className='mi-room-mode-controls';modeControls.innerHTML='<button type="button" data-room-mode="assign" aria-expanded="true">Assegna stanze</button><button type="button" data-room-mode="change" aria-expanded="false">Cambia tipo di abitazione</button>';planner.prepend(modeControls,assignmentPanel,changePanel);changePanel.hidden=true;const activateRoomMode=mode=>{assignmentPanel.hidden=mode!=='assign';changePanel.hidden=mode!=='change';for(const button of modeControls.querySelectorAll('button'))button.setAttribute('aria-expanded',button.dataset.roomMode===mode?'true':'false');};modeControls.onclick=e=>{const button=e.target.closest('[data-room-mode]');if(button)activateRoomMode(button.dataset.roomMode);};
          const changeForm=changePanel.querySelector('form'),previewHost=changePanel.querySelector('[data-accommodation-preview]');let changePreview=null;
          const personGroups=new Map();
          for(const label of changeForm.querySelectorAll('.mi-accommodation-person')){
            const person=admitted.find(p=>String(p.id)===label.querySelector('input').value);
            const option=(person.options||[]).find(o=>types[o.code]&&Number(o.quantity)>0);
            const assigned=person.room&&Object.entries(types).find(([,type])=>new RegExp('^'+type.prefix+'[1-9][0-9]{0,5}$').test(person.room));
            const typeCode=assigned?.[0]||option?.code,title=types[typeCode]?.name||'Altra sistemazione',code=person.room||((types[typeCode]?.prefix||'')+'—');
            label.innerHTML='<input type="checkbox" name="person" value="'+person.id+'"><span class="mi-accommodation-person-code">'+esc(code)+'</span><span>'+esc(person.name)+'</span>';
            if(!personGroups.has(title))personGroups.set(title,[]);personGroups.get(title).push(label);
          }
          const peopleBox=changeForm.querySelector('fieldset');
          for(const [title,labels] of [...personGroups].sort(([a],[b])=>a.localeCompare(b,'it',{numeric:true}))){const heading=document.createElement('h4');heading.textContent=title;labels.forEach(label=>label.dataset.accommodationGroup=title);peopleBox.append(heading,...labels.sort((a,b)=>a.textContent.localeCompare(b.textContent,'it')));}
          const accommodationSearch=changeForm.querySelector('[data-accommodation-search]');accommodationSearch.oninput=()=>{const query=accommodationSearch.value.trim().toLocaleLowerCase('it');for(const label of peopleBox.querySelectorAll('.mi-accommodation-person'))label.hidden=!!query&&!((label.textContent+' '+label.dataset.accommodationGroup).toLocaleLowerCase('it').includes(query));for(const heading of peopleBox.querySelectorAll('h4')){let node=heading.nextElementSibling,visible=false;while(node&&!node.matches('h4')){if(!node.hidden)visible=true;node=node.nextElementSibling;}heading.hidden=!visible;}};
          const oldNumber=changeForm.elements.namedItem('number'),destination=document.createElement('select');destination.name='number';oldNumber.closest('label').firstChild.textContent='Camera di destinazione';oldNumber.replaceWith(destination);
          destination.closest('label').nextElementSibling.textContent='Scegli una camera consultando occupanti e posti disponibili, oppure crea una nuova camera con numero automatico.';
          const refreshDestinations=()=>{
            const previous=destination.value,type=types[changeForm.elements.namedItem('type').value];
            const selected=new Set([...changeForm.querySelectorAll('[name=person]:checked')].map(el=>el.value));
            destination.replaceChildren(new Option('Crea nuova camera (numero automatico)',''));
            for(const room of rooms){
              const match=room.code.match(new RegExp('^'+type.prefix+'([1-9][0-9]{0,5})$'));if(!match)continue;
              const occupants=admitted.filter(p=>p.room===room.code),leaving=occupants.filter(p=>selected.has(String(p.id))).length;
              const free=Math.max(0,Number(room.capacity)-Number(room.occupied)),needed=selected.size-leaving;
              const text=room.code+' — '+(occupants.map(p=>p.name).join(', ')||'Vuota')+' — '+(free?free+(free===1?' posto libero':' posti liberi'):'completa');
              const option=new Option(text,match[1]);option.disabled=(free===0&&leaving===0)||needed>free||(type.individual&&selected.size>1);destination.append(option);
            }
            if([...destination.options].some(o=>o.value===previous&&!o.disabled))destination.value=previous;
          };
          changeForm.addEventListener('change',e=>{if(e.target.name==='type'||e.target.name==='person')refreshDestinations();});refreshDestinations();
          const previewButton=changeForm.querySelector('[data-preview-accommodation]'),confirmButton=changeForm.querySelector('[data-confirm-accommodation]'),actionStatus=changeForm.querySelector('[data-accommodation-action-status]');
          confirmButton.onclick=()=>{if(!changePreview||busy||pending)return;pending={operation:'change_accommodation',data:JSON.stringify(changePreview.payload),preview_version:changePreview.version,request_id:requestId()};mutate('change_accommodation',changePreview.payload);};
          const updateAccommodationStatus=()=>{const selected=changeForm.querySelectorAll('[name=person]:checked').length;actionStatus.textContent=selected?(selected+' '+(selected===1?'persona selezionata':'persone selezionate')):'Nessuna persona selezionata';};
          const invalidate=()=>{changePreview=null;previewHost.replaceChildren();previewButton.hidden=false;confirmButton.hidden=true;updateAccommodationStatus();};changeForm.addEventListener('input',invalidate);changeForm.addEventListener('change',invalidate);
          changeForm.querySelector('[data-discard-accommodation]').onclick=()=>{if(busy||pending)return;changeForm.reset();refreshDestinations();invalidate();dirty=false;dirtyForm=null;content.querySelectorAll('[data-draft-locked]').forEach(el=>{el.disabled=false;delete el.dataset.draftLocked;});say('Cambio annullato. Nessuna modifica registrata.');};
          changeForm.onsubmit=async e=>{
            e.preventDefault();e.stopPropagation();if(busy||pending)return;
            if(!changeForm.reportValidity())return;
            const people=[...changeForm.querySelectorAll('[name=person]:checked')].map(el=>{const p=admitted.find(p=>String(p.id)===el.value);return {code:p.code,number:p.number};});
            if(!people.length){say('Seleziona almeno una persona.');return;}
            const payload={people,type:changeForm.elements.namedItem('type').value,number:changeForm.elements.namedItem('number').value,reason:changeForm.elements.namedItem('reason').value};
            busy=true;invalidate();const controls=[...changeForm.querySelectorAll('input,select,textarea,button')];controls.forEach(el=>el.disabled=true);say('Calcolo dell’anteprima…');
            try{
              const plan=await request('accommodation_preview',{data:JSON.stringify(payload)});if(plan.saved===false)throw new Error(plan.message);
              changePreview={payload,version:plan.version};
              previewHost.innerHTML='<h4>Anteprima del cambio</h4><ul>'+plan.people.map(p=>'<li>'+esc(p.name)+' · '+esc(p.code)+': '+esc(p.before_type)+' → '+esc(p.after_type)+'; '+esc(p.before_room||'senza codice')+' → <strong>'+esc(p.after_room)+'</strong></li>').join('')+'</ul><div class="mi-room-assignment-table" tabindex="0" role="region" aria-label="Variazione importi"><table><thead><tr><th>Iscrizione</th><th>Dovuto prima</th><th>Dovuto dopo</th><th>Differenza</th><th>Versato</th><th>Residuo totale</th><th>Da restituire</th></tr></thead><tbody>'+plan.orders.map(o=>'<tr><th scope="row">'+esc(o.code)+'</th><td>'+money(o.before_total)+'</td><td>'+money(o.after_total)+'</td><td>'+money(o.delta)+'</td><td>'+money(o.paid)+'</td><td>'+(o.due===null?'Da verificare':money(o.due))+'</td><td>'+(o.refund===null?'Da verificare':money(o.refund))+'</td></tr>').join('')+'</tbody></table></div><p>Il residuo totale comprende anche il saldo successivo: non indica la sola caparra da versare ora. La conferma aggiorna sistemazione, camera e dovuto insieme. Non registra pagamenti né rimborsi. Se la caparra è percentuale viene ricalcolata sulle quote individuali; se è fissa resta invariata, entro la nuova quota.</p>';
              previewButton.hidden=true;confirmButton.hidden=false;actionStatus.textContent='Anteprima pronta';
              say('Anteprima pronta. Verifica camere e importi prima di confermare.');
            }catch(error){say('Anteprima non disponibile. '+error.message);}finally{busy=false;controls.forEach(el=>el.disabled=false);}
          };
        }
        content.querySelector('[data-list]').insertAdjacentHTML('beforebegin','<details data-room-inventory><summary>Gestisci inventario camere</summary><p>Per modificare una camera usa il suo codice. La capienza deve comprendere tutti gli occupanti già assegnati.</p><form data-room novalidate>'+input('code','Codice camera','')+input('name','Nome camera','')+input('capacity','Posti',1,'number')+'<button type="submit">Salva camera</button></form><ul>'+rooms.map(r=>'<li>'+esc(r.code)+' — '+esc(r.name)+': '+r.occupied+'/'+r.capacity+' <button data-edit-inventory="'+esc(r.code)+'">Modifica</button> <button class="mi-danger" data-delete-room="'+esc(r.code)+'" '+(r.occupied?'disabled':'')+'>Elimina camera vuota</button></li>').join('')+'</ul></details>');
        content.querySelector('[data-room-inventory]').hidden=!features.rooms||!features.room_inventory;
        content.querySelectorAll('[data-edit-inventory]').forEach(button=>button.onclick=()=>{if(dirty||pending||busy){say('Completa o scarta prima la modifica in corso.');return;}const room=rooms.find(r=>r.code===button.dataset.editInventory),form=content.querySelector('[data-room]');for(const key of ['code','name','capacity'])form.elements.namedItem(key).value=room[key];form.elements.namedItem('name').focus();});
        if(features.rooms&&rooms.length){
          const occupants=roomPeople.filter(p=>!['CANCELLED','EXPIRED'].includes(p.status));
          const choices='<option value="">Scegli una persona</option>'+occupants.map(p=>'<option value="'+p.id+'">'+esc(p.name)+' · '+esc(p.code)+' · '+esc(p.room||'senza camera')+'</option>').join('');
          content.querySelector('[data-list]').insertAdjacentHTML('beforebegin','<details data-room-occupants><summary>Camere e occupanti</summary>'+rooms.map(r=>'<h3>'+esc(r.name)+' · '+r.occupied+'/'+r.capacity+' posti</h3><ul>'+occupants.filter(p=>p.room===r.code).map(p=>'<li>'+esc(p.name)+' · '+esc(p.code)+'</li>').join('')+'</ul>').join('')+'<p>'+admitted.filter(p=>!p.room).length+' persone ammesse senza camera.</p><label>Prima persona<select data-swap-first>'+choices+'</select></label><label>Seconda persona<select data-swap-second>'+choices+'</select></label><button data-swap>Scambia le camere</button></details>');
          const swap=content.querySelector('[data-swap]');swap.onclick=async()=>{
            if(busy)return;if(dirty||(pending&&pending.operation!=='room_swap')){say('Completa o scarta la modifica in corso prima di scambiare le camere.');return;}
            const a=occupants.find(p=>String(p.id)===content.querySelector('[data-swap-first]').value),b=occupants.find(p=>String(p.id)===content.querySelector('[data-swap-second]').value);
            if(!pending){if(!a||!b||a.id===b.id||a.room===b.room){say('Scegli due persone diverse con assegnazioni diverse.');return;}if(!await ask('Scambiare le camere di '+a.name+' e '+b.name+'?','Scambia camere'))return;pending={operation:"room_swap",data:JSON.stringify([{order_code:a.code,number:a.number,key:'room',before:a.room,after:b.room},{order_code:b.code,number:b.number,key:'room',before:b.room,after:a.room}]),request_id:requestId()};}
            busy=true;swap.disabled=true;
            try{const result=await request('room_swap',pending);if(result.saved===false){if(result.rejected){pending=null;say(result.message);return;}throw new Error(result.message);}pending=null;busy=false;await summary();say('Camere scambiate. Aggiornamento del foglio accodato.');}catch(error){say('Scambio non confermato. '+error.message);swap.textContent='Riprova lo stesso scambio';}finally{busy=false;swap.disabled=false;}
          };
        }
        };
        const optionDefinitions=new Map((data.option_definitions||[]).map(option=>[option.code,option]));
        const services=new Map();for(const option of data.service_totals||admitted.flatMap(p=>p.options||[])){const key=option.code||option.name;if(String(key).startsWith('alloggio-'))continue;const definition=optionDefinitions.get(key)||{};const category=participantOptionCategory(option,definition);const grouped=category+'|'+key,item=services.get(grouped)||{name:option.name||key,quantity:0,people:0,category};item.quantity+=Number(option.quantity||0);item.people+=option.people??(Number(option.quantity)>0?1:0);services.set(grouped,item);}
        if(services.size){const labels=Object.fromEntries(participantOptionGroups);const grouped=[...services.values()].reduce((all,service)=>{(all[service.category]??=[]).push(service);return all;},{});content.querySelector('[data-list]').insertAdjacentHTML('beforebegin','<div data-person-services>'+participantOptionGroups.filter(([category])=>grouped[category]?.length).map(([category])=>'<h4>'+esc(labels[category])+'</h4><ul>'+grouped[category].map(service=>'<li>'+esc(service.name)+': '+service.people+' '+(service.people===1?'persona':'persone')+'</li>').join('')+'</ul>').join('')+'</div>');}
        const orderServices=new Map();for(const option of data.order_service_totals||data.items.filter(x=>['CONFIRMED','PENDING_PAYMENT'].includes(x.status)).flatMap(order=>order.order_options||[])){const key=option.code||option.name;const item=orderServices.get(key)||{name:option.name||key,quantity:0,orders:0};item.quantity+=Number(option.quantity||0);item.orders+=option.orders??(Number(option.quantity)>0?1:0);orderServices.set(key,item);}
        if(orderServices.size)content.querySelector('[data-list]').insertAdjacentHTML('beforebegin','<details data-order-services><summary>Servizi acquistati per prenotazione</summary><ul>'+[...orderServices].map(([key,service])=>'<li>'+esc(service.name)+': '+service.quantity+' unità</li>').join('')+'</ul><p>Le quantità sono conteggiate una volta per prenotazione e non attribuite ai singoli partecipanti.</p></details>');
        const allServices=new Map();for(const option of data.service_filters||data.people.flatMap(person=>person.options||[]))allServices.set(option.code||option.name,{name:option.name||option.code});
        serviceFilter.closest('label').hidden=allServices.size===0;
        for(const [key,service] of [...allServices].sort((a,b)=>String(a[1].name).localeCompare(String(b[1].name),'it',{sensitivity:'base'}))){const option=document.createElement('option');option.value=key;option.textContent=service.name;serviceFilter.append(option);}serviceFilter.value=listContext.service;
        const offersCount=metrics?metrics.offers:data.items.filter(x=>x.status==='WAITLIST_OFFERED').length;
        if(offersCount){
          const offerPanel=document.createElement('details');offerPanel.dataset.offerPanel='';offerPanel.innerHTML='<summary>Posti proposti e scadenze ('+offersCount+' prenotazioni)</summary><p>Il termine trascorso non equivale a un annullamento già eseguito: lo stato viene aggiornato dal processo automatico.</p>';content.querySelector('[data-list]').before(offerPanel);
          lazyPanel(offerPanel,async()=>{const result=await loadPanel('offers');if(ticket!==generation)return;offerPanel.insertAdjacentHTML('beforeend','<ul>'+result.offers.map(x=>'<li>'+esc(x.name)+' · '+esc(x.code)+' · '+esc(deadlineLabel(x.offer_expires_at))+' <button data-open="'+esc(x.code)+'">Apri prenotazione</button></li>').join('')+'</ul>');});
        }
        const columns=[['name','Partecipante'],['status','Stato'],['email','Email'],['phone','Telefono'],['future_events','eventi futuri']];
        if(features.rooms)columns.push(['room','Camera']);
        if(metrics?metrics.has_missing:data.items.some(row=>Number(row.missing)>0))columns.push(['missing','Dati mancanti']);
        if(metrics?metrics.has_requests:data.items.some(row=>String(row.requests||'').trim()))columns.push(['requests','Richieste particolari']);
        if(offersCount)columns.push(['offer_expires_at','Scadenza posto proposto (ora locale)']);
        if(metrics?metrics.has_attendance:(data.people||[]).some(row=>['PRESENT','ABSENT'].includes(row.attendance?.state||row.attendance)))columns.push(['attendance','Presenza effettiva']);
        const extraKeys=new Set(data.field_keys||(data.people||[]).flatMap(p=>Object.keys(p.fields||{})));for(const key of extraKeys){const label=data.field_labels?.[key]||'',contactField=/\b(e-?mail|posta elettronica|telefono|cellulare|cell\.)\b/i.test(label)||/^(participant_)?(e?mail|phone|mobile|telefono|cellulare)/i.test(key);if(/^[a-z][a-z0-9_]{0,79}$/.test(key)&&label&&(!contactField||key.startsWith('custom_')))columns.push(['field:'+key,label]);}
        const questionLabels=new Map(columns.filter(([key])=>key.startsWith('field:custom_')).map(([key],index)=>[key,'D'+(index+1)]));
        const reportLabel=(key,label)=>key==='future_events'?'futuri':questionLabels.get(key)||label;
        let savedReportColumns=[],hasSavedReportColumns=false;try{const saved=localStorage.getItem('mi-report-columns:'+event);hasSavedReportColumns=saved!==null;savedReportColumns=JSON.parse(saved||'[]');if(!Array.isArray(savedReportColumns)){savedReportColumns=[];hasSavedReportColumns=false;}}catch(error){savedReportColumns=[];hasSavedReportColumns=false;}
        content.querySelector('[data-list]').insertAdjacentHTML('afterend','<section data-participant-reports><header class="mi-report-heading"><h3>Rapporti partecipanti</h3></header><details data-export-settings><summary>Scegli i dati del rapporto</summary><div class="mi-report-columns">'+columns.map(([key,label])=>'<label><input type="checkbox" data-export-column="'+esc(key)+'" '+(!hasSavedReportColumns||savedReportColumns.includes(key)?'checked':'')+'> '+esc(questionLabels.has(key)?questionLabels.get(key)+' — '+label:label)+'</label>').join('')+'</div></details><div class="mi-booking-detail__actions" data-report-actions><button data-export><span class="mi-action-icon mi-action-icon--excel" aria-hidden="true">▦</span><span>Esporta Excel</span></button></div></section>');
        content.querySelectorAll('[data-export-column]').forEach(input=>input.addEventListener('change',()=>{try{localStorage.setItem('mi-report-columns:'+event,JSON.stringify([...content.querySelectorAll('[data-export-column]:checked')].map(item=>item.dataset.exportColumn)));}catch(error){/* La scelta resta valida per la sessione corrente. */}}));
        if(printButton){printButton.innerHTML='<svg class="mi-action-icon mi-action-icon--print" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 9V3h12v6M6 17H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v7H6z"/></svg><span>Stampa</span>';content.querySelector('[data-report-actions]').prepend(printButton);}
        if(!features.rooms&&listContext.sort==='room')listContext.sort='name';
        const searchBar=document.createElement('div');searchBar.className='mi-management-search mi-search-order-row';searchBar.append(search.closest('label'),content.querySelector('[data-clear-query]'));content.querySelector('[data-list]').before(searchBar);
        const participantHeading=document.createElement('h3');participantHeading.dataset.participantHeading='';participantHeading.innerHTML='<span class="mi-participant-heading-label">Elenco partecipanti</span><span class="mi-participant-count" data-participant-count></span>';
        const listHost=content.querySelector('[data-list]');
        listHost.before(participantHeading);
        const filterSection=document.createElement('section');filterSection.dataset.participantFilters='';filterSection.innerHTML='<header class="mi-filter-heading"><h3>Filtra</h3></header><div class="mi-participant-filters"></div>';participantHeading.before(filterSection);
        const filterControls=filterSection.querySelector('div');filterControls.append(searchBar,depositFilter.closest('label'),criticalFilter.closest('label'),serviceFilter.closest('label'),requestFilter.closest('label'),deadlineFilter.closest('label'));
        const closedLabel=document.createElement('label');closedLabel.className='mi-include-closed';
        const closedToggle=document.createElement('input');closedToggle.type='checkbox';closedToggle.checked=!!listContext.includeClosed;closedToggle.dataset.includeClosed='';closedLabel.append(closedToggle,' Mostra anche le iscrizioni chiuse');filterSection.append(closedLabel);
        const advancedFilters=document.createElement('details');advancedFilters.className='mi-advanced-filters';
        advancedFilters.innerHTML='<summary><svg class="mi-filter-icon" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 5h16l-6 7v5l-4 2v-7z"/></svg><span>Filtri</span><span data-filter-count></span></summary>';
        filterControls.before(searchBar,advancedFilters);advancedFilters.append(filterControls,closedLabel);
        const activeFilterCount=()=>[listContext.filter&&listContext.filter!=='all',listContext.deposit,listContext.service,listContext.requests,listContext.deadline,listContext.includeClosed].filter(Boolean).length;
        advancedFilters.open=false;
        closedToggle.onchange=()=>{listContext.includeClosed=closedToggle.checked;listContext.shown=30;draw();};
        if(data.attendance_availability?.available){
          if(metrics?metrics.admitted:data.people.some(person=>['CONFIRMED','PENDING_PAYMENT'].includes(person.status))){const attendancePanel=document.createElement('details');attendancePanel.dataset.attendancePanel='';attendancePanel.innerHTML='<summary>Registra presenze</summary>';listHost.after(attendancePanel);lazyPanel(attendancePanel,async()=>{const result=await loadPanel('attendance');if(ticket!==generation)return;const attendancePeople=result.people;attendancePanel.innerHTML='<summary>Registra presenze</summary><p>Seleziona le persone da aggiornare, imposta lo stato e salva tutte le modifiche insieme.</p><div class="mi-attendance-actions"><button type="button" data-attendance-select-all>Seleziona tutti</button><button type="button" data-attendance-clear-all>Deseleziona tutti</button></div><form data-attendance-bulk><div class="mi-attendance-table" role="region" aria-label="Registrazione presenze"><table><thead><tr><th scope="col">Seleziona</th><th scope="col">Partecipante</th><th scope="col">Presenza</th></tr></thead><tbody>'+attendancePeople.map(person=>'<tr><td><input type="checkbox" data-attendance-person="'+person.id+'" aria-label="Seleziona '+esc(person.name)+'"></td><td>'+esc(person.name)+'</td><td><select data-attendance-state aria-label="Presenza di '+esc(person.name)+'">'+[['UNRECORDED','Non rilevata'],['PRESENT','Presente'],['ABSENT','Assente']].map(([value,label])=>'<option value="'+value+'" '+((person.attendance?.state||person.attendance||'UNRECORDED')===value?'selected':'')+'>'+label+'</option>').join('')+'</select></td></tr>').join('')+'</tbody></table></div><button type="submit" class="mi-primary">Salva presenze selezionate</button></form>';listHost.after(attendancePanel);attendancePanel.querySelector('[data-attendance-select-all]').onclick=()=>attendancePanel.querySelectorAll('[data-attendance-person]').forEach(input=>input.checked=true);attendancePanel.querySelector('[data-attendance-clear-all]').onclick=()=>attendancePanel.querySelectorAll('[data-attendance-person]').forEach(input=>input.checked=false);attendancePanel.querySelector('form').onsubmit=async e=>{e.preventDefault();const changes=[...attendancePanel.querySelectorAll('[data-attendance-person]:checked')].map(input=>({id:Number(input.dataset.attendancePerson),attendance:input.closest('tr').querySelector('[data-attendance-state]').value}));if(!changes.length){say('Seleziona almeno una persona.');return;}busy=true;attendancePanel.querySelectorAll('button,input,select').forEach(control=>control.disabled=true);say('Salvataggio presenze…');try{const result=await request('attendance_bulk',{data:JSON.stringify(changes)});busy=false;dirty=false;dirtyForm=null;await summary();say(result.message);}catch(error){say('Presenze non salvate. '+error.message);}finally{busy=false;attendancePanel.querySelectorAll('button,input,select').forEach(control=>control.disabled=false);}};});}
        }
        search.closest('label').firstChild.textContent='Cerca nome ';serviceFilter.closest('label').firstChild.textContent='Servizio scelto';
        const searchButton=document.createElement('button');searchButton.type='button';searchButton.dataset.runQuery='';searchButton.textContent='Cerca';searchBar.append(searchButton);
        const filterButton=document.createElement('button');filterButton.type='button';filterButton.dataset.toggleFilters='';
        filterButton.innerHTML=advancedFilters.querySelector('summary').innerHTML;
        advancedFilters.querySelector('summary').hidden=true;
        advancedFilters.id='mi-participant-filters-'+requestId();filterButton.setAttribute('aria-controls',advancedFilters.id);
        const syncFilterButton=()=>filterButton.setAttribute('aria-expanded',String(advancedFilters.open));
        filterButton.onclick=()=>{advancedFilters.open=!advancedFilters.open;syncFilterButton();};
        advancedFilters.addEventListener('toggle',syncFilterButton);syncFilterButton();searchBar.append(filterButton);
        const clearSearch=content.querySelector('[data-clear-query]');clearSearch.type='button';clearSearch.textContent='×';clearSearch.setAttribute('aria-label','Cancella ricerca');clearSearch.title='Cancella ricerca';
        const searchInputWrap=document.createElement('span');searchInputWrap.className='mi-search-input';search.before(searchInputWrap);searchInputWrap.append(search,clearSearch);
        const searchStatus=document.createElement('span');searchStatus.setAttribute('role','status');searchStatus.setAttribute('aria-live','polite');filterSection.querySelector('header').append(searchStatus);
        if(features.rooms){
          const roomSection=document.createElement('details');roomSection.dataset.roomSection='';roomSection.innerHTML='<summary><span class="mi-room-section-icon" aria-hidden="true">🛏️</span><span class="mi-room-section-copy"><strong>Gestione camere</strong><small>Assegna o modifica le camere</small></span><span class="mi-room-section-chevron" aria-hidden="true">⌄</span></summary>';const attendancePanel=content.querySelector('[data-attendance-panel]');(attendancePanel||listHost).after(roomSection);
          lazyPanel(roomSection,async()=>{
            const result=await loadPanel('rooms');if(ticket!==generation)return;
            roomPeople=result.people;admitted=roomPeople.filter(p=>['CONFIRMED','PENDING_PAYMENT'].includes(p.status));rooms=result.rooms||[];data.room_types=result.room_types||{};booking={version:result.rooms_version||''};
            renderRoomPanels();
          const planner=content.querySelector('[data-room-planner]');if(planner){planner.querySelector('h3')?.remove();roomSection.append(planner);}
          for(const selector of ['[data-room-inventory]','[data-room-occupants]']){const panel=content.querySelector(selector);if(panel&&!panel.hidden)roomSection.append(panel);}
          });
        }
        const servicePanels=[...content.querySelectorAll('[data-person-services],[data-order-services]')];
        if(servicePanels.length){const serviceSection=document.createElement('details');serviceSection.dataset.serviceSummary='';serviceSection.innerHTML='<summary>Riepilogo servizi richiesti</summary><p>Per modificare i servizi (colazione, assicurazione, pullman…), vai su <strong>Gestisci → Varia servizi e sistemazione</strong>; per l’alloggio, su <strong>Gestione camere → Cambia tipo di abitazione</strong>.</p>';content.querySelector('[data-participant-reports]').append(serviceSection);servicePanels.forEach(panel=>serviceSection.append(panel));}
        let exportRows=[],pageRows=[],pageTotal=0,pageFingerprint='',listGeneration=0;
        const readAll=async()=>{
          if(!data.server_paging)return exportRows;
          const context=JSON.stringify(listContext),result=[];let fingerprint='';
          do{const page=await request('list_page',{context,offset:result.length,limit:200});
            if(ticket!==generation||context!==JSON.stringify(listContext))throw new Error('La selezione è cambiata. Ripeti l’operazione.');
            if(fingerprint&&fingerprint!==page.fingerprint)throw new Error('I dati sono cambiati durante la lettura. Aggiorna e ripeti l’operazione.');
            fingerprint=page.fingerprint;result.push(...page.rows);
            if(result.length>=page.total)return result;
            if(!page.rows.length)throw new Error('Lettura incompleta. Riprova.');
          }while(true);
        };
        content.querySelector('[data-export]').onclick=async()=>{
          try { exportRows=await readAll();
          const individual=listContext.view==='people',selected=individual?columns.filter(([key])=>content.querySelector('[data-export-column="'+key+'"]').checked):[['code','Prenotazione'],['name','Persone'],['status','Stato'],['paid','Versato netto (EUR)'],['balance','Residuo (EUR)']];
          if(!selected.length){say('Seleziona almeno una colonna.');return;}
          const rows=[selected.map(([key,label])=>reportLabel(key,label)),...exportRows.map(row=>selected.map(([key])=>key==='name'?row.name:key==='future_events'?(row.future_events||'Non rilevato'):key.startsWith('field:')?(row.fields?.[key.slice(6)]??''):key==='attendance'?({PRESENT:'Presente',ABSENT:'Assente',UNRECORDED:'Non rilevata'}[row.attendance?.state||row.attendance]||'Non rilevata'):key==='status'?stateLabel(row):key==='offer_expires_at'?deadlineLabel(row[key]):['paid','balance'].includes(key)?Number(row[key])/100:Array.isArray(row[key])?row[key].join(', '):row[key]))];
          const url=URL.createObjectURL(reportWorkbook(rows));const link=document.createElement('a');link.href=url;link.download='evento-'+event+'-'+(individual?'partecipanti':'prenotazioni')+'.xlsx';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);say('Esportati '+exportRows.length+' risultati filtrati.');
          }catch(error){say('Esportazione non completata. '+error.message);}
        };
        const sortMenu=registrationSortMenu(listContext.sort,key=>{listContext.sort=key;saveRegistrationSort(key);listContext.direction=key==='created_at'?'desc':'asc';listContext.shown=30;draw();});searchBar.append(sortMenu);
        const draw=async(append=false,provided=null)=>{
          sortMenu.sync(listContext.sort);
          const revision=++listGeneration;
          const activeCount=activeFilterCount();filterButton.querySelector('[data-filter-count]').textContent=activeCount?'('+activeCount+')':'';
          if(data.server_paging){
            try{
              if(provided){pageRows=provided.rows;pageTotal=provided.total;}
              else{
                const wanted=append?pageRows.length:listContext.shown-30;
                // Anche gli elenchi ripristinati vengono caricati in pagine limitate.
                let rows=append?pageRows:[],fingerprint=append?pageFingerprint:'';
                do{const response=await request('list_page',{context:JSON.stringify(listContext),offset:rows.length,limit:30});
                  if(revision!==listGeneration||ticket!==generation)return;
                  if(fingerprint&&fingerprint!==response.fingerprint)throw new Error('I dati sono cambiati. Aggiorna il riepilogo per continuare.');
                  fingerprint=response.fingerprint;rows=rows.concat(response.rows);pageTotal=response.total;
                  if(!response.rows.length||rows.length>=pageTotal)break;
                }while(rows.length<=wanted);
                pageRows=rows;pageFingerprint=fingerprint;
              }
            }catch(error){if(revision===listGeneration&&ticket===generation)say('Lista non disponibile. '+error.message);return;}
          }
          const query=listContext.query.trim().toLocaleLowerCase('it'),filter=listContext.filter;
          const matches=p=>(p.name+' '+p.buyer+' '+p.code+' '+p.email+' '+p.phone).toLocaleLowerCase('it').includes(query);
          const open=p=>!['CANCELLED','EXPIRED'].includes(p.status);
          const depositMatch=x=>!listContext.deposit||((x.totals_known??x.economics_known??true)!==false&&['CONFIRMED','PENDING_PAYMENT'].includes(x.status)&&(listContext.deposit==='none'?x.paid<=0&&x.balance>0:listContext.deposit==='partial'?x.paid>0&&x.deposit_missing>0&&x.balance>0:listContext.deposit==='covered'?x.deposit_covered&&x.balance>0:listContext.deposit==='settled'?x.balance<=0:x.balance>0));
          const people=(data.people||[]).filter(p=>(listContext.includeClosed||['CANCELLED','EXPIRED'].includes(listContext.state)||open(p))&&depositMatch(p)&&personLogistics(p)&&deadlineMatch(p)&&requestMatch(p)&&(!listContext.state||p.status===listContext.state)&&matches(p)&&(filter==='all'||(open(p)&&(filter==='balance'?p.collectible:filter==='missing'?(p.missing||[]).length>0:p.unassigned))));
          const orders=data.items.filter(x=>(listContext.includeClosed||['CANCELLED','EXPIRED'].includes(listContext.state)||open(x))&&depositMatch(x)&&(!listContext.orderService||(x.order_options||[]).some(o=>(o.code||o.name)===listContext.orderService&&Number(o.quantity)>0))&&deadlineMatch(x)&&requestMatch(x)&&(!(listContext.room||listContext.service)||(data.people||[]).some(p=>p.code===x.code&&personLogistics(p)))&&(!listContext.state||x.status===listContext.state)&&(filter==='all'||(x.active&&x[filter]>0&&(filter!=='balance'||(x.collectible??['CONFIRMED','PENDING_PAYMENT'].includes(x.status)))))&&((x.name+' '+x.code).toLocaleLowerCase('it').includes(query)||(data.people||[]).some(p=>p.code===x.code&&matches(p))));
          const individual=listContext.view==='people',all=data.server_paging?pageRows:(individual?people:orders).sort((a,b)=>listContext.sort==='created_at'?((listContext.direction==='asc'?1:-1)*(String(a.created_at||'').localeCompare(String(b.created_at||''))||(Number(a.registration_id||0)-Number(b.registration_id||0)))||(Number(a.id||0)-Number(b.id||0))):((Number(!open(a))-Number(!open(b)))||(listContext.direction==='desc'?-1:1)*String(a[listContext.sort]||'').localeCompare(String(b[listContext.sort]||''),'it',{numeric:true,sensitivity:'base'}))),list=data.server_paging?all:all.slice(0,listContext.shown),total=data.server_paging?pageTotal:all.length;
          exportRows=all;
          const titleParts=[];
          if(filter==='unassigned')titleParts.push('senza camera assegnata');
          if(filter==='missing')titleParts.push('con dati mancanti');
          const paymentTitle={none:'senza versamenti',partial:'con caparra da completare',covered:'con caparra versata e saldo atteso',settled:'con saldo versato',unpaid:'con pagamento da completare'}[listContext.deposit];
          if(paymentTitle)titleParts.push(paymentTitle);
          if(listContext.requests)titleParts.push(listContext.requests==='pending'?'con richieste particolari da verificare':listContext.requests==='reviewed'?'con richieste particolari verificate':'con richieste particolari');
          if(listContext.deadline)titleParts.push(listContext.deadline==='expired'?'con proposta di posto scaduta':'con proposta di posto in scadenza');
          if(listContext.service)titleParts.push('che hanno scelto '+(serviceFilter.selectedOptions[0]?.textContent||listContext.service));
          if(listContext.query.trim())titleParts.push('per la ricerca «'+listContext.query.trim()+'»');
          participantHeading.querySelector('.mi-participant-heading-label').textContent='Elenco partecipanti'+(titleParts.length?' '+titleParts.join(', '):'');
          participantHeading.querySelector('[data-participant-count]').textContent=String(total)+' '+(individual?(total===1?'persona':'persone'):(total===1?'prenotazione':'prenotazioni'));
          searchStatus.textContent='';
          const requestedRoomCode=person=>{
            const selected=(person.options||[]).find(option=>Number(option.quantity||0)>0&&data.room_types?.[option.code]);
            return selected?data.room_types[selected.code].prefix+'-':'';
          };
          const showParticipantStatus=individual&&list.some(person=>stateLabel(person)!=='Partecipante');
          content.querySelector('[data-list]').innerHTML='<table><thead><tr>'+(individual?'<th class="mi-progressive-number">N.</th>'+(features.rooms?'<th class="mi-participant-room-code">Stanza</th>':'')+'<th class="mi-participant-name">Partecipante</th>'+(showParticipantStatus?'<th class="mi-participant-status">Stato</th>':'')+'<th class="mi-participant-contacts-cell">Contatti</th><th class="mi-participant-missing">Dati mancanti</th>':'<th>Prenotazione</th><th>Persone nella prenotazione</th><th>Stato</th><th>Versato</th><th>Residuo</th><th class="mi-participant-actions"></th>')+'</tr></thead><tbody>'+list.map((x,index)=>(individual?'<tr class="mi-participant-row" data-open="'+esc(x.code)+'" data-person-focus="'+x.number+'" tabindex="0" aria-label="Apri la scheda di '+esc(x.name)+'"><td class="mi-progressive-number">'+(index+1)+'</td>'+(features.rooms?'<td class="mi-participant-room-code">'+esc(x.room||requestedRoomCode(x)||'—')+'</td>':'')+'<td class="mi-participant-name"><span class="mi-participant-open-label">'+esc(x.name)+' <span class="mi-participant-chevron" aria-hidden="true">›</span></span></td>'+(showParticipantStatus?'<td class="mi-participant-status"><span class="mi-status-pill mi-status-pill--'+stateClass(x)+'">'+esc(stateLabel(x))+'</span></td>':'')+'<td class="mi-participant-contacts-cell">'+emailContact(x.email)+'<br>'+esc(x.phone)+'</td><td class="mi-participant-missing">'+(x.missing.length?'Mancano: '+esc(x.missing.join(', ')):'')+'</td></tr>':'<tr><td>'+esc(x.code)+'</td><td>'+esc(x.name)+(data.people||[]).filter(p=>p.code===x.code).map(p=>'<div>'+esc(p.name)+(p.status==='CANCELLED'?' (annullato)':'')+'</div>').join('')+'</td><td><span class="mi-status-pill mi-status-pill--'+stateClass(x)+'">'+esc(stateLabel(x))+'</span></td><td>'+money(x.paid)+'</td><td>'+money(x.balance)+(x.deposit_plan?'<small>'+esc(depositText(x))+'</small>':'')+'</td><td class="mi-participant-actions"><button data-open="'+esc(x.code)+'">Gestisci</button></td></tr>')).join('')+'</tbody></table>'+(total>list.length?'<button data-more>Mostra altre 30</button>':'')+(all.length===0?'<p>Nessun risultato. Modifica la ricerca o i filtri.</p>':'');
          const participantStatusIndex=features.rooms?3:2,participantContactsIndex=participantStatusIndex+(showParticipantStatus?1:0),participantMissingIndex=participantContactsIndex+1;
          const showMissing=individual&&list.some(p=>(p.missing||[]).length);
          if(individual){
            content.querySelectorAll('[data-list] tbody tr').forEach((row,index)=>row.classList.toggle('mi-closed-registration',!open(list[index])));
            const missingIndex=participantMissingIndex;content.querySelector('[data-list] th:nth-child('+(missingIndex+1)+')').hidden=!showMissing;
            content.querySelectorAll('[data-list] tbody tr').forEach((row,index)=>{
              const person=list[index],missing=[...(person.missing||[])];
              if(missing.length){const attention=document.createElement('small');attention.className='mi-row-attention';attention.textContent=missing.join(' · ');row.querySelector('.mi-participant-name').append(attention);}
              row.cells[missingIndex].textContent=missing.join(', ');row.cells[missingIndex].hidden=!showMissing;
            });
          }
          if(individual){
            content.querySelector('[data-list] table').classList.add('mi-participant-table');
            content.querySelectorAll('[data-list] tbody tr').forEach((row,index)=>{
              row.cells[participantContactsIndex].innerHTML='<div class="mi-participant-contacts">'+phoneContact(list[index].phone)+emailContact(list[index].email)+'</div>';
            });
          }
          if(individual && data.attendance_availability?.available){
            const table=content.querySelector('[data-list] table');
            const statusIndex=participantStatusIndex,headerRow=table.tHead.rows[0],statusHeading=showParticipantStatus?headerRow.cells[statusIndex]:null,statusAnchor=headerRow.cells[statusIndex];
            const heading=document.createElement('th');heading.scope='col';heading.className='mi-attendance-cell';heading.textContent='Presente';headerRow.insertBefore(heading,statusAnchor);if(statusHeading)headerRow.append(statusHeading);
            [...table.tBodies[0].rows].forEach((row,index)=>{
              const person=list[index],statusCell=showParticipantStatus?row.cells[statusIndex]:null,cell=row.insertCell(statusIndex);cell.className='mi-attendance-cell';if(statusCell)row.append(statusCell);
              if(!['CONFIRMED','PENDING_PAYMENT'].includes(person.status))return;
              const input=document.createElement('input');input.type='checkbox';input.dataset.attendanceToggle=person.id;input.setAttribute('aria-label','Presente: '+person.name);
              input.checked=(person.attendance?.state||person.attendance)==='PRESENT';cell.append(input);
              input.onchange=async()=>{const previous=!input.checked,state=input.checked?'PRESENT':'ABSENT';input.disabled=true;
                try{await request('attendance_bulk',{data:JSON.stringify([{id:person.id,attendance:state}])});person.attendance=state;const compact=(data.people||[]).find(p=>p.id===person.id);if(compact)compact.attendance=state;const bulk=content.querySelector('[data-attendance-person="'+person.id+'"]');if(bulk&&!bulk.checked)bulk.closest('tr').querySelector('[data-attendance-state]').value=state;pageFingerprint='';say('Presenza salvata. Il foglio verrà aggiornato.');}
                catch(error){input.checked=previous;say('Presenza non salvata. '+error.message);}finally{input.disabled=false;}
              };
            });
          }
          if(!features.payments&&!individual){content.querySelectorAll('[data-list] tr').forEach(row=>{row.children[3].hidden=true;row.children[4].hidden=true;});}
          const more=content.querySelector('[data-more]');if(more)more.onclick=()=>{listContext.shown+=30;draw(true);};
          criticalFilter.value=filter;
          for(const [index,key,label] of [[features.rooms?2:1,'name','Partecipante'],...(features.rooms?[[1,'room','Stanza']]:[])]){
            const header=content.querySelectorAll('[data-list] thead th')[index];
            const selected=listContext.sort===key,descending=selected&&listContext.direction==='desc';
            header.classList.add('mi-sortable-heading');
            header.setAttribute('aria-sort',selected?(descending?'descending':'ascending'):'none');
            header.innerHTML='<button type="button" data-sort-column="'+key+'">'+label+' <span aria-hidden="true">'+(selected?(descending?'↓':'↑'):'↕')+'</span></button>';
            header.querySelector('button').onclick=async()=>{listContext.direction=selected&&!descending?'desc':'asc';listContext.sort=key;listContext.shown=30;await draw();content.querySelector('[data-sort-column="'+key+'"]')?.focus();};
          }
          if(all.length===0)content.querySelector('[data-list]>p:last-child')?.classList.add('mi-list-empty');
          listResize?.disconnect();
          if(list.length>10){
            const table=content.querySelector('[data-list] table'),shell=document.createElement('div'),viewport=document.createElement('div'),bottomHint=document.createElement('span'),sideHint=document.createElement('span');
            shell.className='mi-participant-scroll-shell';bottomHint.className='mi-scroll-hint mi-scroll-hint--bottom';sideHint.className='mi-scroll-hint mi-scroll-hint--side';bottomHint.setAttribute('aria-hidden','true');sideHint.setAttribute('aria-hidden','true');
            viewport.className='mi-participant-scroll';viewport.tabIndex=0;viewport.setAttribute('role','region');viewport.setAttribute('aria-label','Elenco partecipanti, scorri per vedere le altre righe');
            table.before(shell);shell.append(viewport,bottomHint,sideHint);viewport.append(table);
            const updateHints=()=>{const tolerance=2;bottomHint.hidden=viewport.scrollHeight-viewport.scrollTop-viewport.clientHeight<=tolerance;sideHint.hidden=viewport.scrollWidth-viewport.scrollLeft-viewport.clientWidth<=tolerance;};
            const fitRows=()=>{if(!table.isConnected){listResize?.disconnect();return;}const tenth=table.tBodies[0].rows[9];viewport.style.maxHeight=Math.ceil(tenth.getBoundingClientRect().bottom-table.getBoundingClientRect().top+2)+'px';updateHints();};
            viewport.addEventListener('scroll',updateHints,{passive:true});fitRows();listResize=new ResizeObserver(fitRows);listResize.observe(table);listResize.observe(viewport);
          }
        };
        criticalFilter.onchange=()=>{listContext.filter=criticalFilter.value;listContext.shown=30;draw();};
        let searchTimer;
        const runSearch=()=>{clearTimeout(searchTimer);listContext.query=search.value;listContext.shown=30;searchStatus.textContent='Ricerca in corso…';return draw();};
        content.querySelector('[data-clear-query]').onclick=()=>{search.value='';listContext.orderService='';runSearch();search.focus();};
        search.oninput=()=>{clearTimeout(searchTimer);++listGeneration;searchStatus.textContent='Ricerca in corso…';searchTimer=setTimeout(()=>{if(ticket===generation)runSearch();},200);};
        search.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();runSearch();}};
        searchButton.onclick=runSearch;

        requestFilter.onchange=()=>{listContext.requests=requestFilter.value;listContext.shown=30;draw();};deadlineFilter.onchange=()=>{listContext.deadline=deadlineFilter.value;listContext.shown=30;draw();};serviceFilter.onchange=()=>{listContext.service=serviceFilter.value;listContext.shown=30;draw();};
        await draw();printList=async()=>{let printHost;const cleanup=()=>{printHost?.remove();root.classList.remove('mi-printing-list');document.body.classList.remove('mi-management-printing');};try{
          const individual=listContext.view==='people',chosen=individual?columns.filter(([key])=>content.querySelector('[data-export-column="'+key+'"]').checked):[],selected=individual?[['ordinal','N.'],...(features.rooms?[['room','Stanza']]:[]),...chosen.filter(([key])=>key!=='room')]:[['code','Prenotazione'],['name','Persone'],['status','Stato'],['paid','Versato netto (EUR)'],['balance','Residuo (EUR)']];
          if(!selected.length){say('Seleziona almeno una colonna.');return;}
          const rows=await readAll();printHost=document.createElement('section');printHost.dataset.printList='1';
          const value=(row,key,index)=>key==='ordinal'?index+1:key==='name'?row.name:key==='future_events'?(row.future_events||'Non rilevato'):key.startsWith('field:')?(row.fields?.[key.slice(6)]??''):key==='attendance'?({PRESENT:'Presente',ABSENT:'Assente',UNRECORDED:'Non rilevata'}[row.attendance?.state||row.attendance]||'Non rilevata'):key==='status'?stateLabel(row):key==='offer_expires_at'?deadlineLabel(row[key]):['paid','balance'].includes(key)?money(row[key]):Array.isArray(row[key])?row[key].join(', '):row[key];
          const filters=[listContext.query?'Ricerca: '+listContext.query:'',...['[data-deposit-filter]','[data-request-filter]','[data-deadline-filter]','[data-service-filter]'].map(selector=>{const input=content.querySelector(selector);return input.value?input.selectedOptions[0].textContent:'';}),listContext.filter!=='all'?criticalFilter.selectedOptions[0].textContent:'',listContext.orderService?orderServices.get(listContext.orderService)?.name:''].filter(Boolean);
          printHost.innerHTML='<h2>'+esc(select.selectedOptions[0]?.textContent||'Evento')+'</h2><p>'+rows.length+' '+(individual?'persone':'prenotazioni')+' · '+esc(filters.join(' · ')||'Tutti i risultati')+'</p><table><thead><tr>'+selected.map(([key,label])=>'<th>'+esc(reportLabel(key,label))+'</th>').join('')+'</tr></thead><tbody>'+rows.map((row,index)=>'<tr>'+selected.map(([key])=>'<td>'+esc(value(row,key,index))+'</td>').join('')+'</tr>').join('')+'</tbody></table>';root.append(printHost);root.classList.add('mi-printing-list');document.body.classList.add('mi-management-printing');window.addEventListener('afterprint',cleanup,{once:true});window.print();
        }catch(error){cleanup();say('Stampa non completata. '+error.message);}};say('Aggiornato: '+new Date(data.updated_at).toLocaleString('it-IT'));updateSheetSyncVisibility(ticket,event);
      }catch(e){if(ticket===generation)say('Riepilogo non disponibile. '+e.message);}
    }
    async function syncSheet(){
      if(!await canLeave())return;if(!event){await allPeople();return;}
      const ticket=++generation;busy=true;select.disabled=true;parkPanels();content.replaceChildren();say('Lettura delle modifiche nel foglio Google…');
      try{
        const result=await request('sheet_changes');if(ticket!==generation)return;
        if(result.errors?.length){say(result.errors.join(' '));return;}
        const changes=result.changes||[];
        if(!changes.length){say('Il foglio non contiene modifiche da sincronizzare.');return;}
        content.innerHTML=`<h3>Modifiche dal foglio Google</h3><p>${changes.length} celle da sincronizzare. In caso di conflitto nessuna modifica verrà applicata.</p><table><thead><tr><th>Prenotazione</th><th>Partecipante</th><th>Campo</th><th>Prima</th><th>Dopo</th></tr></thead><tbody>${changes.map(c=>`<tr><td>${esc(c.order_code)}</td><td>${esc(c.number)}</td><td>${esc(c.key)}</td><td>${esc(c.before)}</td><td>${esc(c.after)}</td></tr>`).join('')}</tbody></table><button type="button" data-apply-sheet>Sincronizza ${changes.length} celle</button>`;
        const button=content.querySelector('[data-apply-sheet]');
        button.onclick=async()=>{
          if(busy)return;busy=true;button.disabled=true;select.disabled=true;
          pending=pending||{operation:'sheet_save',data:JSON.stringify(changes),request_id:requestId()};say('Sincronizzazione…');
          try{
            const saved=await request('sheet_save',pending);
            if(saved.ack_pending)throw new Error(saved.message);
            if(saved.saved===false){if(saved.rejected){pending=null;say(saved.message);button.textContent='Rileggi le modifiche';button.onclick=syncSheet;return;}throw new Error(saved.message);}
            pending=null;busy=false;await summary();say(saved.message+' Il foglio si aggiornerà dopo la replica.');
          }catch(error){say(error.message);button.textContent='Riprova la stessa sincronizzazione';}
          finally{busy=false;button.disabled=false;select.disabled=false;}
        };
        say('Controlla le modifiche e premi Sincronizza.');
      }catch(error){say('Foglio non disponibile. '+error.message);}
      finally{busy=false;select.disabled=false;}
    }
    function optionsText(options){return (Array.isArray(options)?options:[]).map(o=>esc(o.name||o.code||'Opzione')+' × '+esc(o.quantity??1)).join(' · ')||'Nessuna';}
    const participantOptionGroups=[['alloggio','Alloggio'],['supplemento','Supplementi'],['trasferimento','Trasferimenti'],['pranzo','Pasti'],['altro','Altro']];
    function participantOptionCategory(option,definition={}){
      const code=String(option.code||definition.code||''),name=String(option.name||definition.name||''),category=String(definition.category||'');
      if(code.startsWith('alloggio-')||category==='alloggio')return 'alloggio';
      if(code==='colazione'||code.startsWith('assicurazione-')||/assicurazione/i.test(name)||category==='supplemento')return 'supplemento';
      if(code.startsWith('pullman')||['pullman','trasferimento'].includes(category))return 'trasferimento';
      if(code==='pranzo'||category==='pranzo')return 'pranzo';
      return 'altro';
    }
    function participantOptionsGroups(options,definitions=[]){
      const definitionByCode=new Map(definitions.map(definition=>[definition.code,definition]));
      const grouped=(Array.isArray(options)?options:[]).filter(option=>Number(option.quantity??1)>0).reduce((all,option)=>{const category=participantOptionCategory(option,definitionByCode.get(option.code));(all[category]??=[]).push(option);return all;},{});
      return participantOptionGroups.filter(([category])=>grouped[category]?.length).map(([category,label])=>'<section class="mi-person-option-group" data-person-option-group="'+category+'"><h4>'+label+'</h4><p>'+grouped[category].map(option=>esc(String(option.name||option.code||'Opzione').replace(/\s*[—–]\s*/g,' - '))).join(' · ')+'</p></section>').join('');
    }
    function optionChangeText(change){
      const before=new Map((change?.before_options||[]).map(option=>[option.code||option.name,option]));
      const after=new Map((change?.after_options||[]).map(option=>[option.code||option.name,option]));
      return [...new Set([...before.keys(),...after.keys()])].map(code=>{const oldOption=before.get(code)||{},newOption=after.get(code)||{},oldQuantity=Number(oldOption.quantity||0),newQuantity=Number(newOption.quantity||0),name=newOption.name||oldOption.name||code;if(oldQuantity===newQuantity)return '';if(!oldQuantity)return 'Aggiunto: '+esc(name)+(newQuantity>1?' ('+newQuantity+')':'');if(!newQuantity)return 'Rimosso: '+esc(name);return esc(name)+': '+oldQuantity+' → '+newQuantity;}).filter(Boolean).join(' · ');
    }
    function input(key,label,value,type='text'){return `<label>${esc(label)}<input name="${esc(key)}" value="${esc(value)}" type="${['email','date','number','tel'].includes(type)?type:'text'}" maxlength="1000"></label>`;}
    function fieldInput(f,value){
      const name='field:'+f.key,label=f.label;
      if(['select','yesno'].includes(f.type)){const options=f.options||[];const choices=options.includes(value)||!value?options:[value,...options];return '<label>'+esc(label)+'<select name="'+esc(name)+'"><option value="">Non indicato</option>'+choices.map(v=>'<option value="'+esc(v)+'" '+(String(v)===String(value)?'selected':'')+'>'+esc(v)+'</option>').join('')+'</select></label>';}
      if(f.type==='textarea')return '<label>'+esc(label)+'<textarea name="'+esc(name)+'" maxlength="1000">'+esc(value)+'</textarea></label>';
      return input(name,label,value,f.type);
    }
    async function detail(code,personNumber){
      updateEventContext();
      if(!await canLeave())return;const ticket=++generation;if(order!==code)currentPerson=null;order=code;personNumber=personNumber??currentPerson;say('Caricamento scheda…');
      try{const b=await request('detail');if(ticket!==generation)return;booking=b;printList=null;parkPanels();dirty=false;select.disabled=false;const selectedPerson=b.participants.find(p=>p.number===Number(personNumber))||b.participants[0];currentPerson=selectedPerson?.number??null;document.title=(selectedPerson?personName(selectedPerson):'Iscritto')+' — Scheda iscritto';
        if(printButton){printButton.hidden=false;printButton.textContent='Stampa riepilogo prenotazione';}
        content.innerHTML='<p class="mi-detail-back"><button type="button" data-back>Vai a Elenco partecipanti</button></p><div data-booking-print></div><h3>'+(selectedPerson?esc(personName(selectedPerson)):'Scheda iscritto')+'</h3><p data-person-contact></p><div data-person-intro-end></div>';
        const position=b.individual,personEconomics=position?.people?.find(p=>p.id===selectedPerson?.id);
        const economics=p=>!p?'<p>Importi individuali non disponibili.</p>':'<dl><div><dt>Quota</dt><dd>'+(position.quotes_known?money(p.total):'Da verificare')+'</dd></div><div><dt>Versato</dt><dd>'+(position.payments_known?money(p.paid):'Da attribuire')+'</dd></div><div><dt>'+(p.credit?'Credito da restituire':'Residuo')+'</dt><dd>'+(position.quotes_known&&position.payments_known?money(p.credit||p.balance):'Da verificare')+'</dd></div></dl>';
        if(!b.is_free_event)content.querySelector('[data-person-intro-end]').insertAdjacentHTML('beforebegin','<section class="mi-person-economic" aria-label="Importi personali">'+economics(personEconomics)+(position?.message?'<p>'+esc(position.message)+'</p>':'')+'</section>');
        const personalBalances=position?.people?.reduce((sum,p)=>sum+p.balance,0)||0,personalCredits=position?.people?.reduce((sum,p)=>sum+(p.credit||0),0)||0;
        const bookingOverview='<details class="mi-booking-overview" data-booking-overview><summary>Vedi tutta la prenotazione</summary><h4>'+esc(b.event_title)+'</h4>'+b.participants.map(p=>'<section><h4><button type="button" data-open="'+esc(b.order_code)+'" data-person-focus="'+p.number+'">'+esc(personName(p))+'</button>'+(p.status==='CANCELLED'?' · Annullata':'')+'</h4>'+participantOptionsGroups(p.options,b.option_definitions)+(b.features?.rooms?'<p>Camera assegnata: '+esc(p.room||'Da assegnare')+'</p>':'')+(!b.is_free_event?economics(position?.people?.find(row=>row.id===p.id)):'')+'</section>').join('')+((b.order_options||[]).length?'<h4>Servizi della prenotazione</h4>'+participantOptionsGroups(b.order_options,b.option_definitions):'')+(!b.is_free_event?'<section class="mi-booking-totals"><h4>Totali della prenotazione</h4><p>Quota '+money(b.total_cents)+' · Versato '+money(b.paid_cents)+' · '+(position?.quotes_known&&position?.payments_known?'Residui individuali '+money(personalBalances)+(personalCredits?' · Crediti da restituire '+money(personalCredits):''):'Residuo netto '+money(b.balance_cents))+'</p></section>':'')+'</details>';
        content.querySelector('[data-person-intro-end]').insertAdjacentHTML('beforebegin',bookingOverview);
        if(selectedPerson){
          const contact=content.querySelector('[data-person-contact]');
          const personal=b.fields.filter(f=>['participant_email','email','participant_phone','phone','mobile'].includes(f.key));
          const contacts=personal.map(f=>selectedPerson.fields?.[f.key]).filter(Boolean);contact.textContent='Contatti dell’iscritto: '+(contacts.join(' · ')||(selectedPerson.number===1?[b.buyer.email,b.buyer.phone].filter(Boolean).join(' · '):'Non indicati'));
          const companions=b.participants.filter(p=>p.id!==selectedPerson.id&&p.status==='ACTIVE').map(personName);if(companions.length)contact.insertAdjacentHTML('afterend','<p>Iscritto insieme con <strong>'+esc(new Intl.ListFormat('it',{style:'long',type:'conjunction'}).format(companions))+'</strong>.</p>');
        }
        if(b.can_adjust_due&&['CONFIRMED','PENDING_PAYMENT','CANCELLED','EXPIRED'].includes(b.status)){
          const adjustmentForm=b.can_adjust_due?'<details><summary>Rettifica il dovuto della prenotazione</summary><form data-adjust-due><label>Persona<select name="participant_id" required>'+b.participants.map(p=>'<option value="'+p.id+'">'+esc(p.first_name+' '+p.last_name)+'</option>').join('')+'</select></label><label>Nuovo totale della prenotazione<input name="total" inputmode="decimal" required></label><label>Motivo<textarea name="reason" required maxlength="500"></textarea></label><button>Verifica e salva rettifica</button></form></details>':'';
          content.insertAdjacentHTML('beforeend',adjustmentForm);
        }
        if(b.can_change_options&&['CONFIRMED','PENDING_PAYMENT'].includes(b.status)&&(b.option_definitions||[]).length){
          const optionForm=(id,title,scope,selected)=>{const definitions=b.option_definitions.filter(o=>o.scope===scope&&!Object.prototype.hasOwnProperty.call(b.room_types||{},o.code));const person=scope==='TICKET'?b.participants.find(p=>p.id===id):null;
          const types=person?b.option_definitions.filter(o=>o.scope==='TICKET'&&b.room_types?.[o.code]):[];
          const currentType=(person?.options||[]).find(o=>Number(o.quantity)>0&&b.room_types?.[o.code])?.code||'';
          const assignment=person? (types.length?'<label>Tipo di alloggio<select name="accommodation_type"><option value="">Nessun alloggio</option>'+types.map(o=>'<option value="'+esc(o.code)+'" '+(o.code===currentType?'selected':'')+'>'+esc(o.name)+'</option>').join('')+'</select></label><label>Camera<select name="room"><option value="">Da assegnare</option><option value="__AUTO__">Crea una nuova camera adatta</option>'+(b.accommodations||[]).map(r=>'<option value="'+esc(r.code)+'" '+(r.code===person.room?'selected':'')+'>'+esc(r.name||r.code)+' ('+Number(r.available)+' posti liberi)</option>').join('')+'</select></label>':'')+(b.bus_assignment_enabled?input('bus','Pullman assegnato',person.fields?.pullman||''):''):'';
          if(!definitions.length&&!assignment)return '';const grouped=definitions.reduce((all,definition)=>{const category=participantOptionCategory(definition,definition);(all[category]??=[]).push(definition);return all;},{});const fields=participantOptionGroups.filter(([category])=>grouped[category]?.length).map(([category,label])=>'<fieldset class="mi-person-option-group" data-person-option-group="'+category+'"><legend>'+label+'</legend>'+grouped[category].map(o=>'<label>'+esc(o.name)+(scope==='TICKET'&&Number(o.max_quantity??1)<=1?'<input type="checkbox" name="option:'+esc(o.code)+'" value="1" '+(Number((selected||[]).find(item=>item.code===o.code)?.quantity||0)>0?'checked':'')+'>':'<input type="number" min="0" max="'+Number(o.max_quantity??1)+'" step="1" name="option:'+esc(o.code)+'" value="'+Number((selected||[]).find(item=>item.code===o.code)?.quantity||0)+'">')+'</label>').join('')+'</fieldset>').join('');return '<form data-change-options="'+id+'"><h4>'+esc(title)+'</h4>'+fields+assignment+'<button type="submit">Verifica e salva servizi</button></form>';};
          content.insertAdjacentHTML('beforeend',optionForm(0,'Servizi comuni della prenotazione','ORDER',b.order_options));
          const serviceForms=selectedPerson&&selectedPerson.status==='ACTIVE'?optionForm(selectedPerson.id,'Servizi di '+personName(selectedPerson),'TICKET',selectedPerson.options):'';
          if(serviceForms)content.insertAdjacentHTML('beforeend','<details data-person-services-editor><summary>Varia servizi e sistemazione</summary><p>Modifica servizi, tipo di alloggio e assegnazioni insieme. Prima di salvare vedrai la nuova quota. Incassi e rimborsi si registrano separatamente.</p>'+serviceForms+'</details>');
        }
        const optionHistory=(b.option_changes||[]).filter(entry=>Number(entry.change?.participant_id)===Number(selectedPerson?.id)).map(entry=>({entry,changes:optionChangeText(entry.change)})).filter(item=>item.changes);
        if(optionHistory.length)content.insertAdjacentHTML('beforeend','<details><summary>Storico variazioni servizi</summary><ul>'+optionHistory.map(({entry,changes})=>'<li>'+changes+(entry.change.reason?' · '+esc(entry.change.reason):'')+' · '+esc(entry.actor_label)+' · '+esc(entry.created_at)+' UTC</li>').join('')+'</ul></details>');
        for(const p of selectedPerson?[selectedPerson]:[]){const definitions=new Map(b.fields.map(f=>[f.key,f]));Object.keys(p.fields).forEach(k=>{if(k==='pullman'&&!b.bus_assignment_enabled)return;if(!definitions.has(k))definitions.set(k,{key:k,label:k});});
          const selectedOptionGroups=participantOptionsGroups(p.options,b.option_definitions);
          const selectedOptions=selectedOptionGroups?`<div class="mi-person-options" aria-label="Servizi e sistemazioni scelti">${selectedOptionGroups}</div>`:'';
          const roomStatus=b.features?.rooms?'<p>Stanza: <strong>'+esc(p.room||'—')+'</strong></p>':'';
          content.insertAdjacentHTML('beforeend',`<form data-person="${p.number}" novalidate><fieldset ${p.status==='CANCELLED'?'disabled':''}><legend>Dati dell’iscritto</legend>${roomStatus}${selectedOptions}<div class="mi-management-grid">${input('first_name','Nome',p.first_name)}${input('last_name','Cognome',p.last_name)}${[...definitions.values()].map(f=>fieldInput(f,p.fields[f.key]??'')).join('')}</div><p>Per rimuovere un dato facoltativo, svuota il campo e salva.</p><button type="submit">Salva iscritto</button> <button class="mi-danger" type="button" data-cancel="${p.id}">Annulla partecipazione</button></fieldset></form>`);
        }
        const personForm=content.querySelector('form[data-person]'),introEnd=content.querySelector('[data-person-intro-end]'),serviceEditor=content.querySelector('[data-person-services-editor]');if(personForm&&introEnd){introEnd.after(personForm);if(serviceEditor)personForm.after(serviceEditor);}
        const printFallback=content.querySelector('[data-booking-print]');
        if(personForm){
          const fieldset=personForm.querySelector('fieldset'),save=fieldset.querySelector('button[type="submit"]'),cancel=fieldset.querySelector('[data-cancel]');
          const actions=document.createElement('div');actions.className='mi-person-actions';
          save.disabled=fieldset.disabled;cancel.disabled=fieldset.disabled;
          actions.append(save);if(printButton)actions.append(printButton);actions.append(cancel);personForm.append(actions);printFallback.remove();
          personalBaselines.set(personForm,personalValues(personForm));save.hidden=true;
        }else if(printButton)printFallback.append(printButton);
        content.insertAdjacentHTML('beforeend','<p class="mi-detail-back"><button type="button" data-back>Vai a Elenco partecipanti</button></p>');
        if(personNumber){const person=content.querySelector('[data-person="'+Number(personNumber)+'"]');person?.scrollIntoView({block:'center'});person?.querySelector('input')?.focus();}
        say('');if(b.pending){pending=b.pending;say('Un salvataggio interrotto può essere completato.');const resume=document.createElement('button');resume.textContent='Completa il salvataggio interrotto';resume.onclick=()=>mutate(pending.operation,JSON.parse(pending.data));status.append(' ',resume);}
      }catch(e){if(ticket===generation)say('Scheda non disponibile. '+e.message);}
    }
    async function mutate(operation,data){
      if(busy)return;busy=true;
      root.querySelectorAll('button,input,select,textarea').forEach(el=>{el.dataset.wasDisabled=el.disabled?'1':'0';el.disabled=true;});
      pending=pending||{operation,data:JSON.stringify(data),version:booking.version,request_id:requestId()};say('Salvataggio…');
      try{const result=await request(pending.operation,pending);if(result.saved===false){if(result.rejected){pending=null;say(result.message);return;}throw new Error(result.message);}pending=null;dirty=false;dirtyForm=null;busy=false;if(order)await detail(order);else await summary();say(result.message||'Modifica salvata.');}
      catch(e){say('Salvataggio non confermato: '+e.message);const retry=document.createElement('button');retry.textContent='Riprova lo stesso salvataggio';retry.onclick=()=>mutate(operation,data);status.append(' ',retry);const reload=document.createElement('button');reload.textContent='Ricarica la scheda';reload.onclick=async()=>{if(!await ask('Ricaricare i dati? Le modifiche non salvate verranno perse.','Ricarica la scheda'))return;pending=null;dirty=false;if(order)detail(order);else summary();};status.append(' ',reload);}
      finally{busy=false;select.disabled=false;root.querySelectorAll('[data-was-disabled]').forEach(el=>{el.disabled=el.dataset.wasDisabled==='1';delete el.dataset.wasDisabled;});}
    }
    content.addEventListener('submit',async e=>{if(e.target.closest('[data-mi-payments]'))return;e.preventDefault();const f=e.target;const invalid=[...f.elements].find(x=>x.willValidate&&!x.validity.valid);if(invalid){const closed=invalid.closest('details');if(closed)closed.open=true;invalid.setAttribute('aria-invalid','true');say('Controlla il formato del campo evidenziato.');invalid.focus();return;}const values=Object.fromEntries(new FormData(f));if(f.hasAttribute('data-change-options')){const options={};f.querySelectorAll('input[type=checkbox][name^="option:"]').forEach(el=>options[el.name.slice(7)]=el.checked?1:0);for(const [key,value]of Object.entries(values))if(key.startsWith('option:'))options[key.slice(7)]=Number(value);const change={participant_id:Number(f.dataset.changeOptions),options,reason:''};for(const key of ['accommodation_type','room','bus'])if(Object.hasOwn(values,key))change[key]=values[key];if(f.dataset.sharesReady){change.allocations={};for(const el of f.querySelectorAll('[data-share]'))change.allocations[el.dataset.share]=Math.round(Number(el.value.replace(',','.'))*100);}const button=f.querySelector('button[type=submit]');button.disabled=true;f.inert=true;busy=true;try{const preview=await request('options_preview',{data:JSON.stringify(change),version:booking.version});if(change.participant_id===0&&preview.allocations){
const fields=booking.participants.map(person=>'<label>'+esc(person.first_name+' '+person.last_name)+'<input data-share="'+person.id+'" inputmode="decimal" value="'+(Number(preview.allocations[person.id]||0)/100).toFixed(2)+'" required></label>').join('');
let editor=f.querySelector('[data-common-shares]');if(!editor){editor=document.createElement('fieldset');editor.dataset.commonShares='';f.querySelector('button').before(editor);}editor.innerHTML='<legend>Ripartizione dei servizi comuni</legend><p>Proposta in parti uguali. Modifica gli importi e conferma nuovamente.</p>'+fields;
if(!f.dataset.sharesReady){f.dataset.sharesReady='1';return;}
change.allocations={};for(const el of f.querySelectorAll('[data-share]'))change.allocations[el.dataset.share]=Math.round(Number(el.value.replace(',','.'))*100);
}
const assignmentText=preview.assignment&&Object.keys(preview.assignment).length?'Camera: '+(preview.assignment.room||'da assegnare')+'. Pullman: '+(preview.assignment.bus||'non assegnato')+'. ':'';
const message=assignmentText+(preview.before_total!==null?'Quota personale: '+money(preview.before_total)+' → '+money(preview.after_total)+'. ':'Variazione: '+money(preview.delta)+'. ')+(preview.credit>0?'Credito da restituire: '+money(preview.credit)+'. ':'')+(change.participant_id===0?'Ripartizione: '+booking.participants.map(p=>p.first_name+' '+p.last_name+': '+money(preview.allocations[p.id]||0)).join('; ')+'. ':'')+'La modifica riguarda soltanto questa iscrizione. Salvare?';if(await ask(message,'Salva servizi')){button.disabled=false;busy=false;await mutate('change_options',change);}}catch(error){say('Verifica non disponibile. '+error.message);}finally{button.disabled=false;f.inert=false;busy=false;}}else if(f.hasAttribute('data-identity')){try{const target=await request('identity_preview',{target_order:values.target_order,target_number:values.target_number});if(await ask('Confermi che '+target.first_name+' '+target.last_name+' è la stessa persona di questa iscrizione?','Conferma collegamento'))mutate('identity_link',{participant_id:Number(f.dataset.identity),target_id:Number(target.id),target_order:values.target_order,target_number:Number(values.target_number)});}catch(error){say(error.message);}}else if(f.hasAttribute('data-adjust-due')){const cents=Math.round(Number(values.total.replace(',','.'))*100);ask('Confermi il nuovo totale di '+money(cents)+'? Incassi e rimborsi restano invariati.','Salva rettifica').then(ok=>{if(ok)mutate('adjust_due',{total_cents:cents,reason:values.reason,participant_id:Number(values.participant_id)});});}else if(f.hasAttribute('data-attendance')){mutate('attendance',{participant_id:Number(f.dataset.attendance),attendance:values.attendance});}else if(f.hasAttribute('data-request-review')){mutate('request_review',{reviewed:f.elements.namedItem('reviewed').checked});}else if(f.hasAttribute('data-person')){const fields={};for(const [k,v]of Object.entries(values))if(k.startsWith('field:'))fields[k.slice(6)]=v;mutate('participant',{number:Number(f.dataset.person),first_name:values.first_name,last_name:values.last_name,room:values.room,fields});}else if(f.hasAttribute('data-room'))mutate(order?'room_save':'event_room_save',{...values,capacity:Number(values.capacity)});});
    content.addEventListener('click',async e=>{const b=e.target.closest('button,.mi-participant-row[data-open],.mi-all-person[data-open]');if(!b||busy||pending)return;if(b.matches('.mi-participant-row,.mi-all-person')&&e.target.closest('a,button,input,select,textarea,label'))return;if(dirty&&(b.dataset.cancel||b.dataset.deleteRoom)){say('Salva le modifiche oppure scartale con Aggiorna riepilogo prima di annullare o eliminare.');return;}if(b.closest('[data-mi-payments]'))return;if(b.dataset.unlink){if(dirty){say('Salva o scarta la bozza prima di rimuovere il collegamento.');return;}if(await ask('Rimuovere questo collegamento personale dal rapporto annuale?','Rimuovi collegamento'))mutate('identity_link',{participant_id:Number(b.dataset.unlink),target_id:0});}if(b.dataset.open){if(b.dataset.openEvent){if(!await canLeave())return;returnEvent=event;event=b.dataset.openEvent;select.value=event;}detail(b.dataset.open,b.dataset.personFocus);}if(b.hasAttribute('data-back')){if(!await canLeave())return;event=returnEvent;select.value=event;summary();}if(b.dataset.deleteRoom&&await ask('Eliminare la camera '+b.dataset.deleteRoom+'? La camera è vuota.','Elimina camera'))mutate(order?'room_delete':'event_room_delete',{code:b.dataset.deleteRoom});if(b.dataset.cancel&&await ask('Annullare la partecipazione?'+(booking?.is_free_event?'':' L’annullamento non riduce automaticamente gli importi: verifica il dovuto ed eventualmente usa «Rettifica il dovuto». Eventuali rimborsi si registrano separatamente.'),'Annulla partecipazione')){busy=true;b.disabled=true;try{const result=await request('cancel',{participant_id:b.dataset.cancel});dirty=false;busy=false;await detail(order);say(result.message);}catch(err){say(err.message);}finally{busy=false;b.disabled=false;}}});
    content.addEventListener('keydown',e=>{const row=e.target.closest('.mi-participant-row[data-open],.mi-all-person[data-open]');if(!row||e.target!==row||!['Enter',' '].includes(e.key))return;e.preventDefault();row.click();});
    select.onchange=async()=>{const next=select.value;if(!await canLeave()){select.value=event;return;}event=next;updateLocation();summary();};root.querySelector('[data-refresh]').onclick=()=>order?detail(order):summary();root.querySelector('[data-print]').onclick=()=>{if(printList){printList();return;}root.querySelectorAll('.mi-print-value').forEach(el=>el.remove());root.querySelectorAll('form input,form select,form textarea').forEach(el=>{const span=document.createElement('span');span.className='mi-print-value';span.textContent=el.tagName==='SELECT'?(el.selectedOptions[0]?.textContent||''):el.value;el.after(span);});document.body.classList.add('mi-management-printing');window.addEventListener('afterprint',()=>document.body.classList.remove('mi-management-printing'),{once:true});window.print();};
    // Aggiorna il contesto visibile dopo la conclusione del controllo su bozze e annullamenti.
    for(const control of [select,periodSelect])if(control?.onchange){const change=control.onchange;control.onchange=async function(...args){try{return await change.apply(this,args);}finally{updateEventContext();}};}
    if(eventActions?.dataset.sheetAuto==='1'&&event)syncSheet();else if(order&&event)detail(order);else summary();
  }
  const scan=()=>{document.querySelectorAll('[data-mi-management]').forEach(init);document.querySelectorAll('[data-group-attendance]').forEach(initGroupAttendance);};
  document.addEventListener('DOMContentLoaded',()=>{scan();new MutationObserver(scan).observe(document.body,{childList:true,subtree:true});});
})();
