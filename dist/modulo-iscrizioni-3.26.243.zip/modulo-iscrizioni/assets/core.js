(function (target) {
  'use strict';

  function clampQuantity(value, maximum) {
    const parsed = Number.parseInt(value, 10);
    return Number.isFinite(parsed) ? Math.max(0, Math.min(Number(maximum) || 20, parsed)) : 0;
  }

  function normalizeSelection(inputs) {
    const result = {};
    Object.entries(inputs || {}).forEach(([code, entry]) => {
      result[String(code)] = clampQuantity(entry.value, entry.max);
    });
    return result;
  }

  function sumQuantities(selection) {
    return Object.values(selection || {}).reduce((sum, value) => sum + clampQuantity(value, 20), 0);
  }

  function normalizePhone(value) {
    const trimmed = String(value || '').trim();
    const digits = trimmed.replace(/\D/g, '');
    if (/^3\d{9}$/.test(digits) && !trimmed.startsWith('+')) {
      return `+39 ${digits.slice(0, 3)} ${digits.slice(3)}`;
    }
    if (/^(?:39|0039)3\d{9}$/.test(digits) && !trimmed.startsWith('+')) {
      const italianMobile = digits.startsWith('0039') ? digits.slice(4) : digits.slice(2);
      return `+39 ${italianMobile.slice(0, 3)} ${italianMobile.slice(3)}`;
    }
    return trimmed;
  }

  function isValidPhone(value) {
    return /^\+[1-9][0-9().\s-]{6,30}$/.test(normalizePhone(value));
  }

  target.MIRegistrationCore = Object.freeze({ clampQuantity, normalizeSelection, sumQuantities, normalizePhone, isValidPhone });
}(globalThis));
