(function () {
  'use strict';

  const groupCoverButton = document.querySelector('[data-mi-group-cover]');
  if (groupCoverButton && window.wp?.media) {
    const field = document.getElementById('mi_group_cover_image_id');
    const preview = document.querySelector('[data-mi-group-cover-preview]');
    const remove = document.querySelector('[data-mi-group-cover-remove]');
    groupCoverButton.addEventListener('click', () => {
      const frame = window.wp.media({ title: 'Scegli immagine del gruppo', button: { text: 'Usa questa immagine' }, multiple: false, library: { type: 'image' } });
      frame.on('select', () => {
        const attachment = frame.state().get('selection').first().toJSON();
        field.value = attachment.id;
        preview.innerHTML = `<img src="${attachment.sizes?.medium?.url || attachment.url}" alt="" style="max-width:100%;height:auto">`;
      });
      frame.open();
    });
    remove?.addEventListener('click', () => { field.value = ''; preview.textContent = 'Nessuna immagine predefinita.'; });
  }

  const saveDraftButton = document.getElementById('save-post');
  if (saveDraftButton) {
    saveDraftButton.setAttribute('formnovalidate', 'formnovalidate');
  }

  const profileSelect = document.getElementById('mi_data_profile');
  const fieldConfig = document.querySelector('.mi-field-config[data-mi-profiles]');
  const fieldPreview = document.querySelector('[data-mi-field-preview]');
  if (profileSelect && fieldConfig && fieldPreview) {
    const profiles = JSON.parse(fieldConfig.dataset.miProfiles || '{}');
    const items = Array.from(fieldConfig.querySelectorAll('[data-mi-field]'));

    const refreshFields = () => {
      fieldPreview.replaceChildren();
      const base = document.createElement('li');
      base.textContent = 'Nome e cognome — obbligatori';
      fieldPreview.append(base);
      items.forEach((item) => {
        const enabled = item.querySelector('[data-mi-field-enabled]');
        const required = item.querySelector('[data-mi-field-required]');
        required.disabled = !enabled.checked;
        if (!enabled.checked) required.checked = false;
        item.classList.toggle('is-disabled', !enabled.checked);
        if (enabled.checked) {
          const line = document.createElement('li');
          line.textContent = `${item.querySelector('strong').textContent} — ${required.checked ? 'obbligatorio' : 'facoltativo'}`;
          fieldPreview.append(line);
        }
      });
    };

    profileSelect.addEventListener('change', () => {
      const profile = profiles[profileSelect.value];
      if (!profile || profileSelect.value === 'CUSTOM') return;
      items.forEach((item) => {
        const key = item.dataset.miField;
        item.querySelector('[data-mi-field-enabled]').checked = profile.enabled.includes(key);
        item.querySelector('[data-mi-field-required]').checked = profile.required.includes(key);
      });
      refreshFields();
    });

    fieldConfig.addEventListener('change', () => {
      profileSelect.value = 'CUSTOM';
      refreshFields();
    });
    refreshFields();
  }

  const anteprimaEmail = document.querySelector('[data-mi-email-preview]');
  if (anteprimaEmail) {
    const valoriEsempio = JSON.parse(anteprimaEmail.dataset.miEmailValues || '{}');
    const campiEmail = Array.from(document.querySelectorAll('#mi_email_subject, #mi_email_preheader, #mi_email_html, #mi_email_text, #mi_email_footer'));
    const segnapostoAmmessi = Object.keys(valoriEsempio);
    const risolviSegnaposto = (testo) => segnapostoAmmessi.reduce((risultato, segnaposto) => risultato.split(segnaposto).join(valoriEsempio[segnaposto]), testo);
    const aggiornaAnteprimaEmail = () => {
      const sconosciuti = new Set();
      campiEmail.forEach((campo) => {
        const trovati = campo.value.match(/{{[^{}]+}}/g) || [];
        trovati.filter((voce) => !segnapostoAmmessi.includes(voce)).forEach((voce) => sconosciuti.add(voce));
      });
      campiEmail.forEach((campo) => campo.setCustomValidity(sconosciuti.size ? 'Rimuovi i segnaposto non ammessi.' : ''));
      anteprimaEmail.querySelector('[data-mi-email-preview-subject]').textContent = risolviSegnaposto(document.getElementById('mi_email_subject').value);
      anteprimaEmail.querySelector('[data-mi-email-preview-preheader]').textContent = risolviSegnaposto(document.getElementById('mi_email_preheader').value);
      anteprimaEmail.querySelector('[data-mi-email-preview-text]').textContent = risolviSegnaposto(document.getElementById('mi_email_text').value);
      anteprimaEmail.querySelector('[data-mi-email-preview-footer]').textContent = risolviSegnaposto(document.getElementById('mi_email_footer').value);
      const errore = anteprimaEmail.querySelector('[data-mi-email-placeholder-error]');
      errore.hidden = sconosciuti.size === 0;
      errore.textContent = sconosciuti.size ? `Segnaposto non ammessi: ${Array.from(sconosciuti).join(', ')}` : '';
    };
    campiEmail.forEach((campo) => campo.addEventListener('input', aggiornaAnteprimaEmail));
    aggiornaAnteprimaEmail();
  }

  const bookingLinks = Array.from(document.querySelectorAll('[data-mi-booking-open]'));
  if (bookingLinks.length) {
    const listUrl = new URL(window.location.href);
    listUrl.searchParams.delete('registration_id');
    const modal = document.createElement('div');
    modal.className = 'mi-booking-modal';
    modal.hidden = true;
    modal.innerHTML = '<div class="mi-booking-modal__backdrop" data-mi-booking-close></div><section class="mi-booking-modal__dialog" role="dialog" aria-modal="true" aria-label="Scheda prenotazione"><button type="button" class="mi-booking-modal__close" data-mi-booking-close aria-label="Chiudi la scheda">×</button><div class="mi-booking-modal__content" aria-live="polite"></div></section>';
    document.body.append(modal);
    const content = modal.querySelector('.mi-booking-modal__content');
    const closeButton = modal.querySelector('.mi-booking-modal__close');
    let previousFocus = null;
    let activeRequest = null;

    const closeBooking = (replaceHistory = true) => {
      if (modal.hidden) return;
      activeRequest?.abort();
      activeRequest = null;
      modal.hidden = true;
      content.replaceChildren();
      document.body.classList.remove('mi-booking-modal-open');
      if (replaceHistory) window.history.replaceState({}, '', listUrl);
      previousFocus?.focus();
    };
    const openBooking = async (link) => {
      activeRequest?.abort();
      const request = new AbortController();
      activeRequest = request;
      previousFocus = link;
      modal.hidden = false;
      document.body.classList.add('mi-booking-modal-open');
      content.innerHTML = '<p class="mi-booking-modal__loading">Apertura della prenotazione…</p>';
      closeButton.focus();
      try {
        const response = await fetch(link.href, { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: request.signal });
        if (!response.ok) throw new Error('detail_unavailable');
        const documentDetail = new DOMParser().parseFromString(await response.text(), 'text/html');
        const detail = documentDetail.getElementById('mi-booking-detail');
        if (!detail) throw new Error('detail_missing');
        detail.querySelector('[data-mi-booking-close]')?.remove();
        content.replaceChildren(detail);
        window.history.pushState({}, '', link.href);
      } catch (error) {
        if ('AbortError' === error.name) return;
        window.location.assign(link.href);
      } finally {
        if (activeRequest === request) activeRequest = null;
      }
    };
    bookingLinks.forEach((link) => link.addEventListener('click', (event) => {
      if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
      openBooking(link);
    }));
    modal.addEventListener('click', (event) => {
      if (event.target.closest('[data-mi-booking-close]')) closeBooking();
    });
    document.addEventListener('keydown', (event) => {
      if ('Escape' === event.key && !modal.hidden) closeBooking();
      if ('Tab' === event.key && !modal.hidden) {
        const focusable = Array.from(modal.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])')).filter((element) => !element.hidden && null !== element.offsetParent);
        if (!focusable.length) { event.preventDefault(); closeButton.focus(); return; }
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    });
    window.addEventListener('popstate', () => closeBooking(false));
  }

  const modalitaEconomica = document.getElementById('mi_economic_mode');
  const modalitaPrezzo = document.getElementById('mi_pricing_mode');
  const riquadroCaparra = document.querySelector('[data-mi-economic-deposit]');
  const modalitaCaparra = document.getElementById('mi_deposit_mode');
  const riquadroCaparraPercentuale = document.querySelector('[data-mi-deposit-percentage]');
  const riquadroCaparraFissa = document.querySelector('[data-mi-deposit-fixed]');
  const riquadroPagamenti = document.querySelector('[data-mi-economic-payments]');
	const riquadroPrezzoFisso = document.querySelector('[data-mi-fixed-price]');
  const aiutoEconomico = document.querySelector('[data-mi-economic-help]');
  if (modalitaEconomica && modalitaPrezzo && riquadroCaparra && riquadroPagamenti && aiutoEconomico) {
    const aggiornaConfigurazioneEconomica = () => {
      const modalita = modalitaEconomica.value;
      const incassa = ['FULL_PAYMENT', 'DEPOSIT_BALANCE'].includes(modalita);
	  const prezzoCoerente = modalita === 'REGISTRATION_ONLY' ? ['NONE', 'ZERO'].includes(modalitaPrezzo.value) : ['FIXED', 'CALCULATED'].includes(modalitaPrezzo.value);
	  if (riquadroPrezzoFisso) {
		riquadroPrezzoFisso.hidden = modalitaPrezzo.value !== 'FIXED';
		const campoPrezzoFisso = riquadroPrezzoFisso.querySelector('input');
		if (campoPrezzoFisso) { campoPrezzoFisso.required = modalitaPrezzo.value === 'FIXED'; campoPrezzoFisso.disabled = modalitaPrezzo.value !== 'FIXED'; }
	  }
      riquadroCaparra.hidden = modalita !== 'DEPOSIT_BALANCE';
	  const caparraFissa = modalitaCaparra?.value === 'FIXED';
	  if (riquadroCaparraPercentuale) {
		riquadroCaparraPercentuale.hidden = caparraFissa;
		const campo = riquadroCaparraPercentuale.querySelector('input');
		if (campo) { campo.disabled = modalita !== 'DEPOSIT_BALANCE' || caparraFissa; campo.required = modalita === 'DEPOSIT_BALANCE' && !caparraFissa; }
	  }
	  if (riquadroCaparraFissa) {
		riquadroCaparraFissa.hidden = !caparraFissa;
		const campo = riquadroCaparraFissa.querySelector('input');
		if (campo) { campo.disabled = modalita !== 'DEPOSIT_BALANCE' || !caparraFissa; campo.required = modalita === 'DEPOSIT_BALANCE' && caparraFissa; }
	  }
      riquadroPagamenti.hidden = !incassa;
      Array.from(riquadroPagamenti.querySelectorAll('input')).forEach((campo) => { campo.disabled = !incassa; });
	  modalitaPrezzo.setCustomValidity(prezzoCoerente ? '' : modalita === 'REGISTRATION_ONLY' ? 'Per la sola iscrizione scegli “Nessun prezzo” oppure “Gratuito”.' : 'Seleziona una quota uguale per tutti oppure prezzi diversi secondo la tipologia.');
	  aiutoEconomico.textContent = modalita === 'REGISTRATION_ONLY' ? (modalitaPrezzo.value === 'ZERO' ? 'L’evento è dichiarato esplicitamente gratuito.' : 'Il modulo raccoglie soltanto le iscrizioni senza dichiarare un prezzo.') : modalita === 'PRICE_ONLY' ? 'Il prezzo viene mostrato, ma non vengono richieste fonti di pagamento.' : modalita === 'FULL_PAYMENT' ? 'È richiesto il versamento dell’intero importo tramite almeno una fonte ammessa.' : `Sono previsti ${caparraFissa ? 'un importo fisso di caparra' : 'una caparra percentuale'} e il successivo saldo.`;
    };
    modalitaEconomica.addEventListener('change', aggiornaConfigurazioneEconomica);
    modalitaPrezzo.addEventListener('change', aggiornaConfigurazioneEconomica);
	modalitaCaparra?.addEventListener('change', aggiornaConfigurazioneEconomica);
    aggiornaConfigurazioneEconomica();
  }

  function labelConfigTable(table) {
    const headers = [...table.querySelectorAll('thead th')].map(th => th.textContent.trim());
    [...table.tBodies[0].rows].forEach((row, index) => {
      const title = row.cells[1]?.querySelector('input')?.value.trim() || row.cells[0]?.querySelector('input')?.value.trim() || 'riga ' + (index + 1);
      [...row.cells].forEach((cell, column) => cell.querySelectorAll('input:not([type="hidden"]),select').forEach(input => input.setAttribute('aria-label', headers[column] + ' — ' + title)));
      row.querySelector('button')?.setAttribute('aria-label', 'Rimuovi ' + title);
    });
  }
  document.querySelectorAll('#mi-ticket-types,#mi-options,#mi-custom-fields').forEach(table => {
    labelConfigTable(table);
    table.addEventListener('input', () => labelConfigTable(table));
    new MutationObserver(() => labelConfigTable(table)).observe(table.tBodies[0], {childList:true});
  });
  const table = document.getElementById('mi-ticket-types');
  const addButton = document.getElementById('mi-add-ticket');
  if (!table || !addButton) return;

  addButton.addEventListener('click', () => {
    const row = document.createElement('tr');
    row.innerHTML = '<td><input name="mi_ticket_code[]" pattern="[a-z0-9-]+" required></td><td><input name="mi_ticket_name[]" required></td><td><input name="mi_ticket_price[]" type="number" min="0" step="0.01" value="0.00" required></td><td><input name="mi_ticket_max[]" type="number" min="1" max="20" value="5" required></td><td><input name="mi_ticket_capacity[]" type="number" min="0" max="10000" value="0"><small>0 = capienza evento</small></td><td><button type="button" class="button mi-remove-ticket">Rimuovi</button></td>';
    table.tBodies[0].append(row);
    row.querySelector('input').focus();
  });

  const optionTable = document.querySelector('#mi-options tbody');
  document.querySelector('#mi-add-option')?.addEventListener('click', () => {
    const row = document.createElement('tr');
    row.innerHTML = '<td><input name="mi_option_code[]" pattern="[a-z0-9-]+" required></td><td><input name="mi_option_name[]" required></td><td><select name="mi_option_scope[]"><option value="ORDER">Ordine</option><option value="TICKET">Partecipante</option></select></td><td><input name="mi_option_price[]" type="number" min="0" step="0.01" value="0.00"></td><td><input name="mi_option_max[]" type="number" min="1" max="20" value="1"></td><td><button type="button" class="button mi-remove-option">Rimuovi</button></td>';
    optionTable?.append(row);
  });
  optionTable?.addEventListener('click', (event) => {
    if (event.target.closest('.mi-remove-option')) event.target.closest('tr')?.remove();
  });

	const customFieldTable = document.querySelector('#mi-custom-fields tbody');
	document.getElementById('mi-add-custom-field')?.addEventListener('click', () => {
	  const index = `new_${Date.now()}_${customFieldTable?.rows.length || 0}`;
	  const row = document.createElement('tr');
	  row.innerHTML = `<td><input name="mi_custom_field_key[${index}]" pattern="[a-z0-9_-]+" placeholder="es. parrocchia"></td><td><input name="mi_custom_field_label[${index}]" required placeholder="Scrivi la domanda"></td><td><select name="mi_custom_field_type[${index}]"><option value="text">Risposta breve</option><option value="yesno">Sì / No</option><option value="textarea">Risposta lunga</option><option value="date">Data</option><option value="select">Scelta singola</option><option value="email">Email</option><option value="tel">Cellulare</option></select></td><td><input name="mi_custom_field_options[${index}]" placeholder="Opzione A | Opzione B"></td><td><select name="mi_custom_field_retention[${index}]"><option value="STANDARD">WordPress e Sheets</option><option value="SHEETS_ONLY">Escludi dalle copie di riepilogo</option></select></td><td><input type="hidden" name="mi_custom_field_required[${index}]" value="0"><input name="mi_custom_field_required[${index}]" type="checkbox" value="1"></td><td><button type="button" class="button mi-remove-custom-field">Rimuovi</button></td>`;
	  customFieldTable?.append(row);
	  row.querySelector('input')?.focus();
	});
	customFieldTable?.addEventListener('click', (event) => {
	  if (event.target.closest('.mi-remove-custom-field')) event.target.closest('tr')?.remove();
	});

  table.addEventListener('click', (event) => {
    const button = event.target.closest('.mi-remove-ticket');
    if (!button || table.tBodies[0].rows.length <= 1) return;
    button.closest('tr').remove();
  });
}());

// Il report presenze disattivato non blocca le modifiche indipendenti ai gruppi.
document.querySelectorAll('[name="mi_annual_attendance_report"]').forEach(toggle=>{
 const fields=toggle.form?.querySelectorAll('[data-mi-attendance-period] input')||[];
 const update=()=>fields.forEach(field=>{field.disabled=!toggle.checked;field.required=toggle.checked;});
 toggle.addEventListener('change',update);update();
});
