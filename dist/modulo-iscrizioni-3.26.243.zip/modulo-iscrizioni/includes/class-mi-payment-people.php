<?php
defined( 'ABSPATH' ) || exit;

/** Quote individuali e attribuzioni: i versamenti aggregati restano distinti dalle quote personali. */
final class MI_Payment_People {
	/** Conserva le scadenze nelle modifiche logistiche e nelle posizioni economiche invariate. */
	public static function payment_deadline_changes( array $registration, $covered, $economic_change ) {
		if ( ! in_array( $registration['economic_mode'] ?? '', array( 'FULL_PAYMENT', 'DEPOSIT_BALANCE' ), true ) ) return array();
		$changes = array( 'status' => $covered ? 'CONFIRMED' : 'PENDING_PAYMENT' );
		if ( $covered ) $changes['expires_at'] = null;
		elseif ( $economic_change || 'PENDING_PAYMENT' !== $registration['status'] ) {
			$deadline = MI_Registration_Service::reopened_payment_deadline( $registration );
			$changes['expires_at'] = $deadline;
			$changes['payment_deadline_at'] = $deadline;
		}
		return $changes;
	}
	/** Le quote dei servizi condivisi si dividono in parti uguali nell'ordine degli identificativi, senza perdere centesimi. */
	public static function common_shares( array $registration, array $people ) {
		$cost = 0;
		foreach ( json_decode( $registration['order_options_json'] ?? '[]', true ) ?: array() as $option ) $cost += (int) ( $option['quantity'] ?? 0 ) * (int) ( $option['unit_price_cents'] ?? 0 );
		$ids = array_map( 'intval', array_column( $people, 'id' ) ); sort( $ids, SORT_NUMERIC );
		$stored = json_decode( $registration['common_allocations_json'] ?? 'null', true );
		if ( is_array( $stored ) ) {
			$keys = array_map( 'intval', array_keys( $stored ) ); sort( $keys, SORT_NUMERIC );
			if ( $keys !== $ids || array_sum( $stored ) !== $cost ) throw new InvalidArgumentException( 'Ripartizione dei servizi comuni incoerente.' );
			foreach ( $stored as $amount ) if ( ! is_int( $amount ) || $amount < 0 ) throw new InvalidArgumentException( 'Importo individuale non valido.' );
			return $stored;
		}
		$shares = array(); $count = count( $ids );
		foreach ( $ids as $n => $id ) $shares[$id] = $count ? intdiv( $cost, $count ) + ( $n < $cost % $count ? 1 : 0 ) : 0;
		return $shares;
	}
	public static function quote_totals( array $registration, array $people, array $items ) {
		$prices = array_column( $items, 'unit_price_cents', 'ticket_type_code' );
		$common = self::common_shares( $registration, $people );
		$adjustments = json_decode( $registration['quote_adjustments_json'] ?? '{}', true ) ?: array();
		$totals = array();
		foreach ( $people as $person ) {
			$id = (int) $person['id']; $total = (int) ( $prices[$person['ticket_type_code']] ?? 0 ) + (int) ( $common[$id] ?? 0 ) + (int) ( $adjustments[$id] ?? 0 );
			foreach ( json_decode( $person['options_json'] ?? '[]', true ) ?: array() as $option ) $total += (int) ( $option['quantity'] ?? 0 ) * (int) ( $option['unit_price_cents'] ?? 0 );
			$totals[$id] = $total;
		}
		return $totals;
	}
	/** Conserva la caparra individuale entro il limite della nuova quota personale. */
	public static function retained_deposits( array $people, array $deltas ) {
		$deposits = array();
		foreach ( $people as $person ) {
			$id = (int) $person['id'];
			$deposits[$id] = min( (int) $person['deposit'], max( 0, (int) $person['total'] + (int) ( $deltas[$id] ?? 0 ) ) );
		}
		return $deposits;
	}
	/** Proietta le caparre percentuali dopo una variazione individuale della quota. Null indica un piano non percentuale o quote non attribuibili. */
	public static function projected_deposits( array $registration, array $position, array $deltas, $new_total ) {
		$snapshot = json_decode( $registration['snapshot_json'] ?? '{}', true ) ?: array();
		$event = $snapshot['event'] ?? array();
		if ( 'DEPOSIT_BALANCE' !== ( $registration['economic_mode'] ?? '' ) || 'PERCENTAGE' !== strtoupper( (string) ( $event['deposit_mode'] ?? '' ) ) || empty( $position['quotes_known'] ) ) return null;
		$totals = array(); $sum = 0;
		foreach ( (array) ( $position['people'] ?? array() ) as $person ) {
			$id = (int) $person['id']; $total = (int) $person['total'] + (int) ( $deltas[$id] ?? 0 );
			if ( $total < 0 ) return null;
			$totals[$id] = $total; $sum += $total;
		}
		if ( $sum !== (int) $new_total ) return null;
		$percentage = min( 99, max( 1, absint( $event['deposit_percentage'] ?? 30 ) ) );
		$target = (int) round( $sum * $percentage / 100 );
		$deposits = array(); $remainders = array(); $assigned = 0;
		foreach ( $totals as $id => $total ) {
			$product = $total * $target; $deposits[$id] = $sum ? intdiv( $product, $sum ) : 0;
			$remainders[$id] = $sum ? $product % $sum : 0; $assigned += $deposits[$id];
		}
		arsort( $remainders, SORT_NUMERIC );
		foreach ( $remainders as $id => $remainder ) { if ( $assigned >= $target ) break; $deposits[$id]++; $assigned++; }
		return $deposits;
	}
	/** Restituisce un valore booleano se è nota la copertura personale, null se sono disponibili solo dati aggregati. */
	public static function covered( array $position, $economic_mode, array $total_deltas = array(), array $projected_deposits = array() ) {
		if ( empty( $position['quotes_known'] ) || empty( $position['payments_known'] ) ) return null;
		if ( 'DEPOSIT_BALANCE' === $economic_mode && false === ( $position['deposits_known'] ?? true ) && ! $projected_deposits ) return null;
		$field = 'DEPOSIT_BALANCE' === $economic_mode ? 'deposit' : 'total';
		foreach ( $position['people'] as $person ) {
			if ( empty( $person['active'] ) ) continue;
			$id = (int) $person['id'];
			$required = 'deposit' === $field ? (int) ( $projected_deposits[$id] ?? $person['deposit'] ) : (int) $person['total'] + (int) ( $total_deltas[$id] ?? 0 );
			if ( (int) $person['paid'] < max( 0, $required ) ) return false;
		}
		return true;
	}
	/** Totali operativi delle sole persone attive. I crediti individuali non compensano i debiti altrui. */
	public static function summary( array $position ) {
		$totals_known = ! empty( $position['quotes_known'] ) && ! empty( $position['payments_known'] );
		$deposits_known = $totals_known && false !== ( $position['deposits_known'] ?? true );
		$summary = array( 'known' => $totals_known && $deposits_known, 'totals_known' => $totals_known, 'deposits_known' => $deposits_known, 'people_count' => count( $position['people'] ?? array() ), 'active_count' => 0, 'total' => 0, 'paid' => 0, 'balance' => 0, 'credit' => 0, 'deposit_due' => $deposits_known ? 0 : null, 'deposit_missing' => $deposits_known ? 0 : null );
		foreach ( $position['people'] as $person ) {
			if ( empty( $person['active'] ) ) continue;
			$summary['active_count']++;
			if ( ! $totals_known ) continue;
			$summary['total'] += max( 0, (int) $person['total'] );
			$summary['paid'] += (int) $person['paid'];
			$summary['balance'] += max( 0, (int) $person['balance'] );
			$summary['credit'] += max( 0, (int) $person['credit'] );
			if ( $deposits_known ) {
				$summary['deposit_due'] += max( 0, (int) $person['deposit'] );
				$summary['deposit_missing'] += max( 0, (int) $person['deposit_missing'] );
			}
		}
		$summary['paid'] = max( 0, $summary['paid'] );
		return $summary;
	}
	public static function read( array $registration, array $payments ) {
		global $wpdb;
		$id = (int) $registration['id'];
		$people = $wpdb->get_results( $wpdb->prepare( "SELECT id,ticket_type_code,first_name,last_name,options_json,status,deposit_due_cents FROM {$wpdb->prefix}mi_participants WHERE registration_id=%d ORDER BY id", $id ), ARRAY_A );
		if ( $wpdb->last_error ) throw new RuntimeException( 'Partecipanti non disponibili.' );
		$items = $wpdb->get_results( $wpdb->prepare( "SELECT ticket_type_code,unit_price_cents FROM {$wpdb->prefix}mi_registration_items WHERE registration_id=%d ORDER BY id", $id ), ARRAY_A );
		if ( $wpdb->last_error ) throw new RuntimeException( 'Quote non disponibili.' );
		return self::calculate( $registration, $people ?: array(), $items ?: array(), $payments );
	}
	public static function calculate( array $registration, array $people, array $items, array $payments ) {
		$prices = array_column( $items, 'unit_price_cents', 'ticket_type_code' );
		$snapshot = json_decode( $registration['snapshot_json'] ?? '{}', true ) ?: array();
		$deposit_plan = 'DEPOSIT_BALANCE' === ( $registration['economic_mode'] ?? '' );
		$rows = array(); $sum = 0; $issue = '';
		$totals = self::quote_totals( $registration, $people, $items );
		foreach ( $people as $person ) {
			$total = $totals[(int) $person['id']];
			if ( ! array_key_exists( $person['ticket_type_code'], $prices ) ) $issue = 'La quota individuale non è disponibile. Verifica le quote della prenotazione.';
			if ( $total < 0 ) $issue = 'La quota individuale non può essere negativa.';
			$sum += $total;
			$rows[(int) $person['id']] = array( 'id' => (int) $person['id'], 'name' => trim( $person['first_name'] . ' ' . $person['last_name'] ), 'total' => $total, 'deposit' => 0, 'paid' => 0, 'active' => 'ACTIVE' === $person['status'] );
		}
		if ( ! $rows ) $issue = 'Partecipanti non disponibili.';
		if ( $sum !== (int) $registration['total_cents'] ) $issue = 'Il totale comprende quote comuni o rettifiche non attribuite alle persone. Verifica le quote individuali prima di registrare il pagamento.';
		$quotes_known = '' === $issue;
		$deposits_known = $quotes_known;
		// La stessa formula della creazione: quota fissa per persona oppure percentuale.
		$deposit_total = min( $sum, max( 0, (int) ( $registration['initial_due_cents'] ?? 0 ) ) );
		$event = $snapshot['event'] ?? array(); $remainders = array(); $assigned = 0;
		$deposits = array_column( $people, 'deposit_due_cents', 'id' );
		if ( $deposit_plan && $sum > 0 ) {
			foreach ( $rows as $id => &$row ) {
				if ( isset( $deposits[$id] ) ) {
					$row['deposit'] = min( $row['total'], (int) $deposits[$id] );
				} elseif ( 'FIXED' === ( $event['deposit_mode'] ?? '' ) ) {
					$row['deposit'] = min( $row['total'], (int) ( $event['deposit_fixed_cents'] ?? 0 ) );
				} else {
					$product = $row['total'] * $deposit_total;
					$row['deposit'] = intdiv( $product, $sum ); $remainders[$id] = $product % $sum;
				}
				$assigned += $row['deposit'];
			} unset( $row );
			if ( $remainders ) { arsort( $remainders, SORT_NUMERIC ); foreach ( $remainders as $id => $remainder ) { if ( $assigned >= $deposit_total ) break; $rows[$id]['deposit']++; $assigned++; } }
			if ( $assigned !== $deposit_total ) {
				$deposits_known = false;
				$issue = 'La caparra complessiva non coincide con le quote individuali. Verifica la prenotazione.';
			}
		}
		$payments_known = true;
		$has_allocated_payments = false;
		$unassigned = 0;
		foreach ( $payments as $payment ) {
			$sign = 'REFUND' === $payment['transaction_kind'] ? -1 : 1;
			$allocations = json_decode( $payment['participant_allocations_json'] ?? 'null', true );
			if ( ! is_array( $allocations ) || ! $allocations ) { $unassigned += $sign * (int) $payment['amount_cents']; continue; }
			$has_allocated_payments = true;
			$allocated = 0;
			foreach ( $allocations as $allocation ) {
				$id = (int) $allocation['participant_id']; $amount = (int) $allocation['amount_cents'];
				if ( ! isset( $rows[$id] ) || $amount < 1 ) { $payments_known = false; $issue = 'Attribuzioni dei versamenti da verificare.'; continue; }
				$rows[$id]['paid'] += $sign * $amount; $allocated += $amount;
			}
			if ( $allocated !== (int) $payment['amount_cents'] ) { $payments_known = false; $issue = 'Attribuzioni dei versamenti da verificare.'; }
		}
		if ( $unassigned !== 0 ) {
			if ( count( $rows ) === 1 ) { $id = array_key_first( $rows ); $rows[$id]['paid'] += $unassigned; }
			else $issue = 'Sono presenti versamenti precedenti senza attribuzione individuale. Occorre verificare a chi appartengono prima di usare la selezione delle persone.';
		}
		foreach ( $rows as &$row ) {
			$row['balance'] = max( 0, $row['total'] - $row['paid'] );
			$row['deposit_missing'] = max( 0, $row['deposit'] - $row['paid'] );
			$row['saldo'] = $row['total'] - $row['deposit'];
			$row['credit'] = max( 0, $row['paid'] - $row['total'] );
			if ( $row['paid'] < 0 ) $issue = 'La posizione individuale richiede una verifica prima di un nuovo versamento.';
		} unset( $row );
		return array( 'ready' => '' === $issue, 'quotes_known' => $quotes_known, 'deposits_known' => $deposits_known, 'payments_known' => $payments_known && ( ! $unassigned || count( $rows ) === 1 ), 'requires_refund_allocation' => $has_allocated_payments, 'message' => $issue, 'deposit_plan' => $deposit_plan, 'people' => array_values( $rows ) );
	}
	/** Solo lettura gestionale: isola una prenotazione incoerente senza inventare
	 * quote personali. Le operazioni di scrittura continuano a usare calculate,
	 * che rifiuta i dati incoerenti prima di registrare movimenti.
	 */
	public static function calculate_for_display( array $registration, array $people, array $items, array $payments ) {
		try { return self::calculate( $registration, $people, $items, $payments ); }
		catch ( InvalidArgumentException $error ) {
			return array( 'ready' => false, 'quotes_known' => false, 'deposits_known' => false, 'payments_known' => false, 'requires_refund_allocation' => true, 'message' => $error->getMessage(), 'deposit_plan' => 'DEPOSIT_BALANCE' === ( $registration['economic_mode'] ?? '' ), 'people' => array() );
		}
	}
	public static function plan( array $position, array $ids, $installment, $amount ) {
		if ( ! $position['ready'] ) throw new InvalidArgumentException( $position['message'] );
		if ( ! $ids || count( $ids ) !== count( array_unique( $ids ) ) ) throw new InvalidArgumentException( 'Seleziona le persone per cui registrare il pagamento.' );
		if ( ! in_array( $installment, array( 'DEPOSIT', 'BALANCE', 'FULL' ), true ) || ( ! $position['deposit_plan'] && 'FULL' !== $installment ) ) throw new InvalidArgumentException( 'Tipo di versamento non valido.' );
		$people = array_column( $position['people'], null, 'id' ); $plan = array(); $total = 0;
		sort( $ids, SORT_NUMERIC );
		foreach ( $ids as $id ) {
			$person = $people[$id] ?? null;
			if ( ! $person || ! $person['active'] ) throw new InvalidArgumentException( 'Partecipante non disponibile per questo versamento.' );
			if ( 'BALANCE' === $installment && $person['deposit_missing'] > 0 ) throw new InvalidArgumentException( 'Prima del saldo deve essere versata la caparra per tutte le persone selezionate.' );
			$due = 'DEPOSIT' === $installment ? $person['deposit_missing'] : $person['balance'];
			if ( $due < 1 ) throw new InvalidArgumentException( 'Una delle persone selezionate ha già versato questa quota. Aggiorna la selezione.' );
			$plan[] = array( 'participant_id' => (int) $id, 'name' => $person['name'], 'amount_cents' => $due ); $total += $due;
		}
		if ( $total !== $amount ) throw new InvalidArgumentException( 'L’importo deve corrispondere esattamente alle quote delle persone selezionate. Ricarica la prenotazione se è stata aggiornata.' );
		return $plan;
	}
	public static function refund_plan( array $position, array $ids, $amount ) {
		if ( empty( $position['payments_known'] ) ) throw new InvalidArgumentException( $position['message'] ?: 'I versamenti precedenti devono essere attribuiti prima di registrare il rimborso.' );
		if ( 1 !== count( $ids ) || 1 !== count( array_unique( $ids ) ) ) throw new InvalidArgumentException( 'Seleziona una sola persona a cui attribuire il rimborso o storno.' );
		$id = (int) reset( $ids );
		$person = array_column( $position['people'], null, 'id' )[$id] ?? null;
		if ( ! $person ) throw new InvalidArgumentException( 'Persona non disponibile per questo rimborso.' );
		if ( $amount < 1 || $amount > max( 0, (int) $person['paid'] ) ) throw new InvalidArgumentException( 'Il rimborso o storno supera quanto versato dalla persona selezionata.' );
		return array( array( 'participant_id' => $id, 'name' => $person['name'], 'amount_cents' => (int) $amount ) );
	}
}
