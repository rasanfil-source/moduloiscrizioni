<?php

defined( 'ABSPATH' ) || exit;
require_once __DIR__ . '/class-mi-booking-search.php';
require_once __DIR__ . '/class-mi-amount.php';

final class MI_Portal {
	const SHORTCODE = 'mi_portale_gestione';
	const CUSTOM_COMMUNICATION_TYPES_OPTION = 'mi_custom_communication_types';

	public static function boot() {
		add_shortcode( self::SHORTCODE, array( __CLASS__, 'render' ) );
		// Il portale autonomo deve terminare la richiesta prima che tema, builder e
		// plugin frontend eseguano i propri callback su template_redirect.
		add_action( 'template_redirect', array( __CLASS__, 'handle_actions' ), -100 );
		add_action( 'template_redirect', array( __CLASS__, 'render_virtual_page' ), -90 );
		add_filter( 'posts_pre_query', array( __CLASS__, 'skip_unused_main_query' ), 10, 2 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp_head', array( __CLASS__, 'portal_icon_links' ), 99 );
		add_action( 'send_headers', array( __CLASS__, 'secure_cancellation_headers' ) );
		add_action( 'mi_pulisci_bozze_cestinate', array( __CLASS__, 'purge_trashed_drafts' ) );
		add_action( 'mi_pulisci_bozze_cestinate', array( __CLASS__, 'archive_completed_event_sheets' ), 20 );
		add_action( 'mi_organizza_fogli_evento', array( __CLASS__, 'archive_completed_event_sheets' ) );
		add_action( 'mi_sync_workspace_event', array( __CLASS__, 'sincronizza_evento_in_coda' ) );
	}

	/** Il portale autonomo non usa gli articoli della home; le query delle schede restano normali. */
	public static function skip_unused_main_query( $posts, $query ) {
		if ( null !== $posts || is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) return $posts;
		if ( empty( $_GET['mi_portal'] ) || ! $query->is_main_query() ) return $posts;
		$query->found_posts = 0;
		$query->max_num_pages = 0;
		return array();
	}

	/** La cancellazione definitiva passa sempre dalla procedura coordinata. */
	public static function purge_trashed_drafts() {
		// L'eliminazione richiede una verifica e può essere ripresa dal punto raggiunto.
	}

	/** Allinea i fogli alla stessa distinzione tra eventi correnti e passati mostrata nel portale. */
	public static function archive_completed_event_sheets() {
		// Tre eventi per esecuzione: le chiamate Drive proseguono anche dopo un
		// timeout HTTP. Il cursore evita che gli eventi oltre i primi 200 siano ignorati.
		$events = array_map( 'intval', get_posts( array( 'post_type' => MI_Event_Post_Type::EVENT_TYPE, 'post_status' => array( 'publish', 'draft', 'private' ), 'numberposts' => -1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC', 'meta_key' => '_mi_operational_sheet_id', 'no_found_rows' => true ) ) );
		$cursor = (int) get_option( 'mi_sheet_organization_cursor', 0 );
		$remaining = array_values( array_filter( $events, static function ( $id ) use ( $cursor ) { return $id > $cursor; } ) );
		$batch = array_slice( $remaining, 0, 3 );
		if ( ! $batch ) { delete_option( 'mi_sheet_organization_cursor' ); return; }
		$fogli = array_map( static function ( $id ) { return array( 'id_evento' => (string) $id, 'id_foglio' => (string) get_post_meta( $id, '_mi_operational_sheet_id', true ) ); }, $batch );
		$verifica = MI_Workspace_Client::request( 'VERIFICA_FOGLI_EVENTO', array( 'fogli' => $fogli, 'direct_projection' => true ) );
		if ( ! is_wp_error( $verifica ) ) foreach ( (array) ( $verifica['stati'] ?? array() ) as $stato ) {
			$id = absint( $stato['id_evento'] ?? 0 );
			if ( ! in_array( $id, $batch, true ) ) continue;
			if ( empty( $stato['esiste'] ) ) update_post_meta( $id, '_mi_sheet_missing', '1' );
			else delete_post_meta( $id, '_mi_sheet_missing' );
		}
		$correnti = $passati = $versions = array();
		foreach ( $batch as $event_id ) {
			$annullato = (bool) get_post_meta( $event_id, '_mi_event_cancelled_at', true );
			$archiviato = (bool) get_post_meta( $event_id, '_mi_event_archived_at', true );
			$chiusura = (string) get_post_meta( $event_id, '_mi_registration_closes_at', true );
			$inizio = (string) get_post_meta( $event_id, '_mi_event_starts_at', true );
			$passato = $archiviato || ( ! $annullato && self::is_past_event( $inizio ?: $chiusura ) );
			// Anche la sostituzione del file deve invalidare lo stato già confermato.
			$version = get_post_meta( $event_id, '_mi_operational_sheet_id', true ) . '|' . ( $passato ? 'past' : 'current' );
			if ( $version === get_post_meta( $event_id, '_mi_sheet_organization', true ) ) continue;
			$versions[ $event_id ] = $version;
			if ( $passato ) $passati[] = (string) $event_id;
			else $correnti[] = (string) $event_id;
		}
		if ( $versions ) {
			$map_sheet = static function ( $id ) { return array( 'id_evento' => (string) $id, 'id_foglio' => (string) get_post_meta( (int) $id, '_mi_operational_sheet_id', true ) ); };
			$result = MI_Workspace_Client::request( 'ORGANIZZA_FOGLI_EVENTO', array( 'fogli_correnti' => array_map( $map_sheet, $correnti ), 'fogli_passati' => array_map( $map_sheet, $passati ), 'direct_projection' => true ) );
			// L'ok della busta non garantisce il successo di ogni singolo spostamento.
			if ( ! is_wp_error( $result ) ) foreach ( (array) ( $result['risultati'] ?? array() ) as $item ) {
				$id = absint( $item['id_evento'] ?? 0 );
				if ( empty( $item['ok'] ) || ! isset( $versions[ $id ] ) ) continue;
				update_post_meta( $id, '_mi_sheet_organization', $versions[ $id ] );
				if ( in_array( (string) $id, $passati, true ) ) update_post_meta( $id, '_mi_sheet_archived_at', current_time( 'mysql', true ) );
				else delete_post_meta( $id, '_mi_sheet_archived_at' );
			}
		}
		// Gli errori non sono certificati: saranno ritentati nel ciclo giornaliero
		// evento successivo, lasciando spazio agli altri eventi tra un nuovo tentativo e l'altro.
		if ( count( $remaining ) > count( $batch ) ) {
			update_option( 'mi_sheet_organization_cursor', max( $batch ), false );
			if ( ! wp_next_scheduled( 'mi_organizza_fogli_evento' ) ) wp_schedule_single_event( time() + 60, 'mi_organizza_fogli_evento' );
		} else delete_option( 'mi_sheet_organization_cursor' );
	}

	public static function secure_cancellation_headers() {
		if ( ( empty( $_GET['mi_cancel_participant'] ) || empty( $_GET['mi_cancel_token'] ) ) && empty( $_GET['mi_status'] ) && empty( $_GET['mi_waitlist_offer'] ) ) return;
		header( 'Referrer-Policy: no-referrer' );
		header( 'X-Robots-Tag: noindex, nofollow, noarchive', true );
	}

	private static function needs_management_script() {
		return is_user_logged_in() && empty( $_GET['mi_status'] ) && empty( $_GET['mi_waitlist_offer'] ) && in_array( self::current_view(), array( 'management', 'registrations', 'groups' ), true );
	}

	private static function needs_payment_assets() {
		return is_user_logged_in() && empty( $_GET['mi_status'] ) && empty( $_GET['mi_waitlist_offer'] ) && in_array( self::current_view(), array( 'payments', 'payment-report' ), true ) && MI_Portal_Payments::allowed();
	}

	private static function current_view() {
		// La schermata iniziale e le risorse condizionali restano allineate anche all'apertura dalla PWA.
		return sanitize_key( wp_unslash( $_GET['mi_portal_view'] ?? 'management' ) );
	}

	public static function assets() {
		if ( ! is_singular() && empty( $_GET['mi_portal'] ) && empty( $_GET['mi_status'] ) && empty( $_GET['mi_waitlist_offer'] ) ) return;
		$post = get_post();
		if ( empty( $_GET['mi_portal'] ) && empty( $_GET['mi_status'] ) && empty( $_GET['mi_waitlist_offer'] ) && ( ! $post || ! has_shortcode( $post->post_content, self::SHORTCODE ) ) ) return;
		if ( class_exists( 'MI_Event_QR' ) ) MI_Event_QR::assets();
		wp_enqueue_style( 'mi-portal', MI_PLUGIN_URL . 'assets/portal.css', array(), MI_VERSION );
		wp_enqueue_script( 'mi-portal', MI_PLUGIN_URL . 'assets/portal.js', array(), MI_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
		if ( self::needs_management_script() ) wp_enqueue_script( 'mi-portal-management', MI_PLUGIN_URL . 'assets/portal-management.js', array(), MI_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_enqueue_style( 'mi-portal-management', MI_PLUGIN_URL . 'assets/portal-management.css', array( 'mi-portal' ), MI_VERSION );
		if ( self::needs_payment_assets() ) {
			wp_enqueue_style( 'mi-portal-payments', MI_PLUGIN_URL . 'assets/portal-payments.css', array( 'mi-portal' ), MI_VERSION );
			wp_enqueue_script( 'mi-portal-payments', MI_PLUGIN_URL . 'assets/portal-payments.js', array(), MI_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
		}
	}

	/** Usa l'identità operativa soltanto nella Segreteria eventi, senza alterare le pagine pubbliche. */
	public static function portal_icon_links() {
		if ( ! empty( $_GET['mi_status'] ) || ! empty( $_GET['mi_waitlist_offer'] ) ) return;
		$is_portal = ! empty( $_GET['mi_portal'] );
		if ( ! $is_portal ) {
			if ( ! is_singular() ) return;
			$post = get_post();
			if ( ! $post || ! has_shortcode( $post->post_content, self::SHORTCODE ) ) return;
		}
		$icon = 'assets/portal-icon-32.png';
		$asset_url = MI_PLUGIN_URL . $icon . '?ver=' . rawurlencode( MI_VERSION );
		$ico = 'assets/segreteria-eventi.ico';
		$ico_url = MI_PLUGIN_URL . $ico . '?ver=' . rawurlencode( MI_VERSION );
		echo '<link rel="shortcut icon" type="image/x-icon" href="' . esc_url( $ico_url ) . '">';
		echo '<link rel="icon" type="image/png" href="' . esc_url( $asset_url ) . '">';
		$apple_icon = class_exists( 'MI_Portal_PWA' ) ? MI_Portal_PWA::apple_icon() : '';
		echo '<link rel="apple-touch-icon" sizes="' . ( $apple_icon ? '192x192' : '180x180' ) . '" href="' . esc_url( $apple_icon ?: MI_PLUGIN_URL . 'assets/portal-icon-180.png?ver=' . rawurlencode( MI_VERSION ) ) . '">';
		if ( class_exists( 'MI_Portal_PWA' ) ) MI_Portal_PWA::render_head();
	}

	public static function handle_actions() {
		if ( 'POST' !== strtoupper( $_SERVER['REQUEST_METHOD'] ?? '' ) ) return;
		$action = sanitize_key( wp_unslash( $_POST['mi_portal_action'] ?? '' ) );
		if ( 'accedi_portale' === $action ) return self::gestisci_accesso_portale();
		if ( 'cancel_participant_public' === $action ) {
			$participant_id = absint( $_POST['participant_id'] ?? 0 );
			check_admin_referer( 'mi_cancel_participant_public_' . $participant_id, 'mi_portal_nonce' );
			return self::redirect_cancel_result( MI_Registration_Service::cancel_participant_with_token( $participant_id, sanitize_text_field( wp_unslash( $_POST['cancel_token'] ?? '' ) ) ) );
		}
		if ( 'waitlist_offer_decision' === $action ) {
			$registration_id = absint( $_POST['registration_id'] ?? 0 );
			check_admin_referer( 'mi_waitlist_offer_' . $registration_id, 'mi_portal_nonce' );
			$result = MI_Registration_Service::respond_waitlist_offer( $registration_id, sanitize_text_field( wp_unslash( $_POST['offer_token'] ?? '' ) ), sanitize_key( wp_unslash( $_POST['decision'] ?? '' ) ) );
			$code = is_wp_error( $result ) ? 'error' : strtolower( (string) $result );
			wp_safe_redirect( add_query_arg( array( 'mi_waitlist_offer' => $registration_id, 'mi_waitlist_result' => $code ), home_url( '/' ) ) );
			exit;
		}
		if ( 'cancel_participant_portal' === $action ) {
			if ( ! is_user_logged_in() || ( ! current_user_can( 'mi_manage_events' ) && ! current_user_can( 'manage_options' ) ) ) wp_die( 'Accesso non consentito.', 403 );
			$participant_id = absint( $_POST['participant_id'] ?? 0 );
			check_admin_referer( 'mi_cancel_participant_portal_' . $participant_id, 'mi_portal_nonce' );
			global $wpdb; $event_id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT r.event_id FROM {$wpdb->prefix}mi_participants p JOIN {$wpdb->prefix}mi_registrations r ON r.id=p.registration_id WHERE p.id=%d", $participant_id ) );
			if ( ! $event_id || ! MI_Access::can_access_event( $event_id ) ) wp_die( 'Partecipante non accessibile.', 403 );
			return self::redirect_cancel_result( MI_Registration_Service::cancel_participant( $participant_id, wp_get_current_user()->display_name ) );
		}
		if ( in_array( $action, array( 'update_event', 'cancel_event', 'archive_event', 'trash_event', 'duplicate_event' ), true ) ) return self::handle_event_management_action( $action );
		if ( 'prepare_event_outputs' === $action ) return self::handle_event_outputs_action();
		if ( 'repair_event_sheet' === $action ) return self::handle_event_sheet_repair_action();
		if ( 'publish_event_portal' === $action ) return self::handle_event_publication_action();
		if ( 'prepare_communication' === $action ) return self::handle_communication_action();
		if ( in_array( $action, array( 'add_communication_type', 'delete_communication_type' ), true ) ) return self::handle_communication_type_action( $action );
		if ( in_array( $action, array( 'create_operator', 'update_operator' ), true ) ) return self::handle_operator_action( $action );
		if ( in_array( $action, array( 'create_group', 'update_group', 'delete_group' ), true ) ) return self::handle_group_action( $action );
		if ( 'create_event' !== $action ) return;
		$existing_event_id = absint( $_POST['event_id'] ?? $_POST['draft_event_id'] ?? 0 );
		$required_capability = $existing_event_id ? 'mi_manage_events' : 'mi_create_events';
		if ( ! is_user_logged_in() || ( ! current_user_can( $required_capability ) && ! current_user_can( 'manage_options' ) ) ) wp_die( 'Accesso non consentito.', 403 );
		check_admin_referer( 'mi_portal_create_event', 'mi_portal_nonce' );
		$extra_services = MI_Extra_Services::parse( wp_unslash( $_POST ) );
		if ( is_wp_error( $extra_services ) ) return self::redirect_result( $extra_services->get_error_message(), true );
		$existing_event = null;
		if ( $existing_event_id ) {
			$existing_event = get_post( $existing_event_id );
			$allowed_statuses = array( 'draft', 'publish', 'private' );
			if ( ! $existing_event || MI_Event_Post_Type::EVENT_TYPE !== $existing_event->post_type || ! in_array( $existing_event->post_status, $allowed_statuses, true ) || get_post_meta( $existing_event_id, '_mi_event_cancelled_at', true ) || ! MI_Access::can_access_event( $existing_event_id ) ) wp_die( 'Evento non accessibile.', 403 );
		}
		$title = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );
		if ( ! $title ) return self::redirect_result( 'Titolo obbligatorio.', true );
		$starts_at = self::normalize_portal_date( sanitize_text_field( wp_unslash( $_POST['starts_at'] ?? '' ) ) );
		if ( ! $starts_at ) return self::redirect_result( 'La data di inizio deve usare il formato gg/mm/aaaa hh:mm, con un anno di quattro cifre.', true );
		$start_date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', $starts_at, wp_timezone() );
		$unchanged_start = $existing_event && $starts_at === (string) get_post_meta( $existing_event_id, '_mi_event_starts_at', true );
		if ( ! $start_date || ( ! $unchanged_start && $start_date->format( 'Y-m-d' ) < current_time( 'Y-m-d' ) ) ) return self::redirect_result( 'La data di inizio non può essere precedente a oggi.', true );
		$latest_event_date = ( new DateTimeImmutable( 'today', wp_timezone() ) )->modify( '+10 years' )->setTime( 23, 59 );
		if ( $start_date > $latest_event_date ) return self::redirect_result( 'La data dell’evento non può essere oltre dieci anni nel futuro.', true );
		$opens_input = sanitize_text_field( wp_unslash( $_POST['opens_at'] ?? '' ) );
		$closes_input = sanitize_text_field( wp_unslash( $_POST['closes_at'] ?? '' ) );
		$opens_at = $opens_input ? self::normalize_portal_date( $opens_input ) : '';
		$closes_at = self::normalize_portal_date( $closes_input );
		if ( ( $opens_input && ! $opens_at ) || ! $closes_at ) return self::redirect_result( 'Le date devono usare il formato gg/mm/aaaa hh:mm, con un anno di quattro cifre.', true );
		$open_date = $opens_at ? DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', $opens_at, wp_timezone() ) : null;
		$close_date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', $closes_at, wp_timezone() );
		$now_minute = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', current_time( 'Y-m-d\TH:i' ), wp_timezone() );
		if ( ( $opens_at && ! $open_date ) || ! $close_date ) return self::redirect_result( 'Controlla le date di apertura e chiusura delle iscrizioni.', true );
		$unchanged_close = $existing_event && $closes_at === (string) get_post_meta( $existing_event_id, '_mi_registration_closes_at', true );
		if ( $now_minute && ! $unchanged_close && $close_date < $now_minute ) return self::redirect_result( 'La chiusura delle iscrizioni non può essere precedente a questo momento.', true );
		if ( $open_date && $close_date <= $open_date ) return self::redirect_result( 'La chiusura delle iscrizioni deve essere successiva all’apertura.', true );
		$pricing_mode_default = $existing_event ? ( get_post_meta( $existing_event_id, '_mi_pricing_mode', true ) ?: 'NONE' ) : 'NONE';
		$portal_pricing_mode = strtoupper( sanitize_key( wp_unslash( $_POST['pricing_mode'] ?? $pricing_mode_default ) ) );
		if ( ! in_array( $portal_pricing_mode, array( 'NONE', 'ZERO', 'FIXED', 'CALCULATED' ), true ) ) return self::redirect_result( 'La modalità delle quote non è valida. Le impostazioni precedenti sono state conservate.', true, $existing_event_id );
		$fixed_price = self::parse_euro_cents( wp_unslash( $_POST['fixed_price'] ?? '' ) );
		if ( 'FIXED' === $portal_pricing_mode && ( is_wp_error( $fixed_price ) || $fixed_price < 1 ) ) return self::redirect_result( 'Indica una quota di partecipazione valida.', true, $existing_event_id );
		if ( ! in_array( $portal_pricing_mode, array( 'ZERO', 'FIXED' ), true ) ) {
			foreach ( array( 'colazione' => 'Colazione', 'assicurazione-disdetta' => 'Assicurazione disdetta', 'assicurazione-sanitaria' => 'Assicurazione sanitaria', 'pranzo' => 'Pranzo', 'rimborso-spese' => 'Rimborso spese' ) as $service_code => $service_label ) {
				if ( empty( $_POST['service_enabled'][ $service_code ] ) ) continue;
				if ( null === MI_Amount::cents( wp_unslash( $_POST['service_price'][ $service_code ] ?? '' ) ) ) return self::redirect_result( 'Indica una quota valida per ' . $service_label . '.', true, $existing_event_id );
			}
			$route_codes = (array) wp_unslash( $_POST['bus_route_code'] ?? array() );
			$route_ids = (array) wp_unslash( $_POST['bus_route_id'] ?? array() );
			$route_prices = (array) wp_unslash( $_POST['bus_route_price'] ?? array() );
			foreach ( array_slice( $route_codes, 0, 12, true ) as $index => $route_label ) {
				$has_route = '' !== trim( (string) $route_label ) || '' !== trim( (string) ( $route_ids[ $index ] ?? '' ) ) || '' !== trim( (string) ( $route_prices[ $index ] ?? '' ) );
				if ( $has_route && null === MI_Amount::cents( $route_prices[ $index ] ?? '' ) ) return self::redirect_result( 'Indica una quota valida per ogni tratta del pullman.', true, $existing_event_id );
			}
			if ( '1' === (string) ( $_POST['overnight'] ?? '0' ) ) foreach ( (array) wp_unslash( $_POST['accommodations'] ?? array() ) as $accommodation_code ) {
				$accommodation_code = strtoupper( sanitize_key( $accommodation_code ) );
				if ( ! in_array( $accommodation_code, array( 'SINGOLA', 'DOPPIA_SEPARATI', 'DOPPIA_MATRIMONIALE', 'TRIPLA', 'MULTIPLA' ), true ) ) continue;
				if ( null === MI_Amount::cents( wp_unslash( $_POST['accommodation_price'][ $accommodation_code ] ?? '' ) ) ) return self::redirect_result( 'Indica una quota valida per ogni tipo di alloggio selezionato.', true, $existing_event_id );
			}
		}
		$economic_mode_default = $existing_event ? ( get_post_meta( $existing_event_id, '_mi_economic_mode', true ) ?: 'FULL_PAYMENT' ) : 'FULL_PAYMENT';
		$portal_economic_mode = strtoupper( sanitize_key( wp_unslash( $_POST['economic_mode'] ?? $economic_mode_default ) ) );
		if ( ! in_array( $portal_economic_mode, array( 'REGISTRATION_ONLY', 'PRICE_ONLY', 'FULL_PAYMENT', 'DEPOSIT_BALANCE' ), true ) ) return self::redirect_result( 'La modalità di pagamento non è valida. Le impostazioni precedenti sono state conservate.', true, $existing_event_id );
		$deposit_mode_default = $existing_event ? ( get_post_meta( $existing_event_id, '_mi_deposit_mode', true ) ?: 'PERCENTAGE' ) : 'PERCENTAGE';
		$portal_deposit_mode = strtoupper( sanitize_key( wp_unslash( $_POST['deposit_mode'] ?? $deposit_mode_default ) ) );
		if ( ! in_array( $portal_deposit_mode, array( 'FIXED', 'PERCENTAGE' ), true ) ) return self::redirect_result( 'La modalità della caparra non è valida. Le impostazioni precedenti sono state conservate.', true, $existing_event_id );
		$deposit_fixed = self::parse_euro_cents( wp_unslash( $_POST['deposit_fixed'] ?? '' ) );
		if ( 'DEPOSIT_BALANCE' === $portal_economic_mode && 'FIXED' === $portal_deposit_mode && ( is_wp_error( $deposit_fixed ) || $deposit_fixed < 1 ) ) return self::redirect_result( 'Indica un importo fisso valido per la caparra.', true, $existing_event_id );
		$copy_id = absint( $_POST['copy_event_id'] ?? 0 );
		if ( $copy_id && ! MI_Access::can_access_event( $copy_id ) ) wp_die( 'Evento modello non accessibile.', 403 );
		$activity_id = absint( $_POST['activity_id'] ?? 0 );
		$current_activity_id = $existing_event ? absint( get_post_meta( $existing_event_id, '_mi_activity_id', true ) ) : 0;
		$keeps_assigned_activity = $existing_event && $activity_id === $current_activity_id;
		if ( $existing_event && ! $keeps_assigned_activity ) {
			// Cambiare gruppo cambia anche l'ambito di accesso: con iscritti serve
			// la migrazione esplicita, come nell'editor amministrativo.
			global $wpdb;
			$has_registrations = $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$wpdb->prefix}mi_registrations WHERE event_id=%d LIMIT 1", $existing_event_id ) );
			if ( $wpdb->last_error || $has_registrations ) return self::redirect_result( 'Il gruppo di un evento con iscrizioni si cambia tramite la procedura di migrazione.', true, $existing_event_id );
		}
		if ( ! $activity_id || MI_Event_Post_Type::GROUP_TYPE !== get_post_type( $activity_id ) || ( ! $keeps_assigned_activity && ! MI_Access::can_access_activity( $activity_id ) ) ) wp_die( 'Gruppo non accessibile.', 403 );
		$description = self::limit_text_lines( sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) ), 6, 1200 );
		$public_slug = MI_Shortcode::validate_public_slug( wp_unslash( $_POST['public_slug'] ?? '' ), $existing_event_id );
		if ( is_wp_error( $public_slug ) ) return self::redirect_result( $public_slug->get_error_message(), true, $existing_event_id );
		if ( $existing_event ) {
			$event_id = wp_update_post( array( 'ID' => $existing_event_id, 'post_title' => $title, 'post_content' => $description ), true );
			if ( is_wp_error( $event_id ) ) return self::redirect_result( 'Non è stato possibile aggiornare l’evento.', true, $existing_event_id );
		} else {
			$event_id = wp_insert_post( array( 'post_type' => MI_Event_Post_Type::EVENT_TYPE, 'post_status' => 'draft', 'post_title' => $title, 'post_content' => $description, 'post_author' => get_current_user_id() ), true );
			if ( is_wp_error( $event_id ) ) return self::redirect_result( 'Non è stato possibile creare la bozza.', true );
			if ( $copy_id ) self::copy_configuration( $copy_id, $event_id );
		}
		$slug_result = MI_Shortcode::save_public_slug( $event_id, $public_slug );
		if ( is_wp_error( $slug_result ) ) return self::redirect_result( $slug_result->get_error_message(), true, $event_id );
		if ( ! get_post_meta( $event_id, '_mi_privacy_policy_version', true ) ) update_post_meta( $event_id, '_mi_privacy_policy_version', wp_date( 'Y-m' ) );
		if ( ! get_post_meta( $event_id, '_mi_privacy_consent_id', true ) ) update_post_meta( $event_id, '_mi_privacy_consent_id', 'privacy-' . $event_id );
		if ( ! get_post_meta( $event_id, '_mi_marketing_consent_id', true ) ) update_post_meta( $event_id, '_mi_marketing_consent_id', 'marketing-' . $event_id );
		update_post_meta( $event_id, '_mi_activity_id', $activity_id );
		$gestore = self::risolvi_gestore_evento( $event_id, false );
		if ( $gestore instanceof WP_User ) update_post_meta( $event_id, '_mi_manager_user_id', $gestore->ID );
		self::save_date( $event_id, '_mi_event_starts_at', $starts_at );
		self::save_date( $event_id, '_mi_registration_opens_at', $opens_at );
		self::save_date( $event_id, '_mi_registration_closes_at', $closes_at );
		update_post_meta( $event_id, '_mi_event_location', mb_substr( sanitize_text_field( wp_unslash( $_POST['location'] ?? '' ) ), 0, 180 ) );
		update_post_meta( $event_id, '_mi_capacity', min( 10000, max( 1, absint( $_POST['capacity'] ?? 30 ) ) ) );
		update_post_meta( $event_id, '_mi_waitlist_enabled', ! empty( $_POST['waitlist_enabled'] ) ? '1' : '0' );
		$saved_waitlist_offer_hours = absint( get_post_meta( $event_id, '_mi_waitlist_offer_hours', true ) );
		$waitlist_offer_hours = isset( $_POST['waitlist_offer_hours'] ) ? absint( $_POST['waitlist_offer_hours'] ) : ( $saved_waitlist_offer_hours ?: 48 );
		update_post_meta( $event_id, '_mi_waitlist_offer_hours', min( 168, max( 1, $waitlist_offer_hours ) ) );
		$saved_reopened_payment_hours = absint( get_post_meta( $event_id, '_mi_reopened_payment_hours', true ) );
		$reopened_payment_hours = isset( $_POST['reopened_payment_hours'] ) ? absint( $_POST['reopened_payment_hours'] ) : ( $saved_reopened_payment_hours ?: 48 );
		update_post_meta( $event_id, '_mi_reopened_payment_hours', min( 168, max( 1, $reopened_payment_hours ) ) );
		update_post_meta( $event_id, '_mi_operational_profile', MI_Field_Schema::sanitize_operational_profile( wp_unslash( $_POST['operational_profile'] ?? 'AUTOMATICO' ) ) );
		$overnight = ! empty( $_POST['overnight'] ) ? '1' : '0';
		update_post_meta( $event_id, '_mi_overnight_enabled', $overnight );
		$accommodation_management = 'PREBOOKED' === strtoupper( sanitize_key( wp_unslash( $_POST['accommodation_management'] ?? '' ) ) ) ? 'PREBOOKED' : 'ON_DEMAND';
		update_post_meta( $event_id, '_mi_accommodation_management', '1' === $overnight ? $accommodation_management : 'ON_DEMAND' );
		update_post_meta( $event_id, '_mi_bus_assignment_enabled', empty( $_POST['bus_assignment_enabled'] ) ? '0' : '1' );
		$accommodations = '1' === $overnight ? array_values( array_intersect( array( 'SINGOLA', 'DOPPIA_SEPARATI', 'DOPPIA_MATRIMONIALE', 'TRIPLA', 'MULTIPLA' ), array_map( 'strtoupper', array_map( 'sanitize_key', (array) wp_unslash( $_POST['accommodations'] ?? array() ) ) ) ) ) : array();
		update_post_meta( $event_id, '_mi_accommodations', $accommodations );
		$field_configuration = MI_Field_Schema::sanitize_configuration(
			'CUSTOM',
			(array) wp_unslash( $_POST['participant_fields'] ?? array() ),
			(array) wp_unslash( $_POST['participant_required'] ?? array() )
		);
		update_post_meta( $event_id, '_mi_data_profile', $field_configuration['profile'] );
		update_post_meta( $event_id, '_mi_participant_fields', $field_configuration['enabled'] );
		update_post_meta( $event_id, '_mi_participant_required_fields', $field_configuration['required'] );
		update_post_meta( $event_id, '_mi_high_impact_approved', MI_Field_Schema::has_high_impact_fields( $field_configuration ) ? '1' : '0' );
		$scope = strtoupper( sanitize_key( wp_unslash( $_POST['participant_extra_scope'] ?? 'ONE' ) ) );
		update_post_meta( $event_id, '_mi_participant_extra_scope', 'MULTIPLE' === strtoupper( (string) ( $_POST['booking_limit_mode'] ?? 'ONE' ) ) && 'ALL' === $scope ? 'ALL' : 'ONE' );
		$question_labels = (array) wp_unslash( $_POST['custom_question_label'] ?? array() );
		$question_keys = (array) wp_unslash( $_POST['custom_question_key'] ?? array() );
		$question_types = (array) wp_unslash( $_POST['custom_question_type'] ?? array() );
		$question_required = (array) wp_unslash( $_POST['custom_question_required'] ?? array() );
		$question_options = (array) wp_unslash( $_POST['custom_question_options'] ?? array() );
		$question_retentions = (array) wp_unslash( $_POST['custom_question_retention'] ?? array() );
		$existing_questions = MI_Field_Schema::sanitize_custom_fields( get_post_meta( $event_id, '_mi_custom_participant_fields', true ) );
		$existing_questions_by_key = array_column( $existing_questions, null, 'key' );
		$submitted_question_keys = array_values( array_filter( array_map( 'sanitize_key', $question_keys ) ) );
		$custom_questions = array();
		foreach ( array_slice( $question_labels, 0, 20, true ) as $index => $label ) {
			$label = sanitize_text_field( $label );
			if ( ! $label ) continue;
			$question_key = sanitize_key( $question_keys[ $index ] ?? '' );
			if ( ! preg_match( '/^custom_[a-z0-9_-]{6,80}$/', $question_key ) ) {
				$question_key = 'custom_domanda_' . substr( str_replace( '-', '', wp_generate_uuid4() ), 0, 16 );
			}
			$existing_question = $existing_questions_by_key[ $question_key ] ?? array();
			$existing_options = implode( "\n", (array) ( $existing_question['options'] ?? array() ) );
			$custom_questions[] = array( 'key' => $question_key, 'label' => $label, 'type' => $question_types[ $index ] ?? ( $existing_question['type'] ?? 'text' ), 'options' => $question_options[ $index ] ?? $existing_options, 'required' => ! empty( $question_required[ $index ] ), 'retention' => $question_retentions[ $index ] ?? ( $existing_question['retention'] ?? 'STANDARD' ) );
		}
		foreach ( $existing_questions as $existing_question ) if ( ! in_array( $existing_question['key'], $submitted_question_keys, true ) ) $custom_questions[] = $existing_question;
		update_post_meta( $event_id, '_mi_custom_participant_fields', MI_Field_Schema::sanitize_custom_fields( $custom_questions ) );
		update_post_meta( $event_id, '_mi_special_requests_enabled', ! empty( $_POST['special_requests_enabled'] ) ? '1' : '0' );
		if ( isset( $_POST['completion_url'] ) ) update_post_meta( $event_id, '_mi_completion_url', esc_url_raw( wp_unslash( $_POST['completion_url'] ), array( 'http', 'https' ) ) );
		update_post_meta( $event_id, '_mi_marketing_enabled', ! empty( $_POST['marketing_enabled'] ) ? '1' : '0' );
		$pricing_mode = $portal_pricing_mode;
		$service_labels = array( 'colazione' => 'Colazione', 'assicurazione-disdetta' => 'Assicurazione disdetta', 'assicurazione-sanitaria' => 'Assicurazione sanitaria', 'pranzo' => 'Pranzo', 'rimborso-spese' => 'Rimborso spese' );
		$service_options = array();
		foreach ( $service_labels as $service_code => $service_label ) {
			if ( empty( $_POST['service_enabled'][ $service_code ] ) ) continue;
			$service_price = self::parse_euro_cents( wp_unslash( $_POST['service_price'][ $service_code ] ?? '' ) );
			if ( is_wp_error( $service_price ) || $service_price < 0 ) continue;
			$category = 'pranzo' === $service_code ? 'pranzo' : ( in_array( $service_code, array( 'colazione', 'assicurazione-disdetta', 'assicurazione-sanitaria' ), true ) ? 'supplemento' : 'altro' );
			$service_options[] = array( 'code' => $service_code, 'name' => $service_label, 'scope' => 'TICKET', 'price_cents' => $service_price, 'max_quantity' => 1, 'category' => $category );
		}
		$bus_route_codes  = (array) wp_unslash( $_POST['bus_route_code'] ?? array() );
		$bus_route_ids    = (array) wp_unslash( $_POST['bus_route_id'] ?? array() );
		$bus_route_prices = (array) wp_unslash( $_POST['bus_route_price'] ?? array() );
		$known_bus_routes = array();
		foreach ( array_slice( $bus_route_codes, 0, 12, true ) as $index => $route_label ) {
			$route_label = sanitize_text_field( $route_label );
			$route_id_input = sanitize_key( $bus_route_ids[ $index ] ?? '' );
			$route_price_input = trim( (string) ( $bus_route_prices[ $index ] ?? '' ) );
			if ( ! $route_label && ! $route_id_input && '' === $route_price_input ) continue;
			if ( ! $route_label ) $route_label = count( $bus_route_codes ) > 1 ? 'Tratta ' . ( $index + 1 ) : 'Pullman';
			$route_code = $route_id_input;
			if ( ! preg_match( '/^pullman(?:-[a-z0-9-]{1,64})?$/', $route_code ) ) {
				$route_code = 'pullman-' . substr( str_replace( '-', '', wp_generate_uuid4() ), 0, 16 );
			}
			if ( isset( $known_bus_routes[ $route_code ] ) ) continue;
			$route_price = self::parse_euro_cents( $bus_route_prices[ $index ] ?? '' );
			if ( is_wp_error( $route_price ) || $route_price < 0 ) continue;
			$known_bus_routes[ $route_code ] = true;
			$service_options[] = array( 'code' => $route_code, 'name' => 'Pullman' === $route_label ? 'Pullman' : 'Pullman - ' . $route_label, 'scope' => 'TICKET', 'price_cents' => $route_price, 'max_quantity' => 1, 'category' => 'pullman' );
		}
		$accommodation_labels = array( 'SINGOLA' => 'Singola', 'DOPPIA_SEPARATI' => 'Doppia con letti separati', 'DOPPIA_MATRIMONIALE' => 'Doppia matrimoniale', 'TRIPLA' => 'Tripla', 'MULTIPLA' => 'Multipla' );
		$accommodation_options = array();
		foreach ( $accommodations as $accommodation_code ) {
			$accommodation_price = self::parse_euro_cents( wp_unslash( $_POST['accommodation_price'][ $accommodation_code ] ?? '' ) );
			if ( is_wp_error( $accommodation_price ) || $accommodation_price < 0 ) continue;
			$accommodation_options[] = array( 'code' => 'alloggio-' . strtolower( str_replace( '_', '-', $accommodation_code ) ), 'name' => 'Alloggio: ' . $accommodation_labels[ $accommodation_code ], 'scope' => 'TICKET', 'price_cents' => $accommodation_price, 'max_quantity' => 1, 'category' => 'alloggio' );
		}
		$managed_option_codes = array_merge(
			array_keys( $service_labels ),
			array_values( array_map( 'sanitize_key', $bus_route_ids ) ),
			array_map( static function ( $code ) { return 'alloggio-' . strtolower( str_replace( '_', '-', $code ) ); }, array( 'SINGOLA', 'DOPPIA_SEPARATI', 'DOPPIA_MATRIMONIALE', 'TRIPLA', 'MULTIPLA' ) ),
			array_column( $extra_services, 'code' )
		);
		$existing_options = (array) get_post_meta( $event_id, '_mi_options', true );
		$unmanaged_options = array_values( array_filter( $existing_options, static function ( $option ) use ( $managed_option_codes ) { return is_array( $option ) && ! in_array( sanitize_key( $option['code'] ?? '' ), $managed_option_codes, true ); } ) );
		$priced_options = array_merge( $unmanaged_options, $accommodation_options, $service_options, $extra_services );
		if ( in_array( $pricing_mode, array( 'ZERO', 'FIXED' ), true ) ) {
			// Cambiare la quota principale non autorizza il portale a cancellare opzioni
			// avanzate create altrove e che il portale non mostra.
			$priced_options = $unmanaged_options;
			$accommodations = array();
			update_post_meta( $event_id, '_mi_overnight_enabled', '0' );
			update_post_meta( $event_id, '_mi_accommodations', array() );
		} elseif ( $priced_options ) {
			$pricing_mode = 'CALCULATED';
		}
		update_post_meta( $event_id, '_mi_pricing_mode', $pricing_mode );
		update_post_meta( $event_id, '_mi_fixed_price_cents', 'FIXED' === $pricing_mode && ! is_wp_error( $fixed_price ) ? $fixed_price : 0 );
		$booking_limit_mode = strtoupper( sanitize_key( wp_unslash( $_POST['booking_limit_mode'] ?? 'ONE' ) ) );
		$max_per_order = 'MULTIPLE' === $booking_limit_mode ? min( 20, max( 2, absint( $_POST['max_per_order'] ?? 2 ) ) ) : 1;
		$existing_ticket_types = array_values( array_filter( (array) get_post_meta( $event_id, '_mi_ticket_types', true ), 'is_array' ) );
		if ( ! $existing_ticket_types ) update_post_meta( $event_id, '_mi_ticket_types', array( array(
			'code'          => 'standard',
			'name'          => 'ZERO' === $pricing_mode ? 'Iscrizione' : 'Quota di partecipazione',
			'price_cents'   => 'FIXED' === $pricing_mode && ! is_wp_error( $fixed_price ) ? max( 0, $fixed_price ) : 0,
			'max_per_order' => $max_per_order,
			'capacity'      => 0,
		) ) );
		elseif ( 1 === count( $existing_ticket_types ) && 'standard' === sanitize_key( $existing_ticket_types[0]['code'] ?? '' ) ) {
			// Il portale gestisce il limite dell'unico ticket standard, non il suo prezzo, nome o capienza avanzata.
			$existing_ticket_types[0]['max_per_order'] = $max_per_order;
			update_post_meta( $event_id, '_mi_ticket_types', $existing_ticket_types );
		}
		update_post_meta( $event_id, '_mi_options', $priced_options );
		$economic_mode = $portal_economic_mode;
		$economic_mode = 'ZERO' === $pricing_mode ? 'REGISTRATION_ONLY' : ( in_array( $economic_mode, array( 'FULL_PAYMENT', 'DEPOSIT_BALANCE' ), true ) ? $economic_mode : 'FULL_PAYMENT' );
		update_post_meta( $event_id, '_mi_economic_mode', $economic_mode );
		$deposit_mode = $portal_deposit_mode;
		update_post_meta( $event_id, '_mi_deposit_mode', $deposit_mode );
		update_post_meta( $event_id, '_mi_deposit_percentage', min( 99, max( 1, absint( $_POST['deposit_percentage'] ?? 30 ) ) ) );
		update_post_meta( $event_id, '_mi_deposit_fixed_cents', 'FIXED' === $deposit_mode && ! is_wp_error( $deposit_fixed ) ? max( 0, $deposit_fixed ) : 0 );
		$payment_methods = array_values( array_intersect( array( 'BANK_TRANSFER', 'CARD', 'CASH' ), array_map( 'strtoupper', array_map( 'sanitize_key', (array) wp_unslash( $_POST['payment_methods'] ?? array() ) ) ) ) );
		update_post_meta( $event_id, '_mi_payment_methods', in_array( $economic_mode, array( 'FULL_PAYMENT', 'DEPOSIT_BALANCE' ), true ) ? $payment_methods : array() );
		if ( isset( $_POST['event_email_style_present'] ) ) {
			$email_style = array();
			if ( ! empty( $_POST['event_email_identity_enabled'] ) ) $email_style = array( 'identity_name' => $_POST['event_email_identity_name'] ?? '', 'identity_detail' => $_POST['event_email_identity_detail'] ?? '', 'signature' => $_POST['event_email_signature'] ?? '' );
			if ( ! empty( $_POST['event_email_colors_enabled'] ) ) $email_style = array_merge( $email_style, array( 'primary_color' => $_POST['event_email_primary_color'] ?? '', 'secondary_color' => $_POST['event_email_secondary_color'] ?? '' ) );
			if ( ! empty( $_POST['event_email_banner_enabled'] ) ) $email_style['banner_url'] = $_POST['event_email_banner_url'] ?? '';
			$email_style = MI_Modello_Email::logo_override( $email_style, $_POST['event_email_logo_mode'] ?? null, get_post_meta( $event_id, '_mi_email_style', true ) );
			$email_style = MI_Modello_Email::sanitizza_stile( wp_unslash( $email_style ) );
			if ( $email_style ) update_post_meta( $event_id, '_mi_email_style', $email_style ); else delete_post_meta( $event_id, '_mi_email_style' );
		}
		$email_result = MI_Modello_Email::salva_testo_portale( $event_id, $_POST['confirmation_email_subject'] ?? '', $_POST['confirmation_email_text'] ?? '' );
		if ( is_wp_error( $email_result ) ) return self::redirect_result( 'I dati dell’evento sono stati salvati, ma il testo dell’email richiede una correzione: ' . $email_result->get_error_message(), true, $event_id );
		update_post_meta( $event_id, '_mi_event_qr_enabled', ! empty( $_POST['event_qr_enabled'] ) ? '1' : '0' );
		$upload_warning = self::save_cover_upload( $event_id );
		$is_published_edit = $existing_event && 'publish' === $existing_event->post_status;
		$success_message = $is_published_edit ? 'Modifiche salvate.' : ( $existing_event ? 'Bozza aggiornata correttamente.' : 'Bozza creata correttamente.' );
		if ( $is_published_edit ) {
			$revision = MI_Registration_Service::ensure_published_revision( $event_id, true );
			if ( ! $revision ) return self::redirect_result( 'Le modifiche sono state salvate, ma non è stato possibile aggiornare la configurazione pubblica. Riprova.', true, $event_id );
			self::accoda_evento_workspace( $event_id );
			$success_message = 'Salvato in WordPress · sincronizzazione Google in attesa.';
		}
		self::redirect_result( $upload_warning ? $success_message . ' Immagine non caricata: ' . $upload_warning : $success_message, false, $event_id, ! $is_published_edit );
	}

	private static function handle_event_outputs_action() {
		if ( ! is_user_logged_in() || ( ! current_user_can( 'mi_manage_events' ) && ! current_user_can( 'manage_options' ) ) ) wp_die( 'Accesso non consentito.', 403 );
		$event_id = absint( $_POST['event_id'] ?? 0 );
		check_admin_referer( 'mi_portal_prepare_event_outputs_' . $event_id, 'mi_portal_nonce' );
		$event = get_post( $event_id );
		if ( ! $event || MI_Event_Post_Type::EVENT_TYPE !== $event->post_type || ! MI_Access::can_access_event( $event_id ) ) wp_die( 'Evento non accessibile.', 403 );
		$result = self::prepara_produzioni_workspace( $event_id, 'BOZZA' );
		if ( is_wp_error( $result ) ) return self::redirect_result( 'Il foglio Google non è stato creato: ' . $result->get_error_message(), true, $event_id );
		return self::redirect_result( 'Foglio Google collegato. Ora puoi pubblicare l’evento.', false, $event_id, true );
	}

	/** Verifica il collegamento e ricrea dai dati centrali un foglio mancante. */
	private static function handle_event_sheet_repair_action() {
		if ( ! is_user_logged_in() || ( ! current_user_can( 'mi_manage_events' ) && ! current_user_can( 'manage_options' ) ) ) wp_die( 'Accesso non consentito.', 403 );
		$event_id = absint( $_POST['event_id'] ?? 0 );
		check_admin_referer( 'mi_portal_repair_event_sheet_' . $event_id, 'mi_portal_nonce' );
		if ( ! $event_id || ! MI_Access::can_access_event( $event_id ) ) wp_die( 'Evento non accessibile.', 403 );
		$verifica = MI_Workspace_Client::request( 'VERIFICA_FOGLIO_EVENTO', array( 'id_evento' => (string) $event_id, 'id_foglio' => (string) get_post_meta( $event_id, '_mi_operational_sheet_id', true ), 'direct_projection' => true ) );
		if ( is_wp_error( $verifica ) ) return self::redirect_result( 'Non è stato possibile verificare il foglio: ' . $verifica->get_error_message(), true, $event_id, true );
		if ( ! empty( $verifica['esiste'] ) ) return self::redirect_result( 'Il foglio Google è disponibile e correttamente collegato.', false, $event_id, true );
		update_post_meta( $event_id, '_mi_sheet_missing', '1' );
		delete_post_meta( $event_id, '_mi_operational_sheet_id' );
		delete_post_meta( $event_id, '_mi_operational_sheet_url' );
		$ricreato = self::prepara_produzioni_workspace( $event_id, 'publish' === get_post_status( $event_id ) ? 'PUBBLICATO' : 'BOZZA' );
		if ( is_wp_error( $ricreato ) ) return self::redirect_result( 'Il foglio non è disponibile e non è stato possibile ricrearlo: ' . $ricreato->get_error_message(), true, $event_id, true );
		return self::redirect_result( 'Il foglio mancante è stato ricreato dai dati autorevoli conservati in MySQL.', false, $event_id, true );
	}

	/** Crea o riallinea il foglio operativo e conserva tutti i collegamenti restituiti. */
	private static function accoda_evento_workspace( $event_id ) {
		update_post_meta( $event_id, '_mi_workspace_event_pending', wp_generate_uuid4() );
		update_post_meta( $event_id, '_mi_workspace_event_attempts', 0 );
		delete_post_meta( $event_id, '_mi_workspace_event_error' );
		self::pianifica_evento_workspace( $event_id, 30 );
	}

	private static function pianifica_evento_workspace( $event_id, $delay ) {
		$args = array( absint( $event_id ) );
		if ( ! wp_next_scheduled( 'mi_sync_workspace_event', $args ) ) wp_schedule_single_event( time() + $delay, 'mi_sync_workspace_event', $args );
	}

	public static function sincronizza_evento_in_coda( $event_id ) {
		$event_id = absint( $event_id );
		$token = (string) get_post_meta( $event_id, '_mi_workspace_event_pending', true );
		if ( ! $token || 'publish' !== get_post_status( $event_id ) ) return;
		// Legge sempre la configurazione corrente, accorpando i salvataggi ravvicinati.
		$result = self::prepara_produzioni_workspace( $event_id, 'PUBBLICATO' );
		if ( $token !== (string) get_post_meta( $event_id, '_mi_workspace_event_pending', true ) ) {
			self::pianifica_evento_workspace( $event_id, 30 );
			return;
		}
		if ( ! is_wp_error( $result ) ) {
			delete_post_meta( $event_id, '_mi_workspace_event_pending', $token );
			delete_post_meta( $event_id, '_mi_workspace_event_error' );
			delete_post_meta( $event_id, '_mi_workspace_event_attempts' );
			MI_Sheet_Open::enqueue( $event_id );
			return;
		}
		$attempts = 1 + absint( get_post_meta( $event_id, '_mi_workspace_event_attempts', true ) );
		update_post_meta( $event_id, '_mi_workspace_event_attempts', $attempts );
		update_post_meta( $event_id, '_mi_workspace_event_error', sanitize_text_field( $result->get_error_message() ) );
		self::pianifica_evento_workspace( $event_id, min( 3600, 30 * ( 2 ** min( $attempts, 7 ) ) ) );
	}

	private static function prepara_produzioni_workspace( $event_id, $stato ) {
		if ( class_exists( 'MI_Event_Deletion' ) ) { $lease = MI_Event_Deletion::enter( $event_id ); if ( is_wp_error( $lease ) ) return $lease; }
		$event = get_post( $event_id );
		if ( ! $event || MI_Event_Post_Type::EVENT_TYPE !== $event->post_type ) return new WP_Error( 'mi_evento_non_valido', 'Evento non valido.' );
		$gestore = self::risolvi_gestore_evento( $event_id, false );
		$url_iscrizione = MI_Shortcode::url_iscrizione( $event_id );
		$ha_saldo = 'DEPOSIT_BALANCE' === get_post_meta( $event_id, '_mi_economic_mode', true );
		$url_saldo = $ha_saldo ? add_query_arg( array( 'mi_status' => 'balance', 'evento' => $event_id ), home_url( '/' ) ) : '';
		// Google serializza la preparazione con la cancellazione tramite tombstone.
		// Non bloccare le iscrizioni mentre aspettiamo la risposta remota.
		if ( class_exists( 'MI_Event_Deletion' ) ) MI_Event_Deletion::release( $event_id );
		try { $request = MI_Event_Projection::request_payload( $event_id ); }
		catch ( Throwable $error ) { return new WP_Error( 'mi_proiezione_evento', $error->getMessage() ); }
		$result = MI_Workspace_Client::request( 'PROIETTA_EVENTO', $request['payload'] );
		if ( is_wp_error( $result ) ) return $result;
		$sheet_id = sanitize_text_field( (string) ( $result['id_foglio'] ?? '' ) );
		if ( class_exists( 'MI_Event_Deletion' ) ) { $lease = MI_Event_Deletion::enter( $event_id ); if ( is_wp_error( $lease ) ) return $lease; }
		$sheet_url = esc_url_raw( (string) ( $result['url_foglio'] ?? '' ) );
		if ( ! preg_match( '~^https://docs\.google\.com/spreadsheets/d/([A-Za-z0-9_-]{20,})(?:/|$)~D', $sheet_url, $sheet_match ) || ! hash_equals( $sheet_id, $sheet_match[1] ) ) return new WP_Error( 'mi_foglio_non_valido', 'Workspace non ha restituito un collegamento al foglio valido.' );
		update_post_meta( $event_id, '_mi_operational_sheet_id', $sheet_id );
		update_post_meta( $event_id, '_mi_operational_sheet_url', $sheet_url );
		update_post_meta( $event_id, '_mi_registration_url', esc_url_raw( $url_iscrizione ) );
		if ( $url_saldo ) update_post_meta( $event_id, '_mi_balance_url', esc_url_raw( $url_saldo ) );
		else delete_post_meta( $event_id, '_mi_balance_url' );
		update_post_meta( $event_id, '_mi_outputs_prepared_at', current_time( 'mysql', true ) );
		delete_post_meta( $event_id, '_mi_sheet_missing' );
		if ( $gestore ) update_post_meta( $event_id, '_mi_manager_user_id', $gestore->ID );
		else delete_post_meta( $event_id, '_mi_manager_user_id' );
		// Certifica la proiezione anche a zero iscrizioni, prima del primo Apri.
		MI_Sheet_Open::enqueue( $event_id );
		return $result;
	}


	/** Individua un solo gestore responsabile, senza ampliare implicitamente l'accesso ai dati. */
	private static function risolvi_gestore_evento( $event_id, $obbligatorio ) {
		$event_id = absint( $event_id );
		$stored_id = absint( get_post_meta( $event_id, '_mi_manager_user_id', true ) );
		$candidates = array();
		if ( $stored_id ) $candidates[] = $stored_id;
		$author_id = absint( get_post_field( 'post_author', $event_id ) );
		if ( $author_id ) $candidates[] = $author_id;
		$manager_roles = array( 'mi_group_manager', 'mi_assigned_event_manager' );
		$users = get_users( array( 'role__in' => $manager_roles, 'fields' => array( 'ID', 'user_email', 'roles' ) ) );
		foreach ( $users as $user ) {
			if ( ! MI_Access::is_suspended( $user->ID ) && MI_Access::can_access_event( $event_id, $user->ID ) ) $candidates[] = $user->ID;
		}
		$candidates = array_values( array_unique( array_filter( array_map( 'absint', $candidates ) ) ) );
		$valid = array();
		foreach ( $candidates as $user_id ) {
			$user = get_user_by( 'id', $user_id );
			if ( ! $user || ! is_email( $user->user_email ) || MI_Access::is_suspended( $user_id ) || ! MI_Access::can_access_event( $event_id, $user_id ) ) continue;
			if ( ! array_intersect( $manager_roles, (array) $user->roles ) ) continue;
			$valid[ $user_id ] = $user;
		}
		if ( $stored_id && isset( $valid[ $stored_id ] ) ) return $valid[ $stored_id ];
		if ( $author_id && isset( $valid[ $author_id ] ) ) return $valid[ $author_id ];
		if ( 1 === count( $valid ) ) return reset( $valid );
		if ( ! $obbligatorio ) return null;
		return new WP_Error( 'mi_gestore_evento_ambiguo', $valid ? 'Al gruppo risultano assegnati più gestori. Indica un solo responsabile prima di pubblicare.' : 'Assegna al gruppo un gestore con un indirizzo email valido prima di pubblicare.' );
	}

	private static function handle_event_publication_action() {
		if ( ! is_user_logged_in() || ( ! current_user_can( 'mi_publish_events' ) && ! current_user_can( 'manage_options' ) ) ) wp_die( 'Non disponi del permesso per pubblicare eventi.', 403 );
		$event_id = absint( $_POST['event_id'] ?? 0 );
		check_admin_referer( 'mi_portal_publish_event_' . $event_id, 'mi_portal_nonce' );
		$event = get_post( $event_id );
		if ( ! $event || MI_Event_Post_Type::EVENT_TYPE !== $event->post_type || 'draft' !== $event->post_status || ! MI_Access::can_access_event( $event_id ) ) return self::redirect_result( 'La bozza non è pubblicabile.', true, $event_id, true );
		$configuration = MI_Registration_Service::public_event( $event_id, true );
		if ( is_wp_error( $configuration ) ) return self::redirect_result( 'Completa la configurazione prima di pubblicare: ' . $configuration->get_error_message(), true, $event_id, true );
		$dates = MI_Registration_Service::validate_event_dates( $configuration );
		if ( is_wp_error( $dates ) ) return self::redirect_result( $dates->get_error_message(), true, $event_id, true );
		$preparazione = self::prepara_produzioni_workspace( $event_id, 'BOZZA' );
		if ( is_wp_error( $preparazione ) ) return self::redirect_result( 'L’evento è ancora in bozza: non abbiamo ricevuto conferma che il foglio Google sia pronto. ' . $preparazione->get_error_message() . ' I dati dell’evento sono conservati. Puoi riprovare la pubblicazione: se il foglio è già stato creato, sarà riutilizzato.', true, $event_id, true );
		$publication_error_key = 'mi_publication_error_' . get_current_user_id();
		delete_transient( $publication_error_key );
		$result = wp_update_post( array( 'ID' => $event_id, 'post_status' => 'publish' ), true );
		if ( is_wp_error( $result ) || 'publish' !== get_post_status( $event_id ) ) {
			$publication_error = (string) get_transient( $publication_error_key );
			delete_transient( $publication_error_key );
			$message = $publication_error ? 'L’evento è rimasto in bozza: ' . $publication_error : 'WordPress non ha potuto pubblicare l’evento.';
			return self::redirect_result( $message, true, $event_id, true );
		}
		MI_Registration_Service::ensure_published_revision( $event_id, true );
		// La preparazione BOZZA ha già creato il foglio. Accoda l'aggiornamento
		// dello stato pubblicato per non tenere aperta la richiesta dell'utente.
		self::accoda_evento_workspace( $event_id );
		$workspace = $preparazione;
		$gestore = self::risolvi_gestore_evento( $event_id, false );
		$email_segreteria = sanitize_email( get_option( 'mi_email_segreteria_eventi', '' ) ) ?: sanitize_email( get_option( 'admin_email', '' ) );
		$notifica = MI_Spedizione_Email::accoda_notifiche_attivazione_evento( $event_id, $gestore, (string) ( $workspace['url_foglio'] ?? '' ), $email_segreteria );
		if ( is_wp_error( $notifica ) ) return self::redirect_result( 'Evento pubblicato e foglio Google collegato; non è stato possibile preparare la comunicazione di attivazione: ' . $notifica->get_error_message(), true, $event_id, true );
		return self::redirect_result( 'Evento pubblicato. Foglio Google collegato e comunicazione di attivazione preparata ai destinatari previsti in modalità ' . esc_html( $notifica['mode'] ?? 'ANTEPRIMA' ) . '.', false, $event_id, true );
	}

	private static function handle_communication_action() {
		if ( ! is_user_logged_in() || ( ! current_user_can( 'mi_manage_communications' ) && ! current_user_can( 'manage_options' ) ) ) wp_die( 'Accesso non consentito.', 403 );
		check_admin_referer( 'mi_portal_prepare_communication', 'mi_portal_nonce' );
		$token = sanitize_key( $_POST['communication_token'] ?? '' );
		$draft = $token ? get_transient( 'mi_comm_' . get_current_user_id() . '_' . $token ) : false;
		if ( $token && ( ! is_array( $draft ) || $draft['mode'] !== MI_Spedizione_Email::modalita() ) ) return self::redirect_portal_result( 'Anteprima scaduta o modalità cambiata. Prepara nuovamente la comunicazione.', true, 'communications' );
		$input = $token ? $draft : wp_unslash( $_POST );
		$event_id = absint( $input['event_id'] ?? 0 );
		if ( ! $event_id || ! MI_Access::can_access_event( $event_id ) ) wp_die( 'Evento non accessibile.', 403 );
		$template = strtoupper( sanitize_key( $input['template_type'] ?? '' ) );
		$allowed_templates = array_merge( array( 'PRE_DEPARTURE_REMINDER', 'BALANCE_REMINDER' ), array_keys( self::custom_communication_types() ) );
		if ( ! in_array( $template, $allowed_templates, true ) ) return self::redirect_portal_result( 'Tipo di comunicazione non valido.', true, 'communications' );
		$message = mb_substr( sanitize_textarea_field( $input['message'] ?? '' ), 0, 4000 );
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id,order_code,buyer_email,total_cents,economic_mode FROM {$wpdb->prefix}mi_registrations WHERE event_id=%d AND status IN ('CONFIRMED','PENDING_PAYMENT') AND capacity_released_at IS NULL ORDER BY id LIMIT 1001", $event_id ), ARRAY_A );
		if ( $wpdb->last_error || ! is_array( $rows ) ) return self::redirect_portal_result( 'Destinatari non disponibili. Nessun invio preparato.', true, 'communications' );
		if ( count( $rows ) > 1000 ) return self::redirect_portal_result( 'Oltre 1000 prenotazioni: invio non disponibile da questa schermata.', true, 'communications' );
		if ( $wpdb->last_error || ! is_array( $rows ) ) return self::redirect_result( 'Iscrizioni non disponibili. Annullamento non eseguito.', true, $event_id );
		$recipients = array();
		try { $positions = MI_Payment_Ledger::positions( $rows ); }
		catch ( Throwable $error ) { return self::redirect_portal_result( 'Saldo non disponibile. Nessuna comunicazione preparata.', true, 'communications' ); }
		foreach ( $rows as $row ) { $position = $positions[$row['id']]; if ( 'BALANCE_REMINDER' === $template && ( ! $position['managed'] || $position['effective_balance'] < 1 ) ) continue; $recipients[] = array( 'order_code' => $row['order_code'], 'paid_cents' => $position['effective_paid'], 'balance_cents' => $position['managed'] ? $position['effective_balance'] : 0 ); }
		$fingerprint = hash( 'sha256', wp_json_encode( array( get_post_status( $event_id ), $rows, $recipients ) ) );
		if ( ! $token ) {
			if ( ! $recipients ) return self::redirect_portal_result( 'Nessun destinatario corrisponde ai criteri.', true, 'communications' );
			if ( 'BALANCE_REMINDER' !== $template && ! trim( $message ) ) return self::redirect_portal_result( 'Inserisci il messaggio.', true, 'communications' );
			$token = strtolower( wp_generate_password( 32, false, false ) );
			set_transient( 'mi_comm_' . get_current_user_id() . '_' . $token, array( 'event_id' => $event_id, 'template_type' => $template, 'message' => $message, 'mode' => MI_Spedizione_Email::modalita(), 'fingerprint' => $fingerprint, 'count' => count( $recipients ), 'emails' => array_values( array_unique( array_column( array_filter( $rows, function( $row ) use ( $recipients ) { return in_array( $row['order_code'], array_column( $recipients, 'order_code' ), true ); } ), 'buyer_email' ) ) ) ), 30 * MINUTE_IN_SECONDS );
			wp_safe_redirect( add_query_arg( array( 'mi_portal_view' => 'communications', 'mi_comm_preview' => $token ), self::base_url() ) );
			exit;
		}
		if ( ! hash_equals( $draft['fingerprint'], $fingerprint ) ) return self::redirect_portal_result( 'Destinatari o saldi cambiati. Prepara una nuova anteprima prima di inviare.', true, 'communications' );
		$result = MI_Spedizione_Email::accoda_comunicazione_operativa( array(
			'communication_id' => 'portal-' . get_current_user_id() . '-' . $token,
			'event_id' => $event_id, 'template_type' => $template, 'message' => $message,
			'allow_operational' => true, 'recipients' => $recipients,
		) );
		if ( is_wp_error( $result ) ) return self::redirect_portal_result( $result->get_error_message(), true, 'communications' );
		delete_transient( 'mi_comm_' . get_current_user_id() . '_' . $token );
		$test_queued = 'PROVA' === ( $result['mode'] ?? '' ) && 'TEST_PENDING' === MI_Spedizione_Email::stato_nuova_email( array( 'attivo' => true ) );
		$delivery_notice = $test_queued ? ' Invio previsto esclusivamente all’indirizzo configurato per i test, non ai destinatari reali.' : ( 'OPERATIVO' === ( $result['mode'] ?? '' ) ? ' Invio ai destinatari reali inserito in coda.' : ' Comunicazioni preparate senza invio.' );
		return self::redirect_portal_result( 'Comunicazioni preparate: ' . absint( $result['count'] ?? 0 ) . '.' . $delivery_notice, false, 'communications' );
	}

	private static function handle_communication_type_action( $action ) {
		if ( ! is_user_logged_in() || ( ! current_user_can( 'mi_manage_all_events' ) && ! current_user_can( 'manage_options' ) ) ) wp_die( 'Solo un Gestore iscrizioni può modificare i tipi di comunicazione.', 403 );
		check_admin_referer( 'mi_portal_manage_communication_types', 'mi_portal_nonce' );
		$types = self::custom_communication_types();
		if ( 'add_communication_type' === $action ) {
			$label = mb_substr( sanitize_text_field( wp_unslash( $_POST['communication_type_label'] ?? '' ) ), 0, 80 );
			if ( ! $label ) return self::redirect_portal_result( 'Indica il nome del nuovo tipo di comunicazione.', true, 'communications' );
			$base = strtoupper( str_replace( '-', '_', sanitize_title( $label ) ) );
			$base = preg_replace( '/[^A-Z0-9_]/', '', $base );
			$code = 'CUSTOM_' . substr( $base ?: 'MESSAGGIO', 0, 24 );
			if ( isset( $types[ $code ] ) ) return self::redirect_portal_result( 'Esiste già un tipo di comunicazione con questo nome.', true, 'communications' );
			$types[ $code ] = $label;
			update_option( self::CUSTOM_COMMUNICATION_TYPES_OPTION, $types, false );
			return self::redirect_portal_result( 'Nuovo tipo di comunicazione salvato.', false, 'communications' );
		}
		$code = strtoupper( sanitize_key( wp_unslash( $_POST['communication_type_code'] ?? '' ) ) );
		if ( ! isset( $types[ $code ] ) ) return self::redirect_portal_result( 'Il tipo personalizzato non esiste.', true, 'communications' );
		unset( $types[ $code ] );
		update_option( self::CUSTOM_COMMUNICATION_TYPES_OPTION, $types, false );
		return self::redirect_portal_result( 'Tipo di comunicazione eliminato. Le comunicazioni storiche restano conservate.', false, 'communications' );
	}

	private static function custom_communication_types() {
		$stored = get_option( self::CUSTOM_COMMUNICATION_TYPES_OPTION, array() );
		$types = array();
		foreach ( is_array( $stored ) ? $stored : array() as $code => $label ) {
			$code = strtoupper( sanitize_key( (string) $code ) );
			$label = mb_substr( sanitize_text_field( (string) $label ), 0, 80 );
			if ( preg_match( '/^CUSTOM_[A-Z0-9_]{1,24}$/', $code ) && $label ) $types[ $code ] = $label;
		}
		return $types;
	}

	private static function operator_roles() {
		return array(
			'mi_registration_manager'   => 'Gestore iscrizioni — tutto il servizio',
			'mi_group_manager'          => 'Gestore gruppo — gruppi assegnati',
			'mi_assigned_event_manager' => 'Gestore evento — eventi assegnati',
		);
	}

	private static function can_manage_module_users() {
		return current_user_can( 'manage_options' ) || current_user_can( 'mi_manage_module_users' );
	}

	private static function save_operator_scope( $user_id, $role, $groups, $events ) {
		$previous_events = get_user_meta( $user_id, '_mi_event_scope', true );
		$previous_events = array_values( array_filter( array_map( 'absint', is_array( $previous_events ) ? $previous_events : array() ) ) );
		if ( 'mi_group_manager' === $role ) update_user_meta( $user_id, '_mi_activity_scope', $groups ); else delete_user_meta( $user_id, '_mi_activity_scope' );
		if ( 'mi_assigned_event_manager' === $role ) {
			update_user_meta( $user_id, '_mi_event_scope', $events );
			foreach ( $events as $event_id ) update_post_meta( $event_id, '_mi_manager_user_id', $user_id );
		} else {
			$events = array();
			delete_user_meta( $user_id, '_mi_event_scope' );
		}
		foreach ( array_diff( $previous_events, $events ) as $event_id ) {
			if ( $user_id === absint( get_post_meta( $event_id, '_mi_manager_user_id', true ) ) ) delete_post_meta( $event_id, '_mi_manager_user_id' );
		}
	}

	private static function limit_text_lines( $value, $maximum_lines, $maximum_characters ) {
		$lines = preg_split( '/\R/u', (string) $value );
		$lines = array_slice( is_array( $lines ) ? $lines : array(), 0, max( 1, (int) $maximum_lines ) );
		return mb_substr( implode( "\n", $lines ), 0, max( 1, (int) $maximum_characters ) );
	}

	private static function handle_operator_action( $action ) {
		if ( ! is_user_logged_in() || ! self::can_manage_module_users() ) wp_die( 'Solo un amministratore o un Gestore iscrizioni può gestire gli operatori.', 403 );
		check_admin_referer( 'mi_portal_manage_operators', 'mi_portal_nonce' );
		$roles = self::operator_roles();
		$role = sanitize_key( wp_unslash( $_POST['operator_role'] ?? '' ) );
		if ( ! isset( $roles[ $role ] ) ) return self::redirect_portal_result( 'Ruolo non valido.', true, 'operators' );
		$password = (string) wp_unslash( $_POST['operator_password'] ?? '' );
		$groups = isset( $_POST['operator_groups'] ) ? array_values( array_unique( array_filter( array_map( 'absint', (array) wp_unslash( $_POST['operator_groups'] ) ) ) ) ) : array();
		$events = isset( $_POST['operator_events'] ) ? array_values( array_unique( array_filter( array_map( 'absint', (array) wp_unslash( $_POST['operator_events'] ) ) ) ) ) : array();
		$groups = array_values( array_filter( $groups, static function ( $group_id ) { return MI_Event_Post_Type::GROUP_TYPE === get_post_type( $group_id ); } ) );
		$events = array_values( array_filter( $events, static function ( $event_id ) { return MI_Event_Post_Type::EVENT_TYPE === get_post_type( $event_id ); } ) );
		if ( 'mi_group_manager' === $role && ! $groups ) return self::redirect_portal_result( 'Assegna almeno un gruppo al Gestore gruppo.', true, 'operators' );
		if ( 'mi_assigned_event_manager' === $role && ! $events ) return self::redirect_portal_result( 'Assegna almeno un evento al Gestore evento.', true, 'operators' );
		if ( 'create_operator' === $action ) {
			$username = sanitize_user( wp_unslash( $_POST['operator_username'] ?? '' ), true );
			$email = sanitize_email( wp_unslash( $_POST['operator_email'] ?? '' ) );
			$name = mb_substr( sanitize_text_field( wp_unslash( $_POST['operator_name'] ?? '' ) ), 0, 120 );
			if ( ! $username || ! is_email( $email ) ) return self::redirect_portal_result( 'Indica un codice utente e un indirizzo email validi.', true, 'operators' );
			if ( strlen( $password ) < 12 ) return self::redirect_portal_result( 'La parola d’accesso deve contenere almeno 12 caratteri.', true, 'operators' );
			$user_id = wp_insert_user( array( 'user_login' => $username, 'user_email' => $email, 'display_name' => $name ?: $username, 'user_pass' => $password, 'role' => $role ) );
			if ( is_wp_error( $user_id ) ) return self::redirect_portal_result( $user_id->get_error_message(), true, 'operators' );
			self::save_operator_scope( $user_id, $role, $groups, $events );
			delete_user_meta( $user_id, '_mi_access_suspended' );
			return self::redirect_portal_result( 'Operatore creato. La parola d’accesso non viene mostrata né inviata per email.', false, 'operators' );
		}
		$user_id = absint( $_POST['operator_id'] ?? 0 );
		$user = get_user_by( 'id', $user_id );
		if ( ! $user || user_can( $user, 'manage_options' ) || $user_id === get_current_user_id() || ! array_intersect( array_keys( $roles ), (array) $user->roles ) ) return self::redirect_portal_result( 'Operatore non modificabile.', true, 'operators' );
		$update = array( 'ID' => $user_id, 'role' => $role );
		$email = sanitize_email( wp_unslash( $_POST['operator_email'] ?? '' ) );
		$name = mb_substr( sanitize_text_field( wp_unslash( $_POST['operator_name'] ?? '' ) ), 0, 120 );
		if ( ! is_email( $email ) ) return self::redirect_portal_result( 'Indirizzo email non valido.', true, 'operators' );
		$update['user_email'] = $email;
		$update['display_name'] = $name ?: $user->user_login;
		if ( '' !== $password ) {
			if ( strlen( $password ) < 12 ) return self::redirect_portal_result( 'La nuova parola d’accesso deve contenere almeno 12 caratteri.', true, 'operators' );
			$update['user_pass'] = $password;
		}
		$result = wp_update_user( $update );
		if ( is_wp_error( $result ) ) return self::redirect_portal_result( $result->get_error_message(), true, 'operators' );
		self::save_operator_scope( $user_id, $role, $groups, $events );
		if ( ! empty( $_POST['operator_suspended'] ) ) update_user_meta( $user_id, '_mi_access_suspended', '1' ); else delete_user_meta( $user_id, '_mi_access_suspended' );
		return self::redirect_portal_result( 'Operatore aggiornato.', false, 'operators' );
	}

	private static function redirect_portal_result( $message, $error, $view ) {
		wp_safe_redirect( add_query_arg( array( 'mi_portal' => '1', 'mi_portal_view' => sanitize_key( $view ), 'mi_portal_message' => $message, 'mi_portal_error' => $error ? '1' : '0' ), self::url() ) );
		exit;
	}

	private static function handle_event_management_action( $action ) {
		if ( ! is_user_logged_in() || ( ! current_user_can( 'mi_manage_events' ) && ! current_user_can( 'manage_options' ) ) ) wp_die( 'Accesso non consentito.', 403 );
		$event_id = absint( $_POST['event_id'] ?? 0 );
		if ( ! $event_id || ! MI_Access::can_access_event( $event_id ) ) wp_die( 'Evento non accessibile.', 403 );
		check_admin_referer( 'mi_portal_manage_event_' . $event_id, 'mi_portal_nonce' );
		if ( class_exists( 'MI_Event_Deletion' ) ) { $lease = MI_Event_Deletion::enter( absint( $_POST['event_id'] ?? 0 ) ); if ( is_wp_error( $lease ) ) wp_die( esc_html( $lease->get_error_message() ), '', array( 'response' => 409 ) ); }
		if ( 'duplicate_event' === $action ) {
			$result = MI_Event_Duplicator::duplicate( $event_id, sanitize_text_field( wp_unslash( $_POST['duplicate_request'] ?? '' ) ) );
			if ( is_wp_error( $result ) ) return self::redirect_result( $result->get_error_message(), true, $event_id );
			return self::redirect_result( 'Bozza creata: ' . get_the_title( $result ) . '. Date e impostazioni sono state mantenute.', false, $result );
		}
		if ( 'archive_event' === $action ) {
			if ( ! get_post_meta( $event_id, '_mi_event_cancelled_at', true ) ) return self::redirect_result( 'Soltanto un evento annullato può essere archiviato.', true, $event_id );
			update_post_meta( $event_id, '_mi_event_archived_at', current_time( 'mysql', true ) );
			return self::redirect_result( 'Evento annullato spostato nello storico.', false );
		}
		if ( 'trash_event' === $action ) {
			$event = get_post( $event_id );
			if ( ! $event || 'draft' !== $event->post_status ) return self::redirect_result( 'Soltanto una bozza può essere spostata nel cestino.', true, $event_id );
			global $wpdb;
			$registration_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}mi_registrations WHERE event_id=%d", $event_id ) );
			if ( $registration_count > 0 ) return self::redirect_result( 'La bozza possiede iscrizioni e non può essere eliminata. Puoi conservarla nello storico.', true, $event_id );
			if ( ! wp_trash_post( $event_id ) ) return self::redirect_result( 'Non è stato possibile spostare la bozza nel cestino.', true, $event_id );
			return self::redirect_result( 'Bozza spostata nel cestino. Puoi ripristinarla oppure eliminarla definitivamente con la procedura «Elimina evento e dati».', false );
		}
		if ( 'update_event' === $action ) {
			$title = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );
			if ( ! $title ) return self::redirect_result( 'Il titolo è obbligatorio.', true, $event_id );
			$starts_at = sanitize_text_field( wp_unslash( $_POST['starts_at'] ?? '' ) );
			$opens_at = sanitize_text_field( wp_unslash( $_POST['opens_at'] ?? get_post_meta( $event_id, '_mi_registration_opens_at', true ) ) );
			$closes_at = sanitize_text_field( wp_unslash( $_POST['closes_at'] ?? '' ) );
			$dates = MI_Registration_Service::validate_event_dates( array( 'opens_at' => $opens_at, 'closes_at' => $closes_at, 'event_starts_at' => $starts_at ) );
			if ( is_wp_error( $dates ) ) return self::redirect_result( $dates->get_error_message(), true, $event_id );
			wp_update_post( array( 'ID' => $event_id, 'post_title' => $title ) );
			update_post_meta( $event_id, '_mi_event_location', mb_substr( sanitize_text_field( wp_unslash( $_POST['location'] ?? '' ) ), 0, 180 ) );
			update_post_meta( $event_id, '_mi_capacity', min( 10000, max( 1, absint( $_POST['capacity'] ?? 1 ) ) ) );
			self::save_date( $event_id, '_mi_event_starts_at', $starts_at );
			self::save_date( $event_id, '_mi_registration_opens_at', $opens_at );
			self::save_date( $event_id, '_mi_registration_closes_at', $closes_at );
			if ( 'publish' === get_post_status( $event_id ) ) {
				MI_Registration_Service::ensure_published_revision( $event_id, true );
				self::accoda_evento_workspace( $event_id );
			}
			return self::redirect_result( 'Dettagli dell’evento aggiornati.', false, $event_id );
		}
		if ( empty( $_POST['confirm_cancellation'] ) ) return self::redirect_result( 'Conferma esplicitamente l’annullamento dell’evento.', true, $event_id );
		$reason = mb_substr( sanitize_textarea_field( wp_unslash( $_POST['cancellation_reason'] ?? '' ) ), 0, 2000 );
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id,order_code,status,total_cents,economic_mode FROM {$wpdb->prefix}mi_registrations WHERE event_id=%d AND status IN ('CONFIRMED','PENDING_PAYMENT','WAITLISTED','WAITLIST_OFFERED') AND capacity_released_at IS NULL ORDER BY id", $event_id ), ARRAY_A );
		$recipients = array();
		try { $positions = MI_Payment_Ledger::positions( $rows ); }
		catch ( Throwable $error ) { return self::redirect_result( 'Saldo non disponibile. Annullamento non eseguito.', true, $event_id ); }
		foreach ( $rows as $row ) { $position = $positions[$row['id']]; $recipients[] = array( 'order_code' => $row['order_code'], 'paid_cents' => $position['effective_paid'], 'balance_cents' => $position['managed'] ? $position['effective_balance'] : 0 ); }
		if ( $wpdb->last_error ) return self::redirect_result( 'Iscrizioni non disponibili. Annullamento non eseguito.', true, $event_id );
		// Il lock evento protegge l'elenco persistente dei destinatari e i relativi tentativi di invio.
		$job = get_post_meta( $event_id, '_mi_event_cancellation_job', true );
		if ( ! is_array( $job ) ) {
			$job = array( 'recipients' => $recipients, 'reason' => $reason );
			if ( ! update_post_meta( $event_id, '_mi_event_cancellation_job', $job ) ) return self::redirect_result( 'Impossibile salvare l’annullamento. Riprova.', true, $event_id );
		}
		$reason = $job['reason'];
		foreach ( $rows as $row ) {
			$result = MI_Registration_Service::cancel_registration( (int) $row['id'], wp_get_current_user()->display_name, false, false );
			if ( is_wp_error( $result ) ) return self::redirect_result( 'Annullamento incompleto: controlla le iscrizioni prima di riprovare.', true, $event_id );
		}
		$email_result = array( 'count' => 0, 'mode' => MI_Spedizione_Email::modalita() );
		foreach ( array_chunk( $job['recipients'], 1000 ) as $batch_index => $batch ) {
			$queued = MI_Spedizione_Email::accoda_comunicazione_operativa( array( 'communication_id' => 'event-cancel-' . $event_id . '-' . $batch_index, 'event_id' => $event_id, 'template_type' => 'EVENT_CANCELLATION', 'message' => $reason, 'allow_operational' => true, 'recipients' => $batch ) );
			if ( is_wp_error( $queued ) ) return self::redirect_result( 'Iscrizioni annullate, ma avvisi non salvati. Ripeti l’annullamento per completarli.', true, $event_id );
			$email_result['count'] += $queued['count'];
			$email_result['mode'] = $queued['mode'];
		}
		$secretariat_result = MI_Spedizione_Email::accoda_avviso_annullamento_segreteria( $event_id, $reason );
		if ( is_wp_error( $secretariat_result ) ) return self::redirect_result( 'Iscrizioni annullate, ma gli avvisi interni non sono stati salvati. Ripeti l’annullamento per completarli.', true, $event_id );
		update_post_meta( $event_id, '_mi_event_cancelled_at', current_time( 'mysql', true ) );
		update_post_meta( $event_id, '_mi_event_cancellation_reason', $reason );
		wp_update_post( array( 'ID' => $event_id, 'post_status' => 'draft' ) );
		$count = (int) ( $email_result['count'] ?? 0 ) + (int) ( $secretariat_result['count'] ?? 0 );
		$mode = sanitize_text_field( (string) ( $email_result['mode'] ?? 'ANTEPRIMA' ) );
		return self::redirect_result( 'Evento annullato. Avvisi preparati: ' . $count . ' (modalità ' . $mode . ').', false );
	}

	public static function url() {
		static $resolved_url = null;
		if ( null !== $resolved_url ) return $resolved_url;
		$pages = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'numberposts' => -1, 's' => '[' . self::SHORTCODE ) );
		foreach ( $pages as $page ) if ( has_shortcode( $page->post_content, self::SHORTCODE ) ) return $resolved_url = get_permalink( $page->ID );
		return $resolved_url = add_query_arg( 'mi_portal', '1', home_url( '/' ) );
	}

	public static function participant_cancel_url( $participant_id, $token ) {
		return add_query_arg( array( 'mi_cancel_participant' => absint( $participant_id ), 'mi_cancel_token' => (string) $token ), self::url() );
	}

	public static function waitlist_offer_url( $registration_id, $token ) {
		return add_query_arg( array( 'mi_waitlist_offer' => absint( $registration_id ), 'mi_waitlist_token' => (string) $token ), home_url( '/' ) );
	}

	public static function status_url( $registration_id, $order_code, $email ) {
		global $wpdb;
		$event_id = absint( $wpdb->get_var( $wpdb->prepare( "SELECT event_id FROM {$wpdb->prefix}mi_registrations WHERE id=%d AND order_code=%s", absint( $registration_id ), sanitize_text_field( (string) $order_code ) ) ) );
		return add_query_arg( array( 'mi_status' => '1', 'evento' => $event_id, 'ordine' => sanitize_text_field( (string) $order_code ), 'token' => MI_Registration_Service::public_status_token( $registration_id, $order_code, $email ) ), home_url( '/' ) );
	}
	public static function balance_url( $registration_id, $order_code, $email ) {
		return add_query_arg( 'mi_status', 'balance', self::status_url( $registration_id, $order_code, $email ) );
	}

	public static function render_virtual_page() {
		if ( 'balance' === (string) ( $_GET['mi_status'] ?? '' ) && ! empty( $_GET['ordine'] ) && ! empty( $_GET['token'] ) ) {
			$code = sanitize_text_field( wp_unslash( $_GET['ordine'] ) );
			$requested_event = absint( $_GET['evento'] ?? 0 );
			$verified = MI_Registration_Service::public_status( $code, '', sanitize_text_field( wp_unslash( $_GET['token'] ) ), $requested_event );
			if ( is_array( $verified ) && ! empty( $verified['collectible'] ) ) {
				global $wpdb;
				$registration = $wpdb->get_row( $wpdb->prepare( "SELECT id,event_id FROM {$wpdb->prefix}mi_registrations WHERE order_code=%s AND event_id=%d LIMIT 1", $code, $requested_event ), ARRAY_A );
				$participants = $registration ? $wpdb->get_results( $wpdb->prepare( "SELECT id,first_name,last_name FROM {$wpdb->prefix}mi_participants WHERE registration_id=%d AND status='ACTIVE' ORDER BY id", $registration['id'] ), ARRAY_A ) : array();
				$prefill_people = array_map( static function ( $participant ) { return array( 'row' => (int) $participant['id'], 'nome' => $participant['first_name'], 'cognome' => $participant['last_name'] ); }, $participants );
				$prefill = $prefill_people ? array_merge( $prefill_people[0], array( 'people' => $prefill_people ) ) : array();
				MI_Public_Balance::render( (int) $registration['event_id'], $prefill ); exit;
			}
		}
		if ( empty( $_GET['mi_portal'] ) && empty( $_GET['mi_status'] ) && empty( $_GET['mi_waitlist_offer'] ) ) return;
		status_header( 200 );
		nocache_headers();
		$is_event_panel_request = ! empty( $_GET['mi_portal_event_panel'] ) && 'xmlhttprequest' === strtolower( sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_REQUESTED_WITH'] ?? '' ) ) );
		if ( $is_event_panel_request ) {
			if ( ! is_user_logged_in() || ( ! current_user_can( 'mi_portal_access' ) && ! current_user_can( 'manage_options' ) ) ) wp_die( 'Accesso non consentito.', 403 );
			$event_id = absint( $_GET['mi_portal_event'] ?? 0 );
			if ( ! $event_id || ! MI_Access::can_access_event( $event_id ) ) wp_die( 'Evento non accessibile.', 403 );
			header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
			echo '<div id="mi-event-inline-panel-' . esc_attr( $event_id ) . '" class="mi-event-inline-panel" data-mi-event-inline-panel data-mi-event-id="' . esc_attr( $event_id ) . '">';
			self::event_management_card( $event_id );
			echo '</div>';
			exit;
		}
		$is_detail_request = ! empty( $_GET['mi_portal_booking'] ) && 'xmlhttprequest' === strtolower( sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_REQUESTED_WITH'] ?? '' ) ) );
		if ( $is_detail_request ) {
			if ( ! is_user_logged_in() || ( ! current_user_can( 'mi_portal_access' ) && ! current_user_can( 'manage_options' ) ) ) wp_die( 'Accesso non consentito.', 403 );
			header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
			self::booking_detail( absint( $_GET['mi_portal_booking'] ) );
			exit;
		}
		$asset_version = rawurlencode( MI_VERSION );
		$page_title = ! empty( $_GET['mi_status'] ) ? 'Stato della prenotazione' : ( ! empty( $_GET['mi_waitlist_offer'] ) ? 'Posto disponibile' : 'Segreteria eventi' );
		?><!doctype html><html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo( 'charset' ); ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow,noarchive"><meta name="referrer" content="no-referrer"><title><?php echo esc_html( get_bloginfo( 'name' ) . ' — ' . $page_title ); ?></title><?php self::portal_icon_links(); ?><link rel="stylesheet" href="<?php echo esc_url( MI_Assets::filter_url( MI_PLUGIN_URL . 'assets/portal.css?ver=' . $asset_version ) ); ?>"></head><body class="mi-portal-standalone"><?php echo self::render(); ?><script defer src="<?php echo esc_url( MI_Assets::filter_url( MI_PLUGIN_URL . 'assets/portal.js?ver=' . $asset_version ) ); ?>"></script><?php if ( self::needs_payment_assets() ) : ?><link rel="stylesheet" href="<?php echo esc_url( MI_Assets::filter_url( MI_PLUGIN_URL . 'assets/portal-payments.css?ver=' . $asset_version ) ); ?>"><script defer src="<?php echo esc_url( MI_Assets::filter_url( MI_PLUGIN_URL . 'assets/portal-payments.js?ver=' . $asset_version ) ); ?>"></script><?php endif; ?><link rel="stylesheet" href="<?php echo esc_url( MI_Assets::filter_url( MI_PLUGIN_URL . 'assets/portal-management.css?ver=' . $asset_version ) ); ?>"><?php if ( self::needs_management_script() ) : ?><script defer src="<?php echo esc_url( MI_Assets::filter_url( MI_PLUGIN_URL . 'assets/portal-management.js?ver=' . $asset_version ) ); ?>"></script><?php endif; ?><?php if ( class_exists( 'MI_Event_QR' ) ) MI_Event_QR::standalone_scripts(); ?></body></html><?php
		exit;
	}

	private static function redirect_cancel_result( $result ) {
		$error = is_wp_error( $result );
		wp_safe_redirect( add_query_arg( array( 'mi_portal' => '1', 'mi_portal_message' => $error ? $result->get_error_message() : 'L’annullamento è stato registrato.', 'mi_portal_error' => $error ? '1' : '0' ), self::url() ) ); exit;
	}

	private static function save_date( $event_id, $key, $value ) {
		$value = sanitize_text_field( wp_unslash( $value ) );
		if ( '' === $value ) { delete_post_meta( $event_id, $key ); return; }
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $value ) ) update_post_meta( $event_id, $key, $value );
	}

	private static function valid_portal_date( $value ) {
		if ( ! is_string( $value ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $value ) ) return false;
		$date = DateTimeImmutable::createFromFormat( '!Y-m-d\\TH:i', $value, wp_timezone() );
		$errors = DateTimeImmutable::getLastErrors();
		return $date && ( false === $errors || ( 0 === $errors['warning_count'] && 0 === $errors['error_count'] ) ) && $date->format( 'Y-m-d\\TH:i' ) === $value;
	}

	private static function normalize_portal_date( $value ) {
		$value = trim( (string) $value );
		if ( self::valid_portal_date( $value ) ) return $value;
		if ( ! preg_match( '/^(\d{2})\/(\d{2})\/(\d{4}) (\d{2}):(\d{2})$/', $value, $parts ) ) return '';
		$day = (int) $parts[1]; $month = (int) $parts[2]; $year = (int) $parts[3]; $hour = (int) $parts[4]; $minute = (int) $parts[5];
		if ( ! checkdate( $month, $day, $year ) || $hour > 23 || $minute > 59 ) return '';
		return sprintf( '%04d-%02d-%02dT%02d:%02d', $year, $month, $day, $hour, $minute );
	}

	private static function portal_date_input_value( $value ) {
		$date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', (string) $value, wp_timezone() );
		return $date instanceof DateTimeImmutable ? $date->format( 'd/m/Y H:i' ) : '';
	}

	private static function save_cover_upload( $event_id ) {
		if ( empty( $_FILES['cover_image']['name'] ) ) return '';
		$file = $_FILES['cover_image'];
		if ( ! empty( $file['error'] ) || empty( $file['tmp_name'] ) ) return 'caricamento incompleto';
		if ( (int) $file['size'] > 2 * MB_IN_BYTES ) return 'file superiore a 2 MB';
		$checked = wp_check_filetype_and_ext( $file['tmp_name'], sanitize_file_name( $file['name'] ) );
		if ( ! in_array( $checked['type'] ?? '', array( 'image/jpeg', 'image/png', 'image/webp' ), true ) ) return 'formato non ammesso';
		$dimensions = wp_getimagesize( $file['tmp_name'] );
		if ( ! is_array( $dimensions ) || empty( $dimensions[0] ) || empty( $dimensions[1] ) ) return 'immagine non leggibile';
		if ( $dimensions[0] > 4096 || $dimensions[1] > 4096 || ( $dimensions[0] * $dimensions[1] ) > 20000000 ) return 'immagine troppo grande: riducila a non più di 4096 pixel per lato';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		try {
			$attachment_id = media_handle_upload( 'cover_image', $event_id, array(), array( 'test_form' => false ) );
		} catch ( Throwable $error ) {
			return 'WordPress non ha potuto elaborare l’immagine';
		}
		if ( is_wp_error( $attachment_id ) ) return 'WordPress non ha potuto salvare il file';
		set_post_thumbnail( $event_id, $attachment_id );
		return '';
	}

	/** Salva un'immagine del gruppo controllando formato e limite di 2 MB. */
	private static function save_group_image_upload( $field_name, $group_id ) {
		if ( empty( $_FILES[ $field_name ]['name'] ) ) return 0;
		$file = $_FILES[ $field_name ];
		if ( ! empty( $file['error'] ) || empty( $file['tmp_name'] ) ) return new WP_Error( 'mi_group_upload', 'Caricamento immagine incompleto.' );
		if ( (int) $file['size'] > 2 * MB_IN_BYTES ) return new WP_Error( 'mi_group_upload_size', 'L’immagine non può superare 2 MB.' );
		$checked = wp_check_filetype_and_ext( $file['tmp_name'], sanitize_file_name( $file['name'] ) );
		if ( ! in_array( $checked['type'] ?? '', array( 'image/jpeg', 'image/png', 'image/webp' ), true ) ) return new WP_Error( 'mi_group_upload_type', 'Sono ammesse soltanto immagini JPG, PNG o WebP.' );
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		$attachment_id = media_handle_upload( $field_name, $group_id, array(), array( 'test_form' => false ) );
		return is_wp_error( $attachment_id ) ? new WP_Error( 'mi_group_upload_failed', 'WordPress non ha potuto salvare l’immagine.' ) : absint( $attachment_id );
	}

	private static function can_manage_groups() {
		return current_user_can( 'manage_options' ) || current_user_can( 'mi_manage_groups' );
	}

	private static function redirect_group_result( $message, $error = false, $group_id = 0 ) {
		$args = array(
			'mi_portal'         => '1',
			'mi_portal_view'    => 'groups',
			'mi_portal_message' => $message,
			'mi_portal_error'   => $error ? '1' : '0',
		);
		if ( $group_id ) $args['mi_portal_group'] = absint( $group_id );
		wp_safe_redirect( add_query_arg( $args, self::url() ) );
		exit;
	}

	private static function handle_group_action( $action ) {
		if ( ! is_user_logged_in() || ! self::can_manage_groups() ) wp_die( 'Solo un amministratore o un Gestore iscrizioni può gestire i gruppi.', 403 );
		check_admin_referer( 'mi_portal_manage_groups', 'mi_portal_nonce' );
		$group_id = absint( $_POST['group_id'] ?? 0 );
		if ( 'delete_group' !== $action ) {
			$sender_email = trim( (string) wp_unslash( $_POST['group_email_sender'] ?? '' ) );
			if ( '' !== $sender_email && ! is_email( $sender_email ) ) return self::redirect_group_result( 'Indica un indirizzo mittente email valido.', true, $group_id );
			try { $attendance_period = MI_Attendance_Report::submitted_period( $group_id, wp_unslash( $_POST ) ); }
			catch ( InvalidArgumentException $e ) { return self::redirect_group_result( $e->getMessage(), true, $group_id ); }
		}
		if ( 'create_group' === $action ) {
			$title = mb_substr( sanitize_text_field( wp_unslash( $_POST['group_title'] ?? '' ) ), 0, 120 );
			if ( ! $title ) return self::redirect_group_result( 'Indica il nome del gruppo.', true );
			if ( get_page_by_path( sanitize_title( $title ), OBJECT, MI_Event_Post_Type::GROUP_TYPE ) ) return self::redirect_group_result( 'Esiste già un gruppo con questo nome: aprilo e modificalo.', true );
			$group_id = wp_insert_post( array( 'post_type' => MI_Event_Post_Type::GROUP_TYPE, 'post_status' => 'publish', 'post_title' => $title, 'post_author' => get_current_user_id() ), true );
			if ( is_wp_error( $group_id ) ) return self::redirect_group_result( 'Non è stato possibile creare il gruppo.', true );
		} else {
			$group = get_post( $group_id );
			if ( ! $group || MI_Event_Post_Type::GROUP_TYPE !== $group->post_type ) wp_die( 'Gruppo non valido.', 404 );
		}
		if ( 'delete_group' === $action ) {
			$linked_events = get_posts( array( 'post_type' => MI_Event_Post_Type::EVENT_TYPE, 'post_status' => array( 'publish', 'draft', 'private', 'mi_archived' ), 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => '_mi_activity_id', 'meta_value' => $group_id ) );
			if ( $linked_events ) return self::redirect_group_result( 'Il gruppo non può essere eliminato perché è assegnato ad almeno un evento.', true, $group_id );
			wp_trash_post( $group_id );
			return self::redirect_group_result( 'Gruppo spostato nel cestino.' );
		}
		$title = mb_substr( sanitize_text_field( wp_unslash( $_POST['group_title'] ?? '' ) ), 0, 120 );
		if ( ! $title ) return self::redirect_group_result( 'Indica il nome del gruppo.', true, $group_id );
		if ( 'update_group' === $action ) {
			$updated = wp_update_post( array( 'ID' => $group_id, 'post_title' => $title ), true );
			if ( is_wp_error( $updated ) ) return self::redirect_group_result( 'Non è stato possibile aggiornare il gruppo.', true, $group_id );
		}
		$primary = sanitize_hex_color( wp_unslash( $_POST['group_primary_color'] ?? '' ) ) ?: '#151b38';
		$secondary = sanitize_hex_color( wp_unslash( $_POST['group_secondary_color'] ?? '' ) ) ?: '#337ab7';
		$email_style = array();
		if ( ! empty( $_POST['group_email_identity_enabled'] ) ) $email_style = array( 'identity_name' => $_POST['group_email_identity_name'] ?? '', 'identity_detail' => $_POST['group_email_identity_detail'] ?? '', 'signature' => $_POST['group_email_signature'] ?? '' );
		$group_contact_email = sanitize_email( wp_unslash( $_POST['group_email_contact'] ?? '' ) );
		if ( $group_contact_email ) $email_style['contact_email'] = $group_contact_email;
		if ( $sender_email ) $email_style['sender_email'] = $sender_email;
		if ( ! empty( $_POST['group_email_logo_enabled'] ) ) $email_style['logo_enabled'] = true;
		$email_style = MI_Modello_Email::logo_override( $email_style, $_POST['group_email_logo_mode'] ?? null, get_post_meta( $group_id, '_mi_email_style', true ) );
		if ( ! empty( $_POST['group_email_colors_enabled'] ) ) $email_style = array_merge( $email_style, array( 'primary_color' => $_POST['group_email_primary_color'] ?? '', 'secondary_color' => $_POST['group_email_secondary_color'] ?? '' ) );
		$email_style = MI_Modello_Email::sanitizza_stile( wp_unslash( $email_style ) );
		if ( $email_style ) update_post_meta( $group_id, '_mi_email_style', $email_style ); else delete_post_meta( $group_id, '_mi_email_style' );
		$annual_attendance_report = isset( $_POST['mi_annual_attendance_report'] ) && '1' === wp_unslash( $_POST['mi_annual_attendance_report'] ) ? '1' : '0';
		update_post_meta( $group_id, '_mi_primary_color', $primary );
		update_post_meta( $group_id, '_mi_secondary_color', $secondary );
		update_post_meta( $group_id, '_mi_accent_color', $primary );
		update_post_meta( $group_id, '_mi_annual_attendance_report', $annual_attendance_report );
		update_post_meta( $group_id, '_mi_attendance_from_month', $attendance_period[0] );
		update_post_meta( $group_id, '_mi_attendance_to_month', $attendance_period[1] );
		if ( ! empty( $_POST['remove_group_logo'] ) ) delete_post_thumbnail( $group_id );
		if ( ! empty( $_POST['remove_group_cover'] ) ) delete_post_meta( $group_id, '_mi_group_cover_image_id' );
		$logo_id = self::save_group_image_upload( 'group_logo', $group_id );
		if ( is_wp_error( $logo_id ) ) return self::redirect_group_result( $logo_id->get_error_message(), true, $group_id );
		if ( $logo_id ) set_post_thumbnail( $group_id, $logo_id );
		$cover_id = self::save_group_image_upload( 'group_cover', $group_id );
		if ( is_wp_error( $cover_id ) ) return self::redirect_group_result( $cover_id->get_error_message(), true, $group_id );
		if ( $cover_id ) update_post_meta( $group_id, '_mi_group_cover_image_id', $cover_id );
		$dependent_events = get_posts( array( 'post_type' => MI_Event_Post_Type::EVENT_TYPE, 'post_status' => array( 'publish', 'draft', 'private' ), 'numberposts' => -1, 'fields' => 'ids', 'meta_key' => '_mi_activity_id', 'meta_value' => $group_id ) );
		foreach ( $dependent_events as $event_id ) update_post_meta( $event_id, '_mi_needs_republish', '1' );
		return self::redirect_group_result( 'create_group' === $action ? 'Gruppo creato. Ora è disponibile nella creazione degli eventi.' : 'Gruppo aggiornato.', false, $group_id );
	}

	private static function parse_euro_cents( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) return 0;
		$cents = MI_Amount::cents( $value );
		return null === $cents ? new WP_Error( 'invalid_amount' ) : $cents;
	}

	private static function copy_configuration( $source, $target ) {
		$keys = array( '_mi_activity_id', '_mi_capacity', '_mi_waitlist_enabled', '_mi_waitlist_offer_hours', '_mi_reopened_payment_hours', '_mi_pricing_mode', '_mi_fixed_price_cents', '_mi_economic_mode', '_mi_deposit_mode', '_mi_deposit_percentage', '_mi_deposit_fixed_cents', '_mi_payment_methods', '_mi_operational_profile', '_mi_data_profile', '_mi_participant_fields', '_mi_participant_required_fields', '_mi_custom_participant_fields', '_mi_participant_extra_scope', '_mi_ticket_types', '_mi_options', '_mi_marketing_enabled', '_mi_special_requests_enabled', '_mi_completion_url', '_mi_overnight_enabled', '_mi_accommodation_management', '_mi_bus_assignment_enabled', '_mi_accommodations', '_mi_email_template', '_mi_email_style', '_mi_identifier_display', '_mi_event_qr_enabled' );
		foreach ( $keys as $key ) {
			$value = get_post_meta( $source, $key, true );
			if ( '' !== $value ) update_post_meta( $target, $key, $value );
		}
	}

	private static function redirect_result( $message, $error = false, $event_id = 0, $show_outputs = false ) {
		$url = self::url();
		$args = array( 'mi_portal' => '1', 'mi_portal_message' => $message, 'mi_portal_error' => $error ? '1' : '0', 'mi_portal_view' => 'manage' );
		if ( $event_id ) {
			$args['mi_portal_event'] = $event_id;
			// Mantieni l'esito vicino alla scheda e al pulsante anche in caso di errore.
			if ( $show_outputs ) $args['mi_portal_outputs'] = '1';
		}
		$destination = add_query_arg( $args, $url );
		if ( $event_id && ! $error && $show_outputs ) $destination .= '#mi-produzioni-evento';
		wp_safe_redirect( $destination );
		exit;
	}

	public static function render() {
		if ( ! is_ssl() ) return '<div class="mi-portal-notice mi-portal-error"><strong>Connessione sicura necessaria.</strong><p>Il portale non può essere usato finché HTTPS non è configurato correttamente.</p></div>';
		if ( ! empty( $_GET['mi_status'] ) ) return self::public_status_view();
		if ( ! empty( $_GET['mi_waitlist_offer'] ) ) return self::waitlist_offer_view();
		if ( ! empty( $_GET['mi_cancel_participant'] ) && ! empty( $_GET['mi_cancel_token'] ) ) return self::cancellation_view();
		if ( ! is_user_logged_in() ) return self::login_view();
		if ( MI_Access::is_suspended() ) return '<div class="mi-portal-empty"><h2>Accesso sospeso</h2><p>Questo account non può accedere alla Segreteria eventi. Contatta un amministratore.</p></div>';
		if ( ! current_user_can( 'mi_portal_access' ) && ! current_user_can( 'manage_options' ) ) return '<div class="mi-portal-empty"><h2>C’è qualcuno qui…?</h2><p>Il tuo account non è abilitato al servizio iscrizioni.</p></div>';
		$view = self::current_view();
		$can_view_groups = self::can_manage_groups() || ( class_exists( 'MI_Portal_PWA' ) && MI_Portal_PWA::enabled() && MI_Portal_PWA::allowed_groups() );
		$can_create = current_user_can( 'mi_create_events' ) || current_user_can( 'manage_options' );
		$requested_edit_id = absint( $_GET['mi_portal_edit'] ?? $_GET['mi_portal_draft'] ?? 0 );
		$can_edit_requested = $requested_edit_id && ( current_user_can( 'mi_manage_events' ) || current_user_can( 'manage_options' ) ) && MI_Access::can_access_event( $requested_edit_id );
		ob_start();
		?><main class="mi-portal" data-mi-portal-scope="reserved"><header class="mi-portal-header"><div><span class="mi-portal-eyebrow">Area riservata</span><h1>Segreteria eventi</h1></div><a class="mi-portal-logout" href="<?php echo esc_url( wp_logout_url( self::base_url() ) ); ?>"><span aria-hidden="true">↗</span> Esci</a></header>
		<nav class="mi-portal-switcher" aria-label="Segreteria eventi"><a class="<?php echo in_array( $view, array( 'management', 'registrations' ), true ) ? 'is-active' : ''; ?>" <?php if ( in_array( $view, array( 'management', 'registrations' ), true ) ) echo 'aria-current="page"'; ?> href="<?php echo esc_url( ( isset( $_GET['mi_portal_event'] ) ? MI_Portal_Management::url( absint( $_GET['mi_portal_event'] ) ) : add_query_arg( 'mi_portal_view', 'management', self::base_url() ) ) ); ?>">Iscrizioni</a><a class="<?php echo 'manage' === $view ? 'is-active' : ''; ?>" <?php if ( 'manage' === $view ) echo 'aria-current="page"'; ?> href="<?php echo esc_url( add_query_arg( 'mi_portal_view', 'manage', self::base_url() ) ); ?>">Eventi</a><?php if ( $can_create ) : ?><a class="<?php echo 'create' === $view ? 'is-active' : ''; ?>" <?php if ( 'create' === $view ) echo 'aria-current="page"'; ?> href="<?php echo esc_url( add_query_arg( 'mi_portal_view', 'create', self::base_url() ) ); ?>">+ Crea evento</a><?php endif; ?><?php if ( MI_Portal_Payments::allowed() ) : ?><a class="<?php echo in_array( $view, array( 'payments', 'payment-report' ), true ) ? 'is-active' : ''; ?>" <?php if ( in_array( $view, array( 'payments', 'payment-report' ), true ) ) echo 'aria-current="page"'; ?> href="<?php echo esc_url( add_query_arg( array( 'mi_portal_view' => 'payments', 'mi_portal_event' => absint( $_GET['mi_portal_event'] ?? 0 ) ), self::base_url() ) ); ?>">Pagamenti</a><?php endif; ?><a class="<?php echo 'communications' === $view ? 'is-active' : ''; ?>" <?php if ( 'communications' === $view ) echo 'aria-current="page"'; ?> href="<?php echo esc_url( add_query_arg( 'mi_portal_view', 'communications', self::base_url() ) ); ?>">Messaggi</a><?php if ( $can_view_groups ) : ?><a class="<?php echo 'groups' === $view ? 'is-active' : ''; ?>" <?php if ( 'groups' === $view ) echo 'aria-current="page"'; ?> href="<?php echo esc_url( add_query_arg( 'mi_portal_view', 'groups', self::base_url() ) ); ?>">Gruppi</a><?php endif; ?><?php if ( self::can_manage_module_users() ) : ?><a class="<?php echo 'operators' === $view ? 'is-active' : ''; ?>" <?php if ( 'operators' === $view ) echo 'aria-current="page"'; ?> href="<?php echo esc_url( add_query_arg( 'mi_portal_view', 'operators', self::base_url() ) ); ?>">Operatori</a><?php endif; ?></nav>

		<?php $notice_near_outputs = 'manage' === $view && ! empty( $_GET['mi_portal_event'] ) && ! empty( $_GET['mi_portal_outputs'] ); if ( ! $notice_near_outputs ) self::notice(); ?>
		<?php if ( 'delete' === $view ) MI_Event_Deletion::render(); elseif ( 'create' === $view && ( $can_create || $can_edit_requested ) ) self::create_view( $requested_edit_id ); elseif ( 'management' === $view ) MI_Portal_Management::render(); elseif ( 'registrations' === $view ) MI_Portal_Management::render( absint( $_GET['mi_portal_booking'] ?? 0 ) ); elseif ( 'payments' === $view ) MI_Portal_Payments::render(); elseif ( 'payment-report' === $view ) MI_Portal_Payments::render_report(); elseif ( 'communications' === $view ) self::communications_view(); elseif ( 'groups' === $view && $can_view_groups ) self::groups_tab(); elseif ( 'operators' === $view && self::can_manage_module_users() ) self::operators_view(); else self::manage_view(); ?>
		</main><?php
		return ob_get_clean();
	}

	private static function public_status_view() {
		$balance_view = 'balance' === ( $_GET['mi_status'] ?? '' );
		$event_id = absint( $_GET['evento'] ?? 0 );
		$order_code = sanitize_text_field( wp_unslash( $_GET['ordine'] ?? '' ) );
		$token = sanitize_text_field( wp_unslash( $_GET['token'] ?? '' ) );
		$first_name = '';
		$last_name = '';
		$result = null;
		if ( $order_code && $token ) {
			$result = MI_Registration_Service::public_status( $order_code, '', $token, $event_id );
		} elseif ( 'POST' === strtoupper( $_SERVER['REQUEST_METHOD'] ?? '' ) && 'public_status_lookup' === sanitize_key( wp_unslash( $_POST['mi_portal_action'] ?? '' ) ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_POST['mi_status_nonce'] ?? '' ) );
			$address = MI_Registration_Service::client_ip();
			$rate_key = 'mi_status_rate_' . substr( hash_hmac( 'sha256', $address, wp_salt( 'nonce' ) ), 0, 32 );
			$attempts = (int) get_transient( $rate_key );
			if ( ! wp_verify_nonce( $nonce, 'mi_public_status' ) || $attempts >= 10 ) {
				$result = new WP_Error( 'mi_status_unavailable', 'Non è stato possibile verificare la prenotazione. Riprova più tardi.' );
			} else {
				set_transient( $rate_key, $attempts + 1, 15 * MINUTE_IN_SECONDS );
				$first_name = sanitize_text_field( wp_unslash( $_POST['first_name'] ?? '' ) );
				$last_name = sanitize_text_field( wp_unslash( $_POST['last_name'] ?? '' ) );
				$result = MI_Registration_Service::public_status_by_name( $event_id, $first_name, $last_name );
			}
		}
		$free_result = is_array( $result ) && ! empty( $result['is_free'] );
		ob_start(); ?>
		<main class="mi-portal mi-public-status"><section class="mi-portal-login"><span class="mi-portal-eyebrow">Consultazione della prenotazione</span><h1><?php echo $free_result ? 'Stato dell’iscrizione' : ( $balance_view ? 'Saldo della prenotazione' : 'Stato della prenotazione' ); ?></h1><p><?php echo $free_result ? 'Qui puoi verificare che la tua iscrizione sia registrata.' : 'Inserisci il cognome e, se necessario, il nome per controllare la tua iscrizione. Gli importi si riferiscono all’intera prenotazione, comprese le eventuali altre persone iscritte insieme. Non vengono mostrati dati personali o note interne.'; ?></p>
		<?php if ( is_array( $result ) ) : ?><div class="mi-status-result"><p class="mi-status-event"><?php echo esc_html( $result['event_title'] ); ?></p><p class="mi-booking-detail__code">Codice <code><?php echo esc_html( $result['order_code'] ); ?></code></p><div class="mi-status-grid"><p><span>Iscrizione</span><strong><?php echo esc_html( $result['status'] ); ?></strong></p><?php if ( ! $free_result ) : ?><p><span>Pagamento</span><strong><?php echo esc_html( $result['payment_status'] ); ?></strong></p><p><span>Versato</span><strong><?php echo esc_html( self::format_money( $result['paid_cents'] ) ); ?></strong></p><p><span><?php echo ! empty( $result['collectible'] ) ? 'Saldo residuo' : 'Differenza contabile (non richiesta di pagamento)'; ?></span><strong><?php echo esc_html( self::format_money( $result['balance_cents'] ) ); ?></strong></p><?php endif; ?></div><?php if ( ! empty( $result['payment_deadline'] ) ) : ?><p class="mi-portal-muted">Scadenza indicata: <?php echo esc_html( self::format_utc_date( $result['payment_deadline'] ) ); ?></p><?php endif; ?></div>
		<?php if ( ! empty( $result['collectible'] ) && $result['balance_cents'] > 0 ) : ?><h2>Come completare il pagamento</h2><p>Importo residuo: <strong><?php echo esc_html( self::format_money( $result['balance_cents'] ) ); ?></strong>. Usa il codice <strong><?php echo esc_html( $result['order_code'] ); ?></strong> come riferimento.</p><ul><?php $instructions = array( 'BANK_TRANSFER' => 'Bonifico: usa le coordinate comunicate dall’organizzazione.', 'CARD' => 'Carta: segui le indicazioni comunicate dall’organizzazione.', 'CASH' => 'Contanti: concorda la consegna con l’organizzazione.' ); foreach ( $result['payment_methods'] as $method ) echo '<li>' . esc_html( $instructions[$method] ) . '</li>'; ?></ul><p>Se hai già versato l’importo, attendi la registrazione da parte della segreteria prima di effettuare un altro pagamento. Questa pagina conferma i movimenti registrati; non esegue un addebito.</p><?php endif; ?>
        <?php elseif ( is_wp_error( $result ) ) : ?><div class="mi-portal-notice mi-portal-error"><?php echo esc_html( $result->get_error_message() ); ?></div><?php endif; ?>
		<form method="post" action="<?php echo esc_url( add_query_arg( array_filter( array( 'mi_status' => $balance_view ? 'balance' : '1', 'evento' => $event_id ) ), home_url( '/' ) ) ); ?>"><input type="hidden" name="mi_portal_action" value="public_status_lookup"><input type="hidden" name="mi_status_nonce" value="<?php echo esc_attr( wp_create_nonce( 'mi_public_status' ) ); ?>"><label>Cognome<input name="last_name" value="<?php echo esc_attr( $last_name ); ?>" maxlength="100" autocomplete="family-name" required></label><label>Nome<input name="first_name" value="<?php echo esc_attr( $first_name ); ?>" maxlength="100" autocomplete="given-name"></label><button type="submit"><?php echo $free_result ? 'Controlla iscrizione' : 'Controlla stato e saldo'; ?></button></form></section></main><?php
		return ob_get_clean();
	}

	private static function waitlist_offer_view() {
		$registration_id = absint( $_GET['mi_waitlist_offer'] ?? 0 );
		$result_code = sanitize_key( wp_unslash( $_GET['mi_waitlist_result'] ?? '' ) );
		if ( $result_code ) {
			$messages = array(
				'accepted' => array( 'Posto accettato', 'La prenotazione è stata aggiornata. Riceverai un’email con la conferma e, se previsti, i dati per il pagamento.' ),
				'declined' => array( 'Rinuncia registrata', 'I posti sono stati liberati e proposti alla richiesta successiva.' ),
				'expired'  => array( 'Proposta scaduta', 'Il termine era trascorso e i posti sono stati proposti alla richiesta successiva.' ),
				'error'    => array( 'Scelta non registrata', 'Il collegamento non è valido, è scaduto oppure è già stato utilizzato.' ),
			);
			$message = $messages[ $result_code ] ?? $messages['error'];
			return '<main class="mi-portal mi-public-status"><section class="mi-portal-login"><span class="mi-portal-eyebrow">Lista d’attesa</span><h1>' . esc_html( $message[0] ) . '</h1><p>' . esc_html( $message[1] ) . '</p></section></main>';
		}
		$token = sanitize_text_field( wp_unslash( $_GET['mi_waitlist_token'] ?? '' ) );
		$offer = MI_Registration_Service::waitlist_offer_from_token( $registration_id, $token );
		if ( is_wp_error( $offer ) ) return '<main class="mi-portal mi-public-status"><section class="mi-portal-login"><span class="mi-portal-eyebrow">Lista d’attesa</span><h1>Proposta non disponibile</h1><p>' . esc_html( $offer->get_error_message() ) . '</p></section></main>';
		ob_start(); ?>
		<main class="mi-portal mi-public-status"><section class="mi-portal-login"><span class="mi-portal-eyebrow">Posto disponibile</span><h1>Vuoi accettare il posto?</h1><p><strong><?php echo esc_html( $offer['buyer_first_name'] . ' ' . $offer['buyer_last_name'] ); ?></strong>, i posti richiesti per <strong><?php echo esc_html( $offer['event_title'] ); ?></strong> sono riservati fino a <strong><?php echo esc_html( $offer['expires_label'] ); ?></strong>.</p><p>Scegli ora. Se l’evento prevede un pagamento, riceverai istruzioni e scadenza soltanto dopo l’accettazione.</p><form method="post"><input type="hidden" name="mi_portal_action" value="waitlist_offer_decision"><input type="hidden" name="registration_id" value="<?php echo esc_attr( $registration_id ); ?>"><input type="hidden" name="offer_token" value="<?php echo esc_attr( $token ); ?>"><?php wp_nonce_field( 'mi_waitlist_offer_' . $registration_id, 'mi_portal_nonce' ); ?><div class="mi-booking-detail__actions"><button class="mi-primary" type="submit" name="decision" value="ACCEPT">Accetta il posto</button><button class="mi-danger" type="submit" name="decision" value="DECLINE">Rinuncia</button></div></form></section></main>
		<?php return ob_get_clean();
	}

	private static function cancellation_view() {
		$participant_id = absint( $_GET['mi_cancel_participant'] ?? 0 );
		$token = sanitize_text_field( wp_unslash( $_GET['mi_cancel_token'] ?? '' ) );
		$participant = MI_Registration_Service::participant_from_token( $participant_id, $token );
		if ( is_wp_error( $participant ) ) return '<section class="mi-portal mi-portal-empty"><h1>Collegamento non disponibile</h1><p>' . esc_html( $participant->get_error_message() ) . '</p></section>';
		if ( 'CANCELLED' === $participant['status'] ) return '<section class="mi-portal mi-portal-empty"><h1>Partecipazione già annullata</h1><p>Non è necessaria alcuna altra operazione.</p></section>';
		$is_free = self::is_free_configuration( array( 'pricing_mode' => get_post_meta( (int) $participant['event_id'], '_mi_pricing_mode', true ) ) );
		ob_start(); ?><section class="mi-portal mi-cancel-confirm"><span class="mi-portal-eyebrow">Conferma richiesta</span><h1>Annullare questa partecipazione?</h1><p>Buongiorno,<br>ci dispiace non possa più partecipare.</p><p><strong><?php echo esc_html( get_the_title( (int) $participant['event_id'] ) ); ?></strong><br>Prenotazione <?php echo esc_html( $participant['order_code'] ); ?></p><p>Dopo la conferma, questa partecipazione sarà annullata.<?php if ( ! $is_free ) : ?> Se hai già effettuato un pagamento, contatta la segreteria per ricevere informazioni sull’eventuale rimborso.<?php endif; ?></p><form method="post"><input type="hidden" name="mi_portal_action" value="cancel_participant_public"><input type="hidden" name="participant_id" value="<?php echo esc_attr( $participant_id ); ?>"><input type="hidden" name="cancel_token" value="<?php echo esc_attr( $token ); ?>"><?php wp_nonce_field( 'mi_cancel_participant_public_' . $participant_id, 'mi_portal_nonce' ); ?><button class="mi-danger" type="submit">Sì, annulla la partecipazione</button></form></section><?php return ob_get_clean();
	}

	private static function login_view() {
		$errore = ! empty( $_GET['mi_errore_accesso'] );
		$attesa = ! empty( $_GET['mi_accesso_in_attesa'] );
		ob_start(); ?><section class="mi-portal mi-portal-login"><span class="mi-portal-eyebrow">Area riservata</span><h1>Segreteria eventi</h1><p>Accedi con le credenziali personali del servizio. Vedrai soltanto le funzioni e gli eventi compresi nel tuo ruolo.</p><?php if ( $errore ) : ?><div class="mi-portal-notice mi-portal-error" role="alert"><strong>Accesso non riuscito.</strong><p><?php echo $attesa ? 'Troppi tentativi ravvicinati. Attendi quindici minuti prima di riprovare.' : 'Controlla nome utente e parola d’accesso oppure contatta un amministratore.'; ?></p></div><?php endif; ?><form class="mi-portal-login__form" method="post" action="<?php echo esc_url( self::base_url() ); ?>"><input type="hidden" name="mi_portal_action" value="accedi_portale"><?php wp_nonce_field( 'mi_accesso_portale', 'mi_portal_nonce' ); ?><label for="mi-login-utente">Nome utente per l’accesso</label><input id="mi-login-utente" name="mi_nome_utente" type="text" maxlength="60" autocomplete="username" required><label for="mi-login-password">Parola d’accesso</label><input id="mi-login-password" name="mi_parola_accesso" type="password" autocomplete="current-password" required><p class="login-remember"><label><input name="mi_ricordami" type="checkbox" value="1"> Ricordami</label></p><button class="mi-primary" type="submit">Accedi</button></form></section><?php return ob_get_clean();
	}

	/** Autentica esclusivamente nella pagina autonoma della Segreteria, senza passare da wp-login.php. */
	private static function gestisci_accesso_portale() {
		// Il nonce consente l'accesso anche da una pagina che contiene lo shortcode del portale.
		if ( is_user_logged_in() ) {
			wp_safe_redirect( self::base_url() );
			exit;
		}
		check_admin_referer( 'mi_accesso_portale', 'mi_portal_nonce' );
		$nome_utente = sanitize_user( wp_unslash( $_POST['mi_nome_utente'] ?? '' ), true );
		$parola_accesso = (string) wp_unslash( $_POST['mi_parola_accesso'] ?? '' );
		$ricordami = ! empty( $_POST['mi_ricordami'] );
		$chiave_limite = self::chiave_limite_accesso( $nome_utente );
		$tentativi = (int) get_transient( $chiave_limite );
		if ( $tentativi >= 5 ) return self::reindirizza_errore_accesso( true );
		if ( ! $nome_utente || '' === $parola_accesso ) return self::registra_errore_accesso( $chiave_limite, $tentativi );

		$utente = wp_signon(
			array(
				'user_login'    => $nome_utente,
				'user_password' => $parola_accesso,
				'remember'      => $ricordami,
			),
			is_ssl()
		);
		$parola_accesso = '';
		if ( is_wp_error( $utente ) ) return self::registra_errore_accesso( $chiave_limite, $tentativi );
		if ( ! user_can( $utente, 'mi_portal_access' ) && ! user_can( $utente, 'manage_options' ) ) {
			wp_clear_auth_cookie();
			return self::registra_errore_accesso( $chiave_limite, $tentativi );
		}
		delete_transient( $chiave_limite );
		wp_safe_redirect( self::base_url() );
		exit;
	}

	private static function chiave_limite_accesso( $nome_utente ) {
		$indirizzo = MI_Registration_Service::client_ip();
		$impronta = hash_hmac( 'sha256', strtolower( (string) $nome_utente ) . '|' . $indirizzo, wp_salt( 'auth' ) );
		return 'mi_accesso_' . substr( $impronta, 0, 32 );
	}

	private static function registra_errore_accesso( $chiave_limite, $tentativi ) {
		set_transient( $chiave_limite, min( 5, (int) $tentativi + 1 ), 15 * MINUTE_IN_SECONDS );
		return self::reindirizza_errore_accesso( false );
	}

	private static function reindirizza_errore_accesso( $attesa ) {
		$destinazione = add_query_arg(
			array(
				'mi_errore_accesso'    => '1',
				'mi_accesso_in_attesa' => $attesa ? '1' : false,
			),
			self::base_url()
		);
		wp_safe_redirect( $destinazione );
		exit;
	}

	private static function accessible_events() {
		$scope = MI_Access::event_ids();
		$query = array( 'post_type' => MI_Event_Post_Type::EVENT_TYPE, 'post_status' => array( 'publish', 'draft', 'private' ), 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' );
		if ( 'ALL' !== $scope ) $query['post__in'] = $scope ?: array( 0 );
		return get_posts( $query );
	}

	private static function communications_view() {
		$token = sanitize_key( $_GET['mi_comm_preview'] ?? '' );
		$draft = $token ? get_transient( 'mi_comm_' . get_current_user_id() . '_' . $token ) : false;
		if ( is_array( $draft ) && MI_Access::can_access_event( $draft['event_id'] ) ) {
			echo '<section><h2>Conferma comunicazione</h2><h3>' . esc_html( get_the_title( $draft['event_id'] ) ) . '</h3><p>' . esc_html( $draft['count'] ) . ' email per le prenotazioni selezionate.</p>';
			echo '<p><strong>' . ( 'OPERATIVO' === $draft['mode'] ? 'Invio ai destinatari reali' : ( 'PROVA' === $draft['mode'] ? 'Invio esclusivamente alla casella di prova' : 'Solo preparazione, senza invio' ) ) . '</strong></p>';
			if ( 'publish' !== get_post_status( $draft['event_id'] ) ) echo '<p>Evento non pubblicato: verranno salvate soltanto anteprime, senza invio.</p>';
			echo '<details><summary>Destinatari delle prenotazioni</summary><p>' . esc_html( implode( ', ', $draft['emails'] ) ) . '</p></details><h3>Testo del messaggio</h3>';
			echo 'BALANCE_REMINDER' === $draft['template_type'] ? '<p>Promemoria personalizzato con saldo, scadenza, causale e collegamento al pagamento di ciascuna prenotazione. Il testo libero non viene utilizzato.</p>' : MI_Modello_Email::formatta_comunicazione( $draft['message'] );
			echo '<form method="post"><input type="hidden" name="mi_portal_action" value="prepare_communication"><input type="hidden" name="communication_token" value="' . esc_attr( $token ) . '">';
			wp_nonce_field( 'mi_portal_prepare_communication', 'mi_portal_nonce' );
			$send_label = 'publish' !== get_post_status( $draft['event_id'] ) || 'ANTEPRIMA' === $draft['mode'] ? 'Conferma preparazione senza invio' : ( 'OPERATIVO' === $draft['mode'] ? 'Conferma invio ai destinatari reali' : 'Conferma invio di prova' );
			echo '<button type="submit">' . esc_html( $send_label ) . '</button></form><a href="' . esc_url( add_query_arg( 'mi_portal_view', 'communications', self::base_url() ) ) . '">Torna alla composizione</a></section>';
			return;
		}
		$events = self::accessible_events();
		$custom_types = self::custom_communication_types();
		$test_mode = 'PROVA' === MI_Spedizione_Email::modalita();
		$test_ready = $test_mode && 'TEST_PENDING' === MI_Spedizione_Email::stato_nuova_email( array( 'attivo' => true ) );
		$notice = $test_ready ? '<strong>Modalità test.</strong> Le comunicazioni degli eventi pubblicati vengono inviate esclusivamente all’indirizzo configurato per i test, non ai destinatari reali.' : ( $test_mode ? '<strong>Modalità test.</strong> Configura un indirizzo di test per abilitare l’invio. Per ora le comunicazioni vengono preparate senza invio.' : ( 'OPERATIVO' === MI_Spedizione_Email::modalita() ? '' : '<strong>Preparazione senza invio.</strong> Da questa schermata le comunicazioni vengono preparate, ma non inviate.' ) );
		echo '<section class="mi-portal-communications"><h2>Comunicazioni</h2>';
		if ( $notice ) echo '<p class="mi-portal-notice">' . $notice . '</p>';
		if ( ! $events ) { echo '<p class="mi-portal-muted">Non ci sono eventi accessibili.</p></section>'; return; }
		echo '<form method="post"><input type="hidden" name="mi_portal_action" value="prepare_communication">';
		wp_nonce_field( 'mi_portal_prepare_communication', 'mi_portal_nonce' );
		echo '<label>Evento<select name="event_id" required><option value="">Scegli un evento</option>';
		foreach ( $events as $event ) echo '<option value="' . esc_attr( $event->ID ) . '" ' . selected( absint( $_GET['mi_portal_event'] ?? 0 ), $event->ID, false ) . '>' . esc_html( $event->post_title ) . '</option>';
		echo '</select></label><label>Tipo<select name="template_type" required><option value="PRE_DEPARTURE_REMINDER">Informazioni prima dell’evento</option><option value="BALANCE_REMINDER">Promemoria del saldo</option>';
		foreach ( $custom_types as $code => $label ) echo '<option value="' . esc_attr( $code ) . '">' . esc_html( $label ) . '</option>';
		echo '</select></label><label>Messaggio<small>Grassetto: **testo** · Corsivo: *testo* · Elenco: una riga per voce preceduta da - . Il promemoria saldo usa il testo automatico.</small><textarea name="message" rows="8" maxlength="4000" placeholder="Punto di ritrovo, orario, cosa portare e altre indicazioni…"></textarea></label><button class="mi-primary" type="submit">' . 'Controlla anteprima e destinatari' . '</button></form>';
		if ( current_user_can( 'mi_manage_all_events' ) || current_user_can( 'manage_options' ) ) {
			echo '<details class="mi-communication-types"><summary>Gestisci i tipi di messaggio</summary><div><form method="post"><input type="hidden" name="mi_portal_action" value="add_communication_type">';
			wp_nonce_field( 'mi_portal_manage_communication_types', 'mi_portal_nonce' );
			echo '<label>Nuovo tipo<input name="communication_type_label" maxlength="80" placeholder="Per esempio: Cambio del punto di ritrovo" required></label><button class="mi-secondary" type="submit">Aggiungi e salva</button></form>';
			if ( $custom_types ) {
				echo '<form class="mi-communication-type-delete" method="post" data-mi-confirm="Eliminare questo tipo di comunicazione? Le comunicazioni già preparate resteranno conservate."><input type="hidden" name="mi_portal_action" value="delete_communication_type">';
				wp_nonce_field( 'mi_portal_manage_communication_types', 'mi_portal_nonce' );
				echo '<label>Tipo personalizzato<select name="communication_type_code" required>';
				foreach ( $custom_types as $code => $label ) echo '<option value="' . esc_attr( $code ) . '">' . esc_html( $label ) . '</option>';
				echo '</select></label><button class="mi-text-danger" type="submit">Elimina</button></form>';
			}
			echo '<p class="mi-portal-muted"><small>I tipi di sistema non possono essere eliminati.</small></p></div></details>';
		}
		echo '</section>';
	}

	private static function groups_tab() {
		if ( ! self::can_manage_groups() ) echo '<h2>Gruppi</h2>';
		if ( class_exists( 'MI_Portal_PWA' ) ) MI_Portal_PWA::render_install_help();
		if ( self::can_manage_groups() ) self::groups_view();
	}

	private static function groups_view() {
		if ( ! self::can_manage_groups() ) { wp_die( 'Solo un amministratore o un Gestore iscrizioni può gestire i gruppi.', 403 ); }
		$groups = get_posts( array( 'post_type' => MI_Event_Post_Type::GROUP_TYPE, 'post_status' => array( 'publish', 'draft' ), 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		$event_counts = array();
		$group_ids = array_map( 'absint', wp_list_pluck( $groups, 'ID' ) );
		if ( $group_ids ) {
			global $wpdb;
			$safe_group_ids = implode( ',', $group_ids );
			$sql = $wpdb->prepare(
				"SELECT CAST(pm.meta_value AS UNSIGNED) AS group_id, COUNT(DISTINCT p.ID) AS event_count FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON pm.post_id=p.ID AND pm.meta_key=%s WHERE p.post_type=%s AND p.post_status IN ('publish','draft','private','mi_archived') AND CAST(pm.meta_value AS UNSIGNED) IN ({$safe_group_ids}) GROUP BY CAST(pm.meta_value AS UNSIGNED)",
				'_mi_activity_id',
				MI_Event_Post_Type::EVENT_TYPE
			);
			foreach ( $wpdb->get_results( $sql, ARRAY_A ) as $row ) $event_counts[ (int) $row['group_id'] ] = (int) $row['event_count'];
		}
		?>
		<section class="mi-groups"><div class="mi-groups__heading"><div><span class="mi-portal-eyebrow">Configurazione</span><h2>Gruppi</h2></div><p class="mi-portal-muted">Definisci una sola volta nome, logo, copertina e colori. I nuovi eventi del gruppo li erediteranno automaticamente.</p></div>
		<details class="mi-group-create" <?php echo $groups ? '' : 'open'; ?>><summary>Aggiungi un nuovo gruppo</summary><form method="post" enctype="multipart/form-data"><input type="hidden" name="mi_portal_action" value="create_group"><?php wp_nonce_field( 'mi_portal_manage_groups', 'mi_portal_nonce' ); ?>
		<div class="mi-group-form-grid"><label>Nome del gruppo<input name="group_title" maxlength="120" required placeholder="Es. Giovani"></label><label class="mi-group-contact-field"><span>Email per le comunicazioni con gli iscritti <small>(facoltativa)</small></span><input type="email" name="group_email_contact" placeholder="gruppo@example.invalid"><small>Sarà usata per le risposte alle email degli eventi del gruppo.</small></label><label>Logo <small>(facoltativo)</small><input type="file" name="group_logo" accept="image/jpeg,image/png,image/webp" data-mi-max-bytes="2097152"><small>JPG, PNG o WebP, massimo 2 MB.</small></label><label>Immagine in evidenza <small>(facoltativa)</small><input type="file" name="group_cover" accept="image/jpeg,image/png,image/webp" data-mi-max-bytes="2097152"><small>Viene proposta agli eventi privi di una propria immagine.</small></label><label>Colore principale<input type="color" name="group_primary_color" value="#151b38"></label><label>Colore pulsanti<input type="color" name="group_secondary_color" value="#337ab7"></label></div><label class="mi-check"><input type="checkbox" name="mi_annual_attendance_report" value="1"> Attiva il rapporto annuale delle presenze per questo gruppo</label><?php MI_Attendance_Report::period_fields(); ?><button class="mi-primary" type="submit">Crea gruppo</button></form></details>
		<div class="mi-group-list"><?php if ( ! $groups ) : ?><p class="mi-portal-empty">Non sono ancora presenti gruppi.</p><?php endif; ?><?php foreach ( $groups as $group ) : $logo = get_the_post_thumbnail_url( $group->ID, 'thumbnail' ); $cover_id = absint( get_post_meta( $group->ID, '_mi_group_cover_image_id', true ) ); $cover = $cover_id ? wp_get_attachment_image_url( $cover_id, 'medium' ) : ''; $primary = sanitize_hex_color( get_post_meta( $group->ID, '_mi_primary_color', true ) ) ?: '#151b38'; $secondary = sanitize_hex_color( get_post_meta( $group->ID, '_mi_secondary_color', true ) ) ?: '#337ab7'; $email_style = (array) get_post_meta( $group->ID, '_mi_email_style', true ); $email_identity_enabled = ! empty( array_intersect_key( $email_style, array_flip( array( 'identity_name', 'identity_detail', 'contact_email', 'signature' ) ) ) ); $email_colors_enabled = ! empty( array_intersect_key( $email_style, array_flip( array( 'primary_color', 'secondary_color' ) ) ) ); $event_count = (int) ( $event_counts[ $group->ID ] ?? 0 ); ?>
		<details class="mi-group-card" <?php echo absint( $_GET['mi_portal_group'] ?? 0 ) === $group->ID ? 'open' : ''; ?>><summary><span class="mi-group-card__identity"><?php if ( $logo ) : ?><img src="<?php echo esc_url( $logo ); ?>" alt=""><?php else : ?><em aria-hidden="true"><?php echo esc_html( mb_strtoupper( mb_substr( $group->post_title, 0, 1 ) ) ); ?></em><?php endif; ?><span><strong><?php echo esc_html( $group->post_title ); ?></strong><small><?php echo esc_html( $event_count . ( 1 === $event_count ? ' evento collegato' : ' eventi collegati' ) ); ?></small></span></span><span>Configura</span></summary><form method="post" enctype="multipart/form-data"><input type="hidden" name="mi_portal_action" value="update_group"><input type="hidden" name="group_id" value="<?php echo esc_attr( $group->ID ); ?>"><?php wp_nonce_field( 'mi_portal_manage_groups', 'mi_portal_nonce' ); ?>
		<div class="mi-group-form-grid"><label>Nome del gruppo<input name="group_title" maxlength="120" value="<?php echo esc_attr( $group->post_title ); ?>" required></label><div class="mi-group-image-field"><strong>Logo</strong><?php if ( $logo ) : ?><img src="<?php echo esc_url( $logo ); ?>" alt=""><label class="mi-check"><input type="checkbox" name="remove_group_logo" value="1"> Rimuovi il logo</label><?php endif; ?><label>Sostituisci<input type="file" name="group_logo" accept="image/jpeg,image/png,image/webp" data-mi-max-bytes="2097152"></label></div><div class="mi-group-image-field"><strong>Immagine in evidenza</strong><?php if ( $cover ) : ?><img src="<?php echo esc_url( $cover ); ?>" alt=""><label class="mi-check"><input type="checkbox" name="remove_group_cover" value="1"> Rimuovi l’immagine</label><?php endif; ?><label>Sostituisci<input type="file" name="group_cover" accept="image/jpeg,image/png,image/webp" data-mi-max-bytes="2097152"></label></div><label>Colore principale<input type="color" name="group_primary_color" value="<?php echo esc_attr( $primary ); ?>"></label><label>Colore pulsanti<input type="color" name="group_secondary_color" value="<?php echo esc_attr( $secondary ); ?>"></label></div>
<label class="mi-group-contact-field"><span>Indirizzo mittente delle email <small>(facoltativo)</small></span><input type="email" name="group_email_sender" maxlength="254" value="<?php echo esc_attr( $email_style['sender_email'] ?? '' ); ?>" placeholder="mittente@example.invalid"><small>Usato per le email agli iscritti degli eventi di questo gruppo. Deve essere già verificato in Gmail, «Invia messaggio come», sull’account della parrocchia. Le risposte continuano ad arrivare all’indirizzo di comunicazione qui sotto. Se vuoto, il mittente resta la segreteria.</small></label>
<label class="mi-group-contact-field"><span>Email per le comunicazioni con gli iscritti <small>(facoltativa)</small></span><input type="email" name="group_email_contact" value="<?php echo esc_attr( $email_style['contact_email'] ?? '' ); ?>" placeholder="gruppo@example.invalid"><small>Questo indirizzo riceve in esclusiva gli avvisi di nuove iscrizioni e cancellazioni, i contatti e le risposte degli iscritti. Pubblicazione, annullamento ed eliminazione dell’evento avvisano anche la segreteria e l’operatore assegnato, se presente. Se resta vuoto, sarà usata l’email della segreteria.</small></label><details class="mi-email-appearance"><summary>Aspetto email</summary><label>Logo nelle email<select name="group_email_logo_mode"><option value="INHERIT" <?php selected( ! array_key_exists( 'logo_enabled', $email_style ) , true ); ?>>Automatico / eredita</option><option value="SHOW" <?php selected( array_key_exists( 'logo_enabled', $email_style ) && ! empty( $email_style['logo_enabled'] ) , true ); ?>>Mostra</option><option value="HIDE" <?php selected( array_key_exists( 'logo_enabled', $email_style ) && empty( $email_style['logo_enabled'] ) , true ); ?>>Nascondi</option></select></label><p class="mi-portal-muted">In modalità automatica vengono usati logo e banner del gruppo. Lascia disattivate le opzioni seguenti per ereditare il default parrocchia.</p><label class="mi-check"><input type="checkbox" name="group_email_identity_enabled" value="1" <?php checked( $email_identity_enabled ); ?>> Personalizza identità e firma</label><div class="mi-group-form-grid"><label>Nome visualizzato<input name="group_email_identity_name" maxlength="120" value="<?php echo esc_attr( $email_style['identity_name'] ?? '' ); ?>"></label><label>Sottotitolo nell’intestazione email<input name="group_email_identity_detail" maxlength="180" value="<?php echo esc_attr( $email_style['identity_detail'] ?? '' ); ?>"></label><label>Firma<input name="group_email_signature" maxlength="240" value="<?php echo esc_attr( $email_style['signature'] ?? '' ); ?>"></label></div><label class="mi-check"><input type="checkbox" name="group_email_colors_enabled" value="1" <?php checked( $email_colors_enabled ); ?>> Personalizza colori email</label><div class="mi-group-form-grid"><label>Colore principale<input type="color" name="group_email_primary_color" value="<?php echo esc_attr( $email_style['primary_color'] ?? '#1a365d' ); ?>"></label><label>Colore CTA<input type="color" name="group_email_secondary_color" value="<?php echo esc_attr( $email_style['secondary_color'] ?? '#337ab7' ); ?>"></label></div></details><label class="mi-check"><input type="checkbox" name="mi_annual_attendance_report" value="1" <?php checked( get_post_meta( $group->ID, '_mi_annual_attendance_report', true ), '1' ); ?>> Attiva il rapporto annuale delle presenze per questo gruppo</label><?php MI_Attendance_Report::period_fields( $group->ID ); ?><div class="mi-group-card__actions"><button class="mi-primary" type="submit">Salva gruppo</button></div></form><?php MI_Attendance_Report::render_group( $group->ID ); ?><?php if ( 0 === $event_count ) : ?><form method="post" class="mi-group-delete" data-mi-confirm="Eliminare questo gruppo? Sarà spostato nel cestino."><input type="hidden" name="mi_portal_action" value="delete_group"><input type="hidden" name="group_id" value="<?php echo esc_attr( $group->ID ); ?>"><?php wp_nonce_field( 'mi_portal_manage_groups', 'mi_portal_nonce' ); ?><button class="mi-danger" type="submit">Elimina gruppo</button></form><?php else : ?><p class="mi-portal-muted">Per eliminare il gruppo, assegna prima i suoi eventi a un altro gruppo.</p><?php endif; ?></details>
		<?php endforeach; ?></div></section>
		<?php
	}

	private static function operators_view() {
		if ( ! self::can_manage_module_users() ) wp_die( 'Solo un amministratore o un Gestore iscrizioni può gestire gli operatori.', 403 );
		$roles = self::operator_roles();
		$groups = get_posts( array( 'post_type' => MI_Event_Post_Type::ACTIVITY_TYPE, 'post_status' => array( 'publish', 'draft' ), 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		$all_events = get_posts( array( 'post_type' => MI_Event_Post_Type::EVENT_TYPE, 'post_status' => array( 'publish', 'draft', 'private' ), 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		$events = array_values( array_filter( $all_events, static function ( $event ) {
			if ( get_post_meta( $event->ID, '_mi_event_cancelled_at', true ) || get_post_meta( $event->ID, '_mi_event_archived_at', true ) ) return false;
			$closes_at = (string) get_post_meta( $event->ID, '_mi_registration_closes_at', true );
			$starts_at = (string) get_post_meta( $event->ID, '_mi_event_starts_at', true );
			return ! self::is_past_event( $starts_at ?: $closes_at );
		} ) );
		$group_names = wp_list_pluck( $groups, 'post_title', 'ID' );
		$event_names = wp_list_pluck( $all_events, 'post_title', 'ID' );
		$operators = get_users( array( 'role__in' => array_keys( $roles ), 'orderby' => 'display_name', 'order' => 'ASC' ) );
		?>
		<section class="mi-operators"><div class="mi-operators__heading"><div><span class="mi-portal-eyebrow">Amministrazione del modulo</span><h2>Operatori</h2></div><p class="mi-portal-muted">Il Gestore iscrizioni opera su tutto il servizio. Il Gestore gruppo crea e amministra gli eventi dei gruppi assegnati. Il Gestore evento amministra soltanto gli eventi ricevuti e non può crearne.</p></div>
		<details class="mi-operator-create"><summary>Crea un nuovo operatore</summary><form method="post" autocomplete="off" data-mi-operator-form><input type="hidden" name="mi_portal_action" value="create_operator"><?php wp_nonce_field( 'mi_portal_manage_operators', 'mi_portal_nonce' ); ?>
		<div class="mi-operator-grid"><label>Nome visualizzato<input name="operator_name" maxlength="120" required></label><label>Nome utente per l’accesso<input name="operator_username" maxlength="60" autocomplete="off" required></label><label>Email<input type="email" name="operator_email" maxlength="100" autocomplete="off" required></label><label>Parola d’accesso iniziale<input type="password" name="operator_password" minlength="12" autocomplete="new-password" required><small>Almeno 12 caratteri. Comunicala direttamente alla persona interessata.</small></label><label>Ruolo<select name="operator_role" required><?php foreach ( $roles as $code => $label ) : ?><option value="<?php echo esc_attr( $code ); ?>"><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label></div>
		<?php self::operator_scope_fields( $groups, $events, $event_names ); ?>
		<button class="mi-primary" type="submit">Crea operatore</button></form></details>
		<div class="mi-operator-list"><?php if ( ! $operators ) : ?><p class="mi-portal-empty">Non sono ancora presenti operatori dedicati.</p><?php endif; ?><?php foreach ( $operators as $operator ) :
			$role = current( array_intersect( array_keys( $roles ), (array) $operator->roles ) ) ?: 'mi_assigned_event_manager';
			$selected_groups = 'mi_group_manager' === $role ? MI_Access::activity_ids( $operator->ID ) : array();
			$selected_groups = is_array( $selected_groups ) ? $selected_groups : array();
			$selected_events = 'mi_assigned_event_manager' === $role ? MI_Access::event_ids( $operator->ID ) : array();
			$selected_events = is_array( $selected_events ) ? $selected_events : array();
			$suspended = MI_Access::is_suspended( $operator->ID );
			$selected_group_names = array_values( array_filter( array_map( static function ( $group_id ) use ( $group_names ) { return $group_names[ $group_id ] ?? ''; }, $selected_groups ) ) );
			$selected_event_names = array_values( array_filter( array_map( static function ( $event_id ) use ( $event_names ) { return $event_names[ $event_id ] ?? ''; }, $selected_events ) ) );
			$role_title = array( 'mi_registration_manager' => 'Gestore iscrizioni', 'mi_group_manager' => 'Gestore gruppo', 'mi_assigned_event_manager' => 'Gestore evento' )[ $role ] ?? $role;
			$scope_description = 'mi_registration_manager' === $role ? 'tutto il servizio' : ( 'mi_group_manager' === $role ? ( $selected_group_names ? implode( ', ', $selected_group_names ) : 'nessun gruppo assegnato' ) : ( $selected_event_names ? implode( ', ', $selected_event_names ) : 'nessun evento assegnato' ) );
		?>
		<details class="mi-operator-card<?php echo $suspended ? ' is-suspended' : ''; ?>"><summary><span><strong><?php echo esc_html( $operator->display_name ?: $operator->user_login ); ?></strong><small><?php echo esc_html( $operator->user_login . ' · ' . $role_title . ' — ' . $scope_description ); ?></small></span><em><?php echo $suspended ? 'Sospeso' : 'Attivo'; ?></em></summary><form method="post" autocomplete="off" data-mi-operator-form><input type="hidden" name="mi_portal_action" value="update_operator"><input type="hidden" name="operator_id" value="<?php echo esc_attr( $operator->ID ); ?>"><?php wp_nonce_field( 'mi_portal_manage_operators', 'mi_portal_nonce' ); ?>
		<div class="mi-operator-grid"><label>Nome visualizzato<input name="operator_name" maxlength="120" value="<?php echo esc_attr( $operator->display_name ); ?>" required></label><label>Nome utente per l’accesso<input value="<?php echo esc_attr( $operator->user_login ); ?>" disabled><small>Il nome utente non può essere modificato.</small></label><label>Email<input type="email" name="operator_email" maxlength="100" value="<?php echo esc_attr( $operator->user_email ); ?>" required></label><label><span>Nuova parola d’accesso <small class="mi-operator-optional"><span class="mi-operator-optional__full">(facoltativa)</span><span class="mi-operator-optional__short" aria-label="facoltativa">(fac.)</span></small></span><input type="password" name="operator_password" minlength="12" autocomplete="new-password" placeholder="Lascia vuoto per non cambiarla"></label><label>Ruolo<select name="operator_role" required><?php foreach ( $roles as $code => $label ) : ?><option value="<?php echo esc_attr( $code ); ?>" <?php selected( $role, $code ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label></div>
		<?php self::operator_scope_fields( $groups, $events, $event_names, $role, $selected_groups, $selected_events ); ?>
		<label class="mi-check mi-operator-suspension"><input type="checkbox" name="operator_suspended" value="1" <?php checked( $suspended ); ?>> Sospendi l’accesso alla Segreteria eventi</label><button class="mi-primary" type="submit">Salva operatore</button></form></details>
		<?php endforeach; ?></div></section>
		<?php
	}

	private static function operator_scope_fields( $groups, $events, $event_names, $role = 'mi_registration_manager', $selected_groups = array(), $selected_events = array() ) {
		$current_event_ids = array_map( 'absint', wp_list_pluck( $events, 'ID' ) );
		$historical_event_ids = array_values( array_diff( $selected_events, $current_event_ids ) );
		?>
		<fieldset data-mi-operator-groups <?php echo 'mi_group_manager' === $role ? '' : 'hidden'; ?>><legend>Gruppi assegnati</legend><p class="mi-portal-muted">Può creare e gestire eventi soltanto in questi gruppi.</p><div class="mi-operator-groups"><?php foreach ( $groups as $group ) : ?><label class="mi-check"><input type="checkbox" name="operator_groups[]" value="<?php echo esc_attr( $group->ID ); ?>" <?php checked( in_array( $group->ID, $selected_groups, true ) ); ?>> <?php echo esc_html( $group->post_title ); ?></label><?php endforeach; ?></div></fieldset>
		<fieldset data-mi-operator-events <?php echo 'mi_assigned_event_manager' === $role ? '' : 'hidden'; ?>><legend>Eventi in corso assegnati</legend><p class="mi-portal-muted">Può gestire completamente gli eventi selezionati, ma non crearne di nuovi.</p><div class="mi-operator-groups"><?php foreach ( $events as $event ) : ?><label class="mi-check"><input type="checkbox" name="operator_events[]" value="<?php echo esc_attr( $event->ID ); ?>" <?php checked( in_array( $event->ID, $selected_events, true ) ); ?>> <?php echo esc_html( $event->post_title ); ?></label><?php endforeach; ?></div><?php if ( $historical_event_ids ) : ?><p class="mi-portal-muted">Restano consultabili nello storico: <?php echo esc_html( implode( ', ', array_values( array_filter( array_map( static function ( $event_id ) use ( $event_names ) { return $event_names[ $event_id ] ?? ''; }, $historical_event_ids ) ) ) ) ); ?>.</p><?php foreach ( $historical_event_ids as $event_id ) : ?><input type="hidden" name="operator_events[]" value="<?php echo esc_attr( $event_id ); ?>"><?php endforeach; ?><?php endif; ?></fieldset>
		<?php
	}

	private static function manage_label() {
		$scope = MI_Access::event_ids();
		if ( 'ALL' !== $scope && 1 === count( $scope ) ) return 'Gestisci evento';
		if ( 'ALL' !== $scope ) return 'I miei eventi';
		return 'Gestisci eventi';
	}

	/** L'etichetta dipende dalla dichiarazione esplicita del gestore, non dai prezzi calcolati. */
	public static function is_free_configuration( array $config ) {
		return 'ZERO' === ( $config['pricing_mode'] ?? '' );
	}

	/** Gli identificativi di revisione immutabili identificano anche la cache delle schede; il chiamante verifica l'ambito. */
	private static function published_card_summaries( array $revision_ids ) {
		global $wpdb;
		$revision_ids = array_values( array_unique( array_filter( array_map( 'absint', $revision_ids ) ) ) );
		if ( ! $revision_ids ) return array();
		sort( $revision_ids, SORT_NUMERIC );
		$revision_list = implode( ',', $revision_ids );
		$key = 'mi_event_cards_v1_' . hash( 'sha256', $revision_list );
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) return $cached;
		$rows = $wpdb->get_results( "SELECT event_id,config_json FROM {$wpdb->prefix}mi_event_revisions WHERE id IN ({$revision_list})", ARRAY_A );
		if ( $wpdb->last_error || ! is_array( $rows ) ) return array();
		$keys = array_flip( array( 'title', 'activity', 'event_starts_at', 'opens_at', 'closes_at', 'capacity', 'waitlist_enabled', 'cover_image', 'pricing_mode' ) );
		$summaries = array();
		foreach ( $rows as $revision ) {
			$config = json_decode( (string) $revision['config_json'], true );
			if ( ! is_array( $config ) ) return array();
			$summaries[ (int) $revision['event_id'] ] = array_intersect_key( $config, $keys );
		}
		// Non salvare una lettura incompleta; la richiesta successiva recupera le revisioni mancanti.
		if ( count( $rows ) === count( $revision_ids ) ) set_transient( $key, $summaries, HOUR_IN_SECONDS );
		return $summaries;
	}

	private static function manage_view() {
		global $wpdb;
		$scope = MI_Access::event_ids();
		if ( 'ALL' !== $scope && ! $scope ) { echo '<section class="mi-portal-empty"><div class="mi-portal-bubble">Na⁺</div><h2>C’è qualcuno qui…?</h2><p>Al momento non ti è stato assegnato nessun evento. Chiedi all’amministratore o al Gestore iscrizioni di associarti a un gruppo o a un evento.</p></section>'; return; }
		$query = array( 'post_type' => MI_Event_Post_Type::EVENT_TYPE, 'post_status' => array( 'publish', 'draft', 'private' ), 'numberposts' => -1, 'orderby' => 'date', 'order' => 'DESC', 'update_post_term_cache' => false );
		if ( 'ALL' !== $scope ) $query['post__in'] = $scope;
		$all_events = get_posts( $query );
		if ( ! $all_events ) { echo '<section class="mi-portal-empty"><div class="mi-portal-bubble">Na⁺</div><h2>C’è qualcuno qui…?</h2><p>Non ci sono eventi visibili.</p></section>'; return; }
		$revision_ids = array();
		foreach ( $all_events as $event ) if ( 'publish' === $event->post_status ) { $revision_id = absint( get_post_meta( $event->ID, '_mi_published_revision_id', true ) ); if ( $revision_id ) $revision_ids[] = $revision_id; }
		$published_summaries = self::published_card_summaries( $revision_ids );
		$show_past = ! empty( $_GET['mi_portal_history'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['mi_portal_history'] ) );
		$current_events = array();
		$past_events = array();
		$start_timestamps = array();
		$cancelled_events = array();
		$archived_events = array();
		foreach ( $all_events as $event ) {
			$published = (array) ( $published_summaries[ $event->ID ] ?? array() );
			$starts_at = (string) ( $published['event_starts_at'] ?? get_post_meta( $event->ID, '_mi_event_starts_at', true ) );
			$closes_at = (string) ( $published['closes_at'] ?? get_post_meta( $event->ID, '_mi_registration_closes_at', true ) );
			$start_timestamps[ $event->ID ] = self::date_timestamp( $starts_at );
			$cancelled_events[ $event->ID ] = (bool) get_post_meta( $event->ID, '_mi_event_cancelled_at', true );
			$archived_events[ $event->ID ] = (bool) get_post_meta( $event->ID, '_mi_event_archived_at', true );
			if ( $archived_events[ $event->ID ] ) $past_events[] = $event;
			elseif ( $cancelled_events[ $event->ID ] ) $current_events[] = $event;
			elseif ( self::is_past_event( $starts_at ?: $closes_at ) ) $past_events[] = $event;
			else $current_events[] = $event;
		}
		$events = $show_past ? $past_events : $current_events;
		usort( $events, static function ( $a, $b ) use ( $start_timestamps, $cancelled_events, $show_past ) {
			if ( ! $show_past && $cancelled_events[ $a->ID ] !== $cancelled_events[ $b->ID ] ) return $cancelled_events[ $a->ID ] ? 1 : -1;
			$a_time = (int) ( $start_timestamps[ $a->ID ] ?? 0 );
			$b_time = (int) ( $start_timestamps[ $b->ID ] ?? 0 );
			if ( ! $a_time ) $a_time = $show_past ? 0 : PHP_INT_MAX;
			if ( ! $b_time ) $b_time = $show_past ? 0 : PHP_INT_MAX;
			return $show_past ? $b_time <=> $a_time : $a_time <=> $b_time;
		} );
		$ids = array_map( 'absint', wp_list_pluck( $events, 'ID' ) );
		$counts = array();
		$registration_counts = array();
		$active_registration_counts = array();
		if ( $ids ) {
			$safe_ids = implode( ',', $ids );
			foreach ( $wpdb->get_results( "SELECT event_id,confirmed_count FROM {$wpdb->prefix}mi_event_counters WHERE event_id IN ({$safe_ids})", ARRAY_A ) as $counter ) $counts[ (int) $counter['event_id'] ] = (int) $counter['confirmed_count'];
			foreach ( $wpdb->get_results( "SELECT event_id,COUNT(*) AS total_count,SUM(CASE WHEN status IN ('CONFIRMED','PENDING_PAYMENT','WAITLISTED','WAITLIST_OFFERED') AND capacity_released_at IS NULL THEN 1 ELSE 0 END) AS active_count FROM {$wpdb->prefix}mi_registrations WHERE event_id IN ({$safe_ids}) GROUP BY event_id", ARRAY_A ) as $counter ) {
				$registration_counts[ (int) $counter['event_id'] ] = (int) $counter['total_count'];
				$active_registration_counts[ (int) $counter['event_id'] ] = (int) $counter['active_count'];
			}
		}
		$base_url = self::base_url();
		// Eventi apre sempre le tessere chiuse; una selezione esplicita resta rispettata.
		$selected = isset( $_GET['mi_portal_event'] ) ? absint( $_GET['mi_portal_event'] ) : 0;
		if ( ! in_array( $selected, $ids, true ) ) $selected = 0;
		echo '<section id="mi-elenco-eventi"><h2>' . ( $show_past ? 'Eventi passati' : 'Eventi' ) . '</h2>';
		if ( $events ) echo '<div class="mi-event-grid">';
		foreach ( $events as $event ) {
			$is_selected = $selected === (int) $event->ID;
			$count = (int) ( $counts[ $event->ID ] ?? 0 );
			$is_cancelled = ! empty( $cancelled_events[ $event->ID ] );
			$published = (array) ( $published_summaries[ $event->ID ] ?? array() );
			$capacity = max( 1, absint( $published['capacity'] ?? get_post_meta( $event->ID, '_mi_capacity', true ) ) );
			$starts_at = (string) ( $published['event_starts_at'] ?? get_post_meta( $event->ID, '_mi_event_starts_at', true ) );
			$closes_at = (string) ( $published['closes_at'] ?? get_post_meta( $event->ID, '_mi_registration_closes_at', true ) );
			$is_expired = self::registration_deadline_passed( $closes_at );
			$opens_at = (string) ( $published['opens_at'] ?? get_post_meta( $event->ID, '_mi_registration_opens_at', true ) );
			$registration_opens_later = ! $is_expired && ! $is_cancelled && 'publish' === $event->post_status && $opens_at && $opens_at > current_time( 'Y-m-d\TH:i' );
			$registration_label = '';
			if ( $is_expired ) $registration_label = 'Iscrizioni chiuse';
			elseif ( $registration_opens_later ) $registration_label = 'dal ' . self::format_date( $opens_at, 'd/m/Y' );
			elseif ( $count >= $capacity ) $registration_label = ( $published['waitlist_enabled'] ?? ( '1' === get_post_meta( $event->ID, '_mi_waitlist_enabled', true ) ) ) ? 'Lista d’attesa aperta' : 'Posti esauriti';
			if ( $is_cancelled || 'publish' !== $event->post_status ) $registration_label = 'Iscrizioni non disponibili';
			$event_title = sanitize_text_field( (string) ( $published['title'] ?? $event->post_title ) );
			$activity_name = sanitize_text_field( (string) ( $published['activity'] ?? '' ) );
			$activity_id = absint( get_post_meta( $event->ID, '_mi_activity_id', true ) );
			if ( ! $activity_name && $activity_id ) $activity_name = get_the_title( $activity_id );
			// Le tessere non richiedono la copertina grande conservata nello snapshot.
			$cover_image = esc_url( (string) ( get_the_post_thumbnail_url( $event->ID, 'medium' ) ?: ( $published['cover_image'] ?? '' ) ) );
			if ( ! $cover_image ) $cover_image = self::group_cover_url( $activity_id, 'thumbnail' );
			$group_logo = self::group_logo_url( $activity_id, 'thumbnail' );
			$date_badge = self::date_badge( $starts_at );
			$occupancy_percentage = min( 100, max( 0, (int) round( ( $count / $capacity ) * 100 ) ) );
			if ( 'draft' === $event->post_status && ! $is_cancelled ) {
				// Una bozza è sempre un processo di creazione interrotto: riapriamo
				// l'intero percorso, anche quando i soli elementi mancanti sono operativi.
				$url_args = array( 'mi_portal_view' => 'create', 'mi_portal_draft' => $event->ID );
			} elseif ( $is_selected ) {
				$url_args = array( 'mi_portal_view' => 'manage', 'mi_portal_event' => 0 );
			} else {
				$url_args = array( 'mi_portal_view' => 'manage', 'mi_portal_event' => $event->ID );
			}
			if ( $show_past ) $url_args['mi_portal_history'] = '1';
			$url = add_query_arg( $url_args, $base_url );
			echo '<article class="mi-event-card-shell' . ( $is_selected ? ' is-selected' : '' ) . '"><a class="mi-event-card' . ( $is_cancelled ? ' is-cancelled' : ( $is_expired ? ' is-expired' : '' ) ) . '" href="' . esc_url( $url ) . '"' . ( 'draft' !== $event->post_status ? ' data-mi-event-open data-mi-event-id="' . esc_attr( $event->ID ) . '"' : '' ) . ( $is_selected ? ' aria-expanded="true" aria-controls="mi-event-inline-panel-' . esc_attr( $event->ID ) . '"' : ' aria-expanded="false"' ) . '><span class="mi-event-card__toggle" aria-hidden="true"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 13 6 6 6-6M6 6l6 6 6-6"/></svg></span><span class="mi-event-card__date"><small>' . esc_html( $date_badge['month'] ) . '</small><strong>' . esc_html( $date_badge['day'] ) . '</strong>' . ( $group_logo ? '<img class="mi-event-card__group-logo" src="' . esc_url( $group_logo ) . '" alt="" loading="lazy" decoding="async">' : '' ) . '</span><span class="mi-event-card__content"><span class="mi-event-card__image">';
			if ( $cover_image ) echo '<img src="' . esc_url( $cover_image ) . '" alt="" loading="lazy" decoding="async" fetchpriority="low">';
			echo '</span><span class="mi-event-card__identity"><strong>' . esc_html( $event_title ) . '</strong>';
			if ( $activity_name ) echo '<small>' . esc_html( $activity_name ) . '</small>';
			echo '<span class="mi-event-card__date-row"><small>' . esc_html( self::format_date( $starts_at ) ) . '</small>';
			$price_config = $published ?: array( 'pricing_mode' => get_post_meta( $event->ID, '_mi_pricing_mode', true ) );
			if ( self::is_free_configuration( $price_config ) ) echo '<span class="mi-event-free">Gratuito</span>';
			echo '</span>';
			$status_label = $is_cancelled ? 'Annullato' : ( 'publish' === $event->post_status ? ( self::is_past_event( $starts_at ) ? 'Concluso' : 'Attivo' ) : 'Bozza' );
			echo '</span><span class="mi-event-card__footer"><span class="mi-event-card__capacity"><small>Posti occupati</small><strong>' . esc_html( $count . ' / ' . $capacity ) . '</strong><i aria-hidden="true"><b style="width:' . esc_attr( $occupancy_percentage ) . '%"></b></i></span><span class="mi-event-card__status"><strong>' . esc_html( $status_label ) . '</strong>' . ( $registration_label ? '<small>' . ( $registration_opens_later ? '<b>' . esc_html( $registration_label ) . '</b>' : esc_html( $registration_label ) ) . '</small>' : '' ) . '<small>Scadenza: ' . esc_html( self::format_date( $closes_at ) ) . '</small></span></span></span></a>';
			$registration_count = (int) ( $registration_counts[ $event->ID ] ?? 0 );
			$active_count = (int) ( $active_registration_counts[ $event->ID ] ?? 0 );
			$can_trash = ! $is_cancelled && 'draft' === $event->post_status && 0 === $registration_count;
			$can_archive = $is_cancelled && empty( $archived_events[ $event->ID ] );
			$can_cancel = ! $is_cancelled && 'draft' !== $event->post_status;
			$can_duplicate = current_user_can( 'mi_create_events' ) || current_user_can( 'manage_options' );
			if ( $can_trash || $can_archive || $can_cancel || $can_duplicate || MI_Event_Deletion::allowed() ) {
				echo '<details class="mi-event-card-menu"><summary aria-label="Azioni per ' . esc_attr( $event_title ) . '"><span aria-hidden="true">⋮</span></summary><div>';
				if ( $can_duplicate ) {
					echo '<form method="post"><input type="hidden" name="mi_portal_action" value="duplicate_event"><input type="hidden" name="event_id" value="' . esc_attr( $event->ID ) . '"><input type="hidden" name="duplicate_request" value="' . esc_attr( wp_generate_uuid4() ) . '">';
					wp_nonce_field( 'mi_portal_manage_event_' . $event->ID, 'mi_portal_nonce' );
					echo '<button type="submit">Duplica evento</button></form>';
				}
				if ( $can_trash ) {
					echo '<form method="post" data-mi-confirm="Eliminare questa bozza? Sarà spostata nel cestino di WordPress."><input type="hidden" name="mi_portal_action" value="trash_event"><input type="hidden" name="event_id" value="' . esc_attr( $event->ID ) . '">';
					wp_nonce_field( 'mi_portal_manage_event_' . $event->ID, 'mi_portal_nonce' );
					echo '<button class="mi-text-danger" type="submit">Elimina bozza</button></form>';
				} elseif ( $can_archive ) {
					echo '<form method="post" data-mi-confirm="Archiviare questo evento annullato? Resterà consultabile nello storico."><input type="hidden" name="mi_portal_action" value="archive_event"><input type="hidden" name="event_id" value="' . esc_attr( $event->ID ) . '">';
					wp_nonce_field( 'mi_portal_manage_event_' . $event->ID, 'mi_portal_nonce' );
					echo '<button type="submit">Archivia</button></form>';
				} elseif ( $can_cancel ) {
					echo '<button class="mi-text-danger" type="button" data-mi-cancel-dialog-open="mi-cancel-event-' . esc_attr( $event->ID ) . '">Annulla evento</button>';
				}
				if ( MI_Event_Deletion::allowed() ) echo '<a class="mi-text-danger" href="' . esc_url( MI_Event_Deletion::url( $event->ID ) ) . '">Elimina definitivamente…</a>';
				echo '</div></details>';
				if ( $can_cancel ) {
					echo '<dialog class="mi-event-cancel-dialog" id="mi-cancel-event-' . esc_attr( $event->ID ) . '" aria-labelledby="mi-cancel-event-title-' . esc_attr( $event->ID ) . '"><form method="post"><input type="hidden" name="mi_portal_action" value="cancel_event"><input type="hidden" name="event_id" value="' . esc_attr( $event->ID ) . '">';
					wp_nonce_field( 'mi_portal_manage_event_' . $event->ID, 'mi_portal_nonce' );
					echo '<div class="mi-event-cancel-dialog__heading"><div><span class="mi-portal-eyebrow">Azione evento</span><h2 id="mi-cancel-event-title-' . esc_attr( $event->ID ) . '">Annulla “' . esc_html( $event_title ) . '”</h2></div><button type="button" class="mi-event-cancel-dialog__close" data-mi-cancel-dialog-close aria-label="Chiudi">×</button></div>';
					if ( $active_count > 0 ) echo '<p><strong>Attenzione:</strong> saranno annullate ' . esc_html( $active_count ) . ' prenotazioni. I dati resteranno nello storico.</p><label>Motivo <small>(facoltativo)</small><textarea name="cancellation_reason" rows="6" maxlength="2000" placeholder="Spiega brevemente perché l’evento viene annullato."></textarea></label><label class="mi-check"><input type="checkbox" name="confirm_cancellation" value="1" required> Ho compreso che le iscrizioni saranno annullate</label>';
					else echo '<p>L’evento non ha prenotazioni attive.</p><input type="hidden" name="confirm_cancellation" value="1">';
					echo '<div class="mi-event-cancel-dialog__actions"><button type="button" class="mi-secondary" data-mi-cancel-dialog-close>Indietro</button><button class="mi-danger" type="submit">Annulla definitivamente l’evento</button></div></form></dialog>';
				}
			}
			echo '</article>';
			if ( $is_selected ) {
				echo '<div id="mi-event-inline-panel-' . esc_attr( $event->ID ) . '" class="mi-event-inline-panel" data-mi-event-inline-panel data-mi-event-id="' . esc_attr( $event->ID ) . '">';
				self::event_management_card( $selected, $active_count, $registration_count );
				if ( ! empty( $_GET['mi_portal_outputs'] ) ) {
					self::event_outputs_panel( $selected );
					self::notice();
				}
				echo '</div>';
			}
		}
		if ( $events ) echo '</div>'; else echo '<p class="mi-portal-muted">' . ( $show_past ? 'Non ci sono eventi passati.' : 'Non ci sono eventi in corso, futuri o in bozza.' ) . '</p>';
		echo '</section>';
		$history_url = $show_past
			? add_query_arg( 'mi_portal_view', 'manage', $base_url )
			: add_query_arg( array( 'mi_portal_view' => 'manage', 'mi_portal_history' => '1' ), $base_url );
		echo '<p class="mi-event-history-link"><a href="' . esc_url( $history_url ) . '">' . ( $show_past ? 'Torna agli eventi attuali' : 'Visualizza eventi passati' ) . '</a></p>';
	}

	private static function event_management_card( $event_id, $active_count = null, $registration_count = null ) {
		$event = get_post( $event_id );
		if ( ! $event || ! MI_Access::can_access_event( $event_id ) ) return;
		$starts_at = (string) get_post_meta( $event_id, '_mi_event_starts_at', true );
		$opens_at = (string) get_post_meta( $event_id, '_mi_registration_opens_at', true );
		$closes_at = (string) get_post_meta( $event_id, '_mi_registration_closes_at', true );
		$location = (string) get_post_meta( $event_id, '_mi_event_location', true );
		$capacity = max( 1, absint( get_post_meta( $event_id, '_mi_capacity', true ) ) );
		$cancelled = (string) get_post_meta( $event_id, '_mi_event_cancelled_at', true );
		$expired = self::registration_deadline_passed( $closes_at );
		$registration_url = 'publish' === $event->post_status ? esc_url( MI_Shortcode::url_iscrizione( $event_id ) ) : '';
		if ( null === $active_count || null === $registration_count ) {
			global $wpdb;
			$totals = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS total_count,SUM(CASE WHEN status IN ('CONFIRMED','PENDING_PAYMENT','WAITLISTED','WAITLIST_OFFERED') AND capacity_released_at IS NULL THEN 1 ELSE 0 END) AS active_count FROM {$wpdb->prefix}mi_registrations WHERE event_id=%d", $event_id ), ARRAY_A );
			$active_count = (int) ( $totals['active_count'] ?? 0 );
			$registration_count = (int) ( $totals['total_count'] ?? 0 );
		}
		$list_args = array( 'mi_portal_view' => 'manage' );
		if ( ! empty( $_GET['mi_portal_history'] ) ) $list_args['mi_portal_history'] = '1';
		$list_url = add_query_arg( $list_args, self::base_url() ) . '#mi-elenco-eventi';
		echo '<section class="mi-event-management" data-mi-selected-event tabindex="-1"><a class="mi-event-management__back" href="' . esc_url( $list_url ) . '" aria-label="Comprimi la scheda dell’evento" title="Comprimi la scheda"><svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 11 6-6 6 6M6 18l6-6 6 6"/></svg></a><div class="mi-event-management__heading"><div><span class="mi-portal-eyebrow">Evento selezionato</span><h2>' . esc_html( $event->post_title ) . '</h2></div><span class="mi-event-management__state">' . esc_html( $cancelled ? 'Annullato' : ( $expired ? 'Scaduto' : ( 'publish' === $event->post_status ? 'Attivo' : 'Bozza' ) ) ) . '</span></div>';
		echo '<div class="mi-event-management__toolbar"><a class="mi-primary" href="' . esc_url( MI_Portal_Management::url( $event_id ) ) . '">Gestisci iscrizioni di questo evento</a>';
		if ( get_post_meta( $event_id, '_mi_operational_sheet_url', true ) && MI_Portal_Management::allowed() ) {
			echo '<a class="mi-sheet-button" href="' . esc_url( MI_Sheet_Open::url( $event_id ) ) . '" aria-label="Apri il foglio Google dell’evento"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true" focusable="false"><path d="M6 2h8l5 5v15H6zM14 2v6h5"/><path d="M9 11h7v8H9zM9 15h7M12.5 11v8"/></svg><span>Apri</span><span aria-hidden="true">↗</span></a>';
		}
		echo '</div>';
		if ( $cancelled ) { echo '<div class="mi-portal-notice mi-portal-error"><strong>Evento annullato</strong><p>La scheda e le iscrizioni sono conservate nello storico.</p></div></section>'; return; }
		if ( get_post_meta( $event_id, '_mi_workspace_event_pending', true ) ) {
			echo '<p class="mi-portal-muted" role="status">Salvato in WordPress · sincronizzazione Google in attesa. I tentativi proseguono automaticamente.</p>';
			if ( absint( get_post_meta( $event_id, '_mi_workspace_event_attempts', true ) ) >= 3 ) echo '<p class="mi-portal-error">Google non è ancora allineato: ' . esc_html( get_post_meta( $event_id, '_mi_workspace_event_error', true ) ) . '</p>';
		}
		echo '<details open><summary>Dettagli principali</summary><form class="mi-event-management__form" method="post" data-mi-event-quick-form><input type="hidden" name="mi_portal_action" value="update_event"><input type="hidden" name="event_id" value="' . esc_attr( $event_id ) . '">';
		wp_nonce_field( 'mi_portal_manage_event_' . $event_id, 'mi_portal_nonce' );
		echo '<label>Titolo<input name="title" maxlength="180" required value="' . esc_attr( $event->post_title ) . '"></label><label>Luogo<input name="location" maxlength="180" value="' . esc_attr( $location ) . '"></label><div class="mi-event-management__dates"><label>Inizio evento<input type="datetime-local" name="starts_at" value="' . esc_attr( $starts_at ) . '"></label><label>Inizio iscrizioni (vuoto = subito)<input type="datetime-local" name="opens_at" value="' . esc_attr( $opens_at ) . '"></label><label>Chiusura iscrizioni<input type="datetime-local" name="closes_at" value="' . esc_attr( $closes_at ) . '"></label><label>Posti disponibili<input type="number" min="1" max="10000" name="capacity" value="' . esc_attr( $capacity ) . '"></label></div><p class="mi-portal-warning" role="status" data-mi-late-registration-notice hidden>Attenzione: stai lasciando la possibilità di iscriversi anche dopo l’inizio dell’evento.</p><button class="mi-primary" type="submit" data-mi-event-quick-submit>Salva modifiche</button></form>';
		if ( $registration_url ) {
			echo '<div class="mi-event-management__registration"><strong>Link per le iscrizioni</strong><div class="mi-output-copy mi-event-registration-link"><input type="url" readonly aria-label="Link per le iscrizioni" value="' . esc_attr( $registration_url ) . '"><button type="button" class="mi-secondary" data-mi-copy="' . esc_attr( $registration_url ) . '">Copia</button><button type="button" class="mi-event-link-share" data-mi-share="' . esc_attr( $registration_url ) . '" data-mi-share-title="' . esc_attr( $event->post_title ) . '" aria-label="Condividi il link per le iscrizioni" title="Condividi il link per le iscrizioni"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="18" cy="5" r="2.5"></circle><circle cx="6" cy="12" r="2.5"></circle><circle cx="18" cy="19" r="2.5"></circle><path d="M8.2 10.8l7.6-4.5M8.2 13.2l7.6 4.5"></path></svg></button><a class="mi-secondary mi-output-link" href="' . esc_url( $registration_url ) . '" target="_blank" rel="noopener noreferrer">Apri <span aria-hidden="true">↗</span></a></div></div>';
		}
		if ( class_exists( 'MI_Event_QR' ) ) MI_Event_QR::render( $event_id );
		if ( $registration_url && 'DEPOSIT_BALANCE' === get_post_meta( $event_id, '_mi_economic_mode', true ) && 'ZERO' !== get_post_meta( $event_id, '_mi_pricing_mode', true ) ) {
			$balance_url = add_query_arg( array( 'mi_status' => 'balance', 'evento' => $event_id ), home_url( '/' ) );
			echo '<div class="mi-event-management__registration"><strong>Link per il versamento del saldo</strong><div class="mi-output-copy mi-event-registration-link"><input type="url" readonly aria-label="Link per il versamento del saldo" value="' . esc_attr( $balance_url ) . '"><button type="button" class="mi-secondary" data-mi-copy="' . esc_attr( $balance_url ) . '">Copia</button><a class="mi-secondary mi-output-link" href="' . esc_url( $balance_url ) . '" target="_blank" rel="noopener noreferrer" aria-label="Apri la pagina del saldo">Apri <span aria-hidden="true">↗</span></a></div></div>';
		}
		$full_edit_args = array( 'mi_portal_view' => 'create', 'mi_portal_edit' => $event_id );
		if ( ! empty( $_GET['mi_portal_history'] ) ) $full_edit_args['mi_portal_history'] = '1';
		echo '<p class="mi-event-management__full-edit"><span>Vuoi modificare l’immagine, le domande, i servizi o altri particolari?</span><a class="mi-primary" href="' . esc_url( add_query_arg( $full_edit_args, self::base_url() ) ) . '">Tutti i dettagli</a></p></details>';
		if ( $active_count > 0 ) {
			echo '<details class="mi-event-danger"><summary>Annulla l’evento</summary><div class="mi-event-danger__body"><p><strong>Attenzione:</strong> saranno annullate ' . esc_html( $active_count ) . ' prenotazioni attive o in lista d’attesa. I dati resteranno nello storico e gli eventuali rimborsi dovranno essere gestiti separatamente.</p><p>Per ogni prenotazione attiva o in lista d’attesa sarà preparato automaticamente un avviso all’indirizzo usato per iscriversi. L’invio effettivo dipende dalla modalità email generale; in ANTEPRIMA non parte alcuna email. Se vuoi, puoi aggiungere ulteriori spiegazioni per gli iscritti nel motivo dell’annullamento.</p><form method="post" data-mi-confirm="Confermi definitivamente l’annullamento di questo evento?"><input type="hidden" name="mi_portal_action" value="cancel_event"><input type="hidden" name="event_id" value="' . esc_attr( $event_id ) . '">';
			wp_nonce_field( 'mi_portal_manage_event_' . $event_id, 'mi_portal_nonce' );
			echo '<label>Motivo da comunicare agli iscritti <small>(facoltativo)</small><textarea name="cancellation_reason" rows="5" maxlength="2000" placeholder="Spiega brevemente perché l’evento è stato annullato."></textarea></label><label class="mi-check"><input type="checkbox" name="confirm_cancellation" value="1" required> Ho compreso che tutte le iscrizioni saranno annullate</label><button class="mi-danger" type="submit">Annulla definitivamente l’evento</button></form></div></details>';
		}
		if ( 'draft' === $event->post_status && 0 === $registration_count ) {
			echo '<details class="mi-event-trash"><summary>Elimina questa bozza</summary><div><p>La bozza sarà spostata nel cestino di WordPress e potrà essere ripristinata. Questa opzione è disponibile soltanto quando non esistono iscrizioni.</p><form method="post" data-mi-confirm="Spostare questa bozza nel cestino? Potrai ripristinarla dal pannello WordPress."><input type="hidden" name="mi_portal_action" value="trash_event"><input type="hidden" name="event_id" value="' . esc_attr( $event_id ) . '">';
			wp_nonce_field( 'mi_portal_manage_event_' . $event_id, 'mi_portal_nonce' );
			echo '<button class="mi-danger" type="submit">Sposta la bozza nel cestino</button></form></div></details>';
		}
		echo '</section>';
	}

	private static function booking_detail( $registration_id ) { echo '<div id="mi-portal-booking-detail">'; MI_Portal_Management::render( $registration_id ); echo '</div>'; }

	private static function create_view( $existing_event_id = 0 ) {
		$event = $existing_event_id ? get_post( $existing_event_id ) : null;
		if ( $event && ( MI_Event_Post_Type::EVENT_TYPE !== $event->post_type || ! in_array( $event->post_status, array( 'draft', 'publish', 'private' ), true ) || get_post_meta( $existing_event_id, '_mi_event_cancelled_at', true ) || ! MI_Access::can_access_event( $existing_event_id ) ) ) $event = null;
		$is_editing = (bool) $event;
		$is_draft = $is_editing && 'draft' === $event->post_status;
		$copy_from = $is_editing ? 0 : absint( $_GET['mi_copy_from'] ?? 0 );
		$model = $copy_from ? get_post( $copy_from ) : null;
		if ( $copy_from && ( ! $model || MI_Event_Post_Type::EVENT_TYPE !== $model->post_type || ! in_array( $model->post_status, array( 'draft', 'publish', 'private' ), true ) || ! MI_Access::can_access_event( $copy_from ) ) ) $copy_from = 0;
		$configuration_id = $is_editing ? $existing_event_id : $copy_from;
		$value = static function ( $key, $default = '' ) use ( $configuration_id, $is_editing ) {
			if ( ! $configuration_id || ( ! $is_editing && in_array( $key, array( '_mi_registration_opens_at', '_mi_registration_closes_at', '_mi_event_starts_at' ), true ) ) ) return $default;
			return metadata_exists( 'post', $configuration_id, $key ) ? get_post_meta( $configuration_id, $key, true ) : $default;
		};
		$activity_id = absint( $value( '_mi_activity_id' ) );
		$participant_fields = (array) $value( '_mi_participant_fields', array() );
		$participant_required = (array) $value( '_mi_participant_required_fields', array() );
		$custom_questions = array_values( (array) $value( '_mi_custom_participant_fields', array() ) );
		$options = array();
		foreach ( (array) $value( '_mi_options', array() ) as $option ) if ( ! empty( $option['code'] ) ) $options[ sanitize_key( $option['code'] ) ] = (array) $option;
		$bus_routes = array();
		foreach ( $options as $option_code => $option ) {
			if ( 'pullman' !== $option_code && 0 !== strpos( $option_code, 'pullman-' ) ) continue;
			$bus_routes[] = array(
				'id'    => $option_code,
				'label' => preg_replace( '/^Pullman\\s*[—-]\\s*/u', '', (string) ( $option['name'] ?? '' ) ),
				'price' => number_format( absint( $option['price_cents'] ?? 0 ) / 100, 2, ',', '' ),
			);
		}
		$accommodations_selected = (array) $value( '_mi_accommodations', array() );
		$accommodation_management = strtoupper( (string) $value( '_mi_accommodation_management', $is_editing ? 'PREBOOKED' : 'ON_DEMAND' ) );
		if ( ! in_array( $accommodation_management, array( 'PREBOOKED', 'ON_DEMAND' ), true ) ) $accommodation_management = 'ON_DEMAND';
		$payment_methods_selected = (array) $value( '_mi_payment_methods', array() );
		$pricing_mode_selected = strtoupper( (string) $value( '_mi_pricing_mode', 'ZERO' ) );
		$economic_mode_selected = strtoupper( (string) $value( '_mi_economic_mode', 'FULL_PAYMENT' ) );
		$deposit_mode_selected = 'FIXED' === strtoupper( (string) $value( '_mi_deposit_mode', 'PERCENTAGE' ) ) ? 'FIXED' : 'PERCENTAGE';
		$saved_ticket_types = array_values( array_filter( (array) $value( '_mi_ticket_types', array() ), 'is_array' ) );
		$max_per_order = $configuration_id ? min( 20, max( 1, absint( $saved_ticket_types[0]['max_per_order'] ?? 1 ) ) ) : 1;
		$multiple_per_order = $max_per_order > 1;
		$models = get_posts( array( 'post_type' => MI_Event_Post_Type::EVENT_TYPE, 'post_status' => array( 'publish', 'draft' ), 'numberposts' => -1, 'orderby' => 'date', 'order' => 'DESC' ) );
		$models = array_values( array_filter( $models, static function ( $model ) { return MI_Access::can_access_event( $model->ID ); } ) );
		$model_dates = array();
		$current_models = array();
		$past_models = array();
		foreach ( $models as $model ) {
			$starts_at = (string) get_post_meta( $model->ID, '_mi_event_starts_at', true );
			$closes_at = (string) get_post_meta( $model->ID, '_mi_registration_closes_at', true );
			$model_dates[ $model->ID ] = strtotime( $starts_at ?: $closes_at ) ?: 0;
			if ( get_post_meta( $model->ID, '_mi_event_archived_at', true ) || self::is_past_event( $starts_at ?: $closes_at ) ) $past_models[] = $model;
			else $current_models[] = $model;
		}
		usort( $current_models, static function ( $a, $b ) use ( $model_dates ) {
			$a_time = $model_dates[ $a->ID ] ?: PHP_INT_MAX;
			$b_time = $model_dates[ $b->ID ] ?: PHP_INT_MAX;
			return $a_time <=> $b_time;
		} );
		usort( $past_models, static function ( $a, $b ) use ( $model_dates ) { return $model_dates[ $b->ID ] <=> $model_dates[ $a->ID ]; } );
		$models = array_merge( $current_models, array_slice( $past_models, 0, 10 ) );
		$current_model_ids = array_flip( array_map( static function ( $model ) { return (int) $model->ID; }, $current_models ) );
		$model_booking_limits = array();
		foreach ( $models as $model ) {
			$model_tickets = array_values( array_filter( (array) get_post_meta( $model->ID, '_mi_ticket_types', true ), 'is_array' ) );
			$model_booking_limits[ $model->ID ] = min( 20, max( 1, absint( $model_tickets[0]['max_per_order'] ?? 1 ) ) );
		}
		$activities = get_posts( array( 'post_type' => MI_Event_Post_Type::ACTIVITY_TYPE, 'post_status' => array( 'publish', 'draft' ), 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
		$activity_scope = MI_Access::activity_ids();
		if ( 'ALL' !== $activity_scope ) $activities = array_values( array_filter( $activities, static function ( $activity ) use ( $activity_scope, $activity_id ) { return (int) $activity->ID === $activity_id || in_array( (int) $activity->ID, $activity_scope, true ); } ) );
		$catalog = MI_Field_Schema::catalog();
		$common_fields = array_intersect_key( $catalog, array_flip( array( 'email', 'phone', 'birth_date' ) ) );
		$additional_fields = array_diff_key( $catalog, $common_fields );
		$today_start = current_time( 'Y-m-d\TH:i' );
		$email_settings = MI_Modello_Email::impostazioni( $configuration_id );
		$draft_registration_count = 0;
		$draft_initial_step = 0;
		if ( $is_draft ) {
			global $wpdb;
			$draft_registration_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}mi_registrations WHERE event_id=%d", $existing_event_id ) );
			$draft_initial_step = self::draft_initial_step( $existing_event_id );
		}
		$wizard_back_url = '';
		if ( $is_editing ) {
			$wizard_back_args = array( 'mi_portal_view' => 'manage', 'mi_portal_event' => $existing_event_id );
			if ( ! empty( $_GET['mi_portal_history'] ) ) $wizard_back_args['mi_portal_history'] = '1';
			$wizard_back_url = add_query_arg( $wizard_back_args, self::base_url() ) . '#mi-event-inline-panel-' . $existing_event_id;
		}
		ob_start();
		?><?php if ( $is_editing ) : ?><div class="mi-draft-resume"><div class="mi-portal-notice mi-portal-success"><strong><?php echo $is_draft ? 'Riprendi la creazione di' : 'Modifica'; ?> “<?php echo esc_html( $event->post_title ); ?>”</strong><p><?php echo $is_draft ? 'Completa o correggi i passaggi e salva nuovamente la stessa bozza.' : 'Stai aggiornando lo stesso evento. Il modulo e il foglio già collegati non saranno duplicati.'; ?></p></div><?php if ( $is_draft && 0 === $draft_registration_count ) : ?><form class="mi-draft-resume__delete" method="post" data-mi-confirm="Eliminare questa bozza? Sarà spostata nel cestino di WordPress."><input type="hidden" name="mi_portal_action" value="trash_event"><input type="hidden" name="event_id" value="<?php echo esc_attr( $existing_event_id ); ?>"><?php wp_nonce_field( 'mi_portal_manage_event_' . $existing_event_id, 'mi_portal_nonce' ); ?><button class="mi-danger" type="submit">Elimina questa bozza</button></form><?php endif; ?></div><?php endif; ?><form class="mi-event-wizard" method="post" enctype="multipart/form-data" data-mi-initial-step="<?php echo esc_attr( $draft_initial_step ); ?>" data-mi-back-url="<?php echo esc_url( $wizard_back_url ); ?>" data-mi-accommodation-management-mode="<?php echo esc_attr( $accommodation_management ); ?>" data-mi-operational-profile="<?php echo esc_attr( $value( '_mi_operational_profile', 'AUTOMATICO' ) ); ?>" data-mi-deposit-mode="<?php echo esc_attr( $deposit_mode_selected ); ?>" data-mi-deposit-fixed="<?php echo esc_attr( number_format( absint( $value( '_mi_deposit_fixed_cents', 0 ) ) / 100, 2, ',', '' ) ); ?>"><input type="hidden" name="mi_portal_action" value="create_event"><input type="hidden" name="event_id" value="<?php echo esc_attr( $is_editing ? $existing_event_id : 0 ); ?>"><?php wp_nonce_field( 'mi_portal_create_event', 'mi_portal_nonce' ); ?>
		<section class="mi-wizard-step is-active"><span class="mi-portal-eyebrow">1 di 8</span><h2>Come si chiama?</h2><label>Titolo dell’evento<input name="title" required maxlength="180" value="<?php echo esc_attr( $is_editing ? $event->post_title : '' ); ?>" placeholder="Es. Pellegrinaggio ad Assisi"></label><label>Gruppo organizzatore<select name="activity_id"><option value="">Scegli un gruppo</option><?php foreach ( $activities as $activity ) : ?><option value="<?php echo esc_attr( $activity->ID ); ?>" <?php selected( $activity_id, $activity->ID ); ?>><?php echo esc_html( $activity->post_title ); ?></option><?php endforeach; ?></select></label><?php if ( self::can_manage_groups() ) : ?><p class="mi-portal-muted mi-wizard-group-link">Crea o modifica gruppo in: <a href="<?php echo esc_url( add_query_arg( 'mi_portal_view', 'groups', self::base_url() ) ); ?>" target="_blank" rel="noopener">Gruppi</a></p><?php endif; ?><?php if ( ! $is_editing ) : ?><label>Vuoi partire dalla configurazione di un evento precedente?<select name="copy_event_id" data-mi-copy-event><option value="">No, configuro liberamente il nuovo evento</option><?php foreach ( $models as $model ) : ?><option value="<?php echo esc_attr( $model->ID ); ?>" data-mi-max-per-order="<?php echo esc_attr( $model_booking_limits[ $model->ID ] ); ?>" <?php selected( $copy_from, $model->ID ); ?>><?php echo esc_html( $model->post_title . ( isset( $current_model_ids[ $model->ID ] ) ? ' — in corso' : ' — passato' ) ); ?></option><?php endforeach; ?></select></label><p class="mi-portal-muted">Dopo tutti gli eventi in corso sono proposti fino a 10 eventi passati. Vengono copiate solo impostazioni e domande, mai iscrizioni o dati personali.</p><?php endif; ?></section>
		<section class="mi-wizard-step"><span class="mi-portal-eyebrow">2 di 8</span><h2>Cosa devono sapere le persone?</h2><label>Luogo<input name="location" maxlength="180" value="<?php echo esc_attr( $value( '_mi_event_location' ) ); ?>" placeholder="Es. Basilica di Sant’Eugenio"></label><label>Presentazione e informazioni<textarea name="description" rows="6" maxlength="1200" data-mi-max-lines="6" placeholder="Descrivi programma, orari, cosa portare e ogni informazione utile."><?php echo esc_textarea( $is_editing ? $event->post_content : '' ); ?></textarea><small>Massimo 6 righe.</small></label></section>
		<section class="mi-wizard-step"><span class="mi-portal-eyebrow">3 di 8</span><h2>Immagine</h2><?php $current_cover = $is_editing ? get_the_post_thumbnail_url( $existing_event_id, 'medium_large' ) : ''; if ( $current_cover ) : ?><figure class="mi-wizard-current-cover"><img src="<?php echo esc_url( $current_cover ); ?>" alt=""><figcaption>Immagine attuale</figcaption></figure><?php endif; ?><label><?php echo $current_cover ? 'Sostituisci l’immagine in evidenza' : 'Immagine in evidenza'; ?> <small>(facoltativa)</small><input type="file" name="cover_image" accept="image/jpeg,image/png,image/webp" data-mi-max-bytes="2097152"></label><p class="mi-portal-muted">JPG, PNG o WebP, massimo 2 MB. Le fotografie grandi vengono ridotte automaticamente.</p><p class="mi-image-preparation" data-mi-image-status role="status" aria-live="polite"></p></section>
		<section class="mi-wizard-step"><span class="mi-portal-eyebrow">4 di 8</span><h2>Date e posti</h2><div class="mi-wizard-grid"><label>Apertura iscrizioni<input type="text" inputmode="numeric" maxlength="16" pattern="\d{2}/\d{2}/\d{4} \d{2}:\d{2}" name="opens_at" value="<?php echo esc_attr( self::portal_date_input_value( $value( '_mi_registration_opens_at' ) ) ); ?>" placeholder="gg/mm/aaaa hh:mm" data-mi-opens><small>Facoltativa: se vuota, le iscrizioni aprono subito alla pubblicazione.</small></label><label>Chiusura iscrizioni<input type="text" inputmode="numeric" maxlength="16" pattern="\d{2}/\d{2}/\d{4} \d{2}:\d{2}" name="closes_at" value="<?php echo esc_attr( self::portal_date_input_value( $value( '_mi_registration_closes_at' ) ) ); ?>" placeholder="gg/mm/aaaa hh:mm" data-mi-closes required></label><label>Data e ora di inizio<input type="text" inputmode="numeric" maxlength="16" pattern="\d{2}/\d{2}/\d{4} \d{2}:\d{2}" name="starts_at" value="<?php echo esc_attr( self::portal_date_input_value( $value( '_mi_event_starts_at' ) ) ); ?>" placeholder="gg/mm/aaaa hh:mm" data-mi-starts required></label><label>Posti disponibili<input type="number" min="1" max="10000" name="capacity" value="<?php echo esc_attr( max( 1, absint( $value( '_mi_capacity', 30 ) ) ) ); ?>" required></label></div><p class="mi-portal-muted">Formato richiesto: gg/mm/aaaa hh:mm. Ordine: apertura iscrizioni, chiusura iscrizioni, inizio evento. La chiusura e l’inizio non possono essere nel passato.</p><fieldset class="mi-booking-limit" data-mi-booking-limit><legend>Quante persone può comprendere una prenotazione?</legend><label class="mi-check"><input type="radio" name="booking_limit_mode" value="ONE" <?php checked( ! $multiple_per_order ); ?>> 1 — Ogni persona si iscrive separatamente</label><label class="mi-check"><input type="radio" name="booking_limit_mode" value="MULTIPLE" <?php checked( $multiple_per_order ); ?>> Più persone nella stessa prenotazione</label><label data-mi-booking-limit-value>Fino a quante persone?<input type="number" name="max_per_order" min="2" max="20" value="<?php echo esc_attr( max( 2, $max_per_order ) ); ?>" required></label><small>Questo limite riguarda la singola prenotazione, non i posti complessivi dell’evento.</small></fieldset><label class="mi-check"><input type="checkbox" name="waitlist_enabled" value="1" data-mi-waitlist <?php checked( '1', $value( '_mi_waitlist_enabled' ) ); ?>> Attiva automaticamente la lista d’attesa a esaurimento posti</label><label data-mi-waitlist-offer>Tempo per accettare un posto liberato<input type="number" name="waitlist_offer_hours" min="1" max="168" value="<?php echo esc_attr( min( 168, max( 1, absint( $value( '_mi_waitlist_offer_hours', 48 ) ) ) ) ); ?>" required> <small>ore; il valore consigliato è 48.</small></label></section>
		<section class="mi-wizard-step"><span class="mi-portal-eyebrow">5 di 8</span><h2>Quali dati chiediamo?</h2><p>Nome e cognome sono sempre obbligatori per ogni partecipante.</p><fieldset data-mi-participant-scope <?php echo $multiple_per_order ? '' : 'hidden disabled'; ?>><legend>Dati aggiuntivi da compilare</legend><label class="mi-check"><input type="radio" name="participant_extra_scope" value="ONE" <?php checked( 'ONE', $value( '_mi_participant_extra_scope', 'ONE' ) ); ?>> Solo per uno degli iscritti (il primo, modificabile)</label><label class="mi-check"><input type="radio" name="participant_extra_scope" value="ALL" <?php checked( 'ALL', $value( '_mi_participant_extra_scope', 'ONE' ) ); ?>> Per tutti gli iscritti</label></fieldset><div class="mi-field-choice-list"><?php self::render_field_choices( $common_fields, $participant_fields, $participant_required ); ?></div><details class="mi-additional-fields"><summary>Ulteriori dati per alcuni eventi</summary><div class="mi-field-choice-list"><?php self::render_field_choices( $additional_fields, $participant_fields, $participant_required ); ?></div></details></section>
		<section class="mi-wizard-step"><span class="mi-portal-eyebrow">6 di 8</span><h2>Domande particolari</h2><p class="mi-portal-muted">Aggiungi solo ciò che serve davvero. Puoi lasciare tutto vuoto.</p><div class="mi-custom-questions"><?php for ( $i = 0; $i < 4; $i++ ) : $question = (array) ( $custom_questions[ $i ] ?? array() ); $question_type = sanitize_key( $question['type'] ?? 'text' ); ?><div class="mi-custom-question"><input type="hidden" name="custom_question_key[]" value="<?php echo esc_attr( $question['key'] ?? '' ); ?>"><label>Domanda <?php echo esc_html( $i + 1 ); ?><input name="custom_question_label[]" maxlength="120" value="<?php echo esc_attr( $question['label'] ?? '' ); ?>" placeholder="Es. Allergie da segnalare"></label><label>Risposta<select name="custom_question_type[]"><option value="text" <?php selected( $question_type, 'text' ); ?>>Breve</option><option value="yesno" <?php selected( $question_type, 'yesno' ); ?>>Sì / No</option><option value="textarea" <?php selected( $question_type, 'textarea' ); ?>>Testo libero</option><option value="date" <?php selected( $question_type, 'date' ); ?>>Data</option><option value="email" <?php selected( $question_type, 'email' ); ?>>Email</option><option value="tel" <?php selected( $question_type, 'tel' ); ?>>Telefono</option><option value="select" <?php selected( $question_type, 'select' ); ?>>Scelta</option></select></label><label class="mi-check"><input type="checkbox" name="custom_question_required[<?php echo esc_attr( $i ); ?>]" value="1" <?php checked( ! empty( $question['required'] ) ); ?>> Obbligatoria</label></div><?php endfor; ?></div><label class="mi-check"><input type="checkbox" name="special_requests_enabled" value="1" <?php checked( '1', $value( '_mi_special_requests_enabled' ) ); ?>> Mostra uno spazio facoltativo per richieste particolari</label><label class="mi-check"><input type="checkbox" name="marketing_enabled" value="1" <?php checked( '1', $value( '_mi_marketing_enabled' ) ); ?>> Mostra “Comunicazioni su future iniziative”</label></section>
		<section class="mi-wizard-step"><span class="mi-portal-eyebrow">7 di 8</span><h2>Servizi e quote (se presenti)</h2><label class="mi-check"><input type="checkbox" name="overnight" value="1" data-mi-overnight <?php checked( '1', $value( '_mi_overnight_enabled' ) ); ?>> È previsto il pernottamento</label><div data-mi-accommodations hidden><h3>Tipi di alloggio</h3><?php foreach ( array( 'SINGOLA' => 'Singola', 'DOPPIA_SEPARATI' => 'Doppia con letti separati', 'DOPPIA_MATRIMONIALE' => 'Doppia matrimoniale', 'TRIPLA' => 'Tripla', 'MULTIPLA' => 'Multipla' ) as $code => $label ) : ?><div class="mi-accommodation-fee"><label class="mi-check"><input type="checkbox" name="accommodations[]" value="<?php echo esc_attr( $code ); ?>" data-mi-accommodation <?php checked( in_array( $code, $accommodations_selected, true ) ); ?>> <?php echo esc_html( $label ); ?></label><?php $accommodation_option = (array) ( $options[ 'alloggio-' . strtolower( str_replace( '_', '-', $code ) ) ] ?? array() ); ?><label>Quota (€)<input name="accommodation_price[<?php echo esc_attr( $code ); ?>]" value="<?php echo esc_attr( ! empty( $accommodation_option ) ? number_format( absint( $accommodation_option['price_cents'] ?? 0 ) / 100, 2, ',', '' ) : '' ); ?>" inputmode="decimal" placeholder="Es. 80,00" <?php disabled( ! in_array( $code, $accommodations_selected, true ) ); ?>></label></div><?php endforeach; ?></div><h3>Quote accessorie per partecipante</h3><p class="mi-portal-muted">Sono indipendenti dal pernottamento. Lascia una voce non selezionata se non è prevista.</p><?php foreach ( array( 'colazione' => 'Colazione', 'assicurazione-disdetta' => 'Assicurazione disdetta', 'assicurazione-sanitaria' => 'Assicurazione sanitaria', 'pranzo' => 'Pranzo', 'rimborso-spese' => 'Rimborso spese generico' ) as $service_code => $service_label ) : $service = (array) ( $options[ $service_code ] ?? array() ); ?><div class="mi-service-fee"><label class="mi-check"><input type="checkbox" name="service_enabled[<?php echo esc_attr( $service_code ); ?>]" value="1" data-mi-service-fee <?php checked( ! empty( $service ) ); ?>> <?php echo esc_html( $service_label ); ?></label><label>Quota (€)<input name="service_price[<?php echo esc_attr( $service_code ); ?>]" value="<?php echo esc_attr( ! empty( $service ) ? number_format( absint( $service['price_cents'] ?? 0 ) / 100, 2, ',', '' ) : '' ); ?>" inputmode="decimal" placeholder="Es. 25,00" <?php disabled( empty( $service ) ); ?>></label></div><?php endforeach; ?><div class="mi-bus-routes" data-mi-bus-routes><div class="mi-bus-routes__heading"><h3 class="mi-bus-title">Pullman</h3><button type="button" class="mi-secondary" data-mi-add-bus-route>Aggiungi tratta</button><label class="mi-check"><input type="checkbox" name="bus_assignment_enabled" value="1" <?php checked( '1', $value( '_mi_bus_assignment_enabled' ) ); ?>> Assegneremo le persone a un pullman determinato</label></div><p class="mi-portal-muted">Facoltativo: indica una sigla, per esempio RM-FCO o RM-Assisi, e la relativa quota.</p><div data-mi-bus-routes-list><?php foreach ( $bus_routes as $route ) : ?><div class="mi-bus-route"><input type="hidden" name="bus_route_id[]" value="<?php echo esc_attr( $route['id'] ); ?>"><label>Descrizione (facoltativa)<input name="bus_route_code[]" maxlength="60" value="<?php echo esc_attr( $route['label'] ); ?>" placeholder="Es. RM-FCO"></label><label>Quota (€)<input name="bus_route_price[]" value="<?php echo esc_attr( $route['price'] ); ?>" inputmode="decimal" placeholder="Es. 25,00"></label><button type="button" class="mi-icon-button" data-mi-remove-bus-route aria-label="Rimuovi questa tratta">×</button></div><?php endforeach; ?></div><template data-mi-bus-route-template><div class="mi-bus-route"><input type="hidden" name="bus_route_id[]" value=""><label>Descrizione (facoltativa)<input name="bus_route_code[]" maxlength="60" placeholder="Es. RM-FCO"></label><label>Quota (€)<input name="bus_route_price[]" inputmode="decimal" placeholder="Es. 25,00"></label><button type="button" class="mi-icon-button" data-mi-remove-bus-route aria-label="Rimuovi questa tratta">×</button></div></template></div><?php MI_Extra_Services::render( $options ); ?><label>Come sarà l’evento?<select name="pricing_mode" data-mi-pricing aria-describedby="mi-pricing-help"><option value="ZERO" <?php selected( $pricing_mode_selected, 'ZERO' ); ?>>Iscrizione senza quote nel modulo</option><option value="FIXED" <?php selected( $pricing_mode_selected, 'FIXED' ); ?>>Quota uguale per tutti</option><option value="NONE" <?php selected( $pricing_mode_selected, 'NONE' ); ?>>In base ai servizi scelti</option><option value="CALCULATED" <?php selected( $pricing_mode_selected, 'CALCULATED' ); ?>>Prezzi configurati nei ticket e nelle opzioni avanzate</option></select></label><p id="mi-pricing-help" class="mi-portal-muted">Iscrizione senza quote nel modulo: per eventi gratuiti oppure con quote e alloggi gestiti separatamente, ad esempio da un’agenzia. Il modulo raccoglie soltanto i dati di iscrizione.</p><label data-mi-fixed-price hidden>Quota base per partecipante (€)<input name="fixed_price" value="<?php echo esc_attr( number_format( absint( $value( '_mi_fixed_price_cents', 0 ) ) / 100, 2, ',', '' ) ); ?>" inputmode="decimal" placeholder="Es. 120,00"></label><label>Modalità di pagamento richiesta<select name="economic_mode" data-mi-economic><option value="FULL_PAYMENT" <?php selected( $economic_mode_selected, 'FULL_PAYMENT' ); ?>>Unica soluzione</option><option value="DEPOSIT_BALANCE" <?php selected( $economic_mode_selected, 'DEPOSIT_BALANCE' ); ?>>Caparra e saldo</option></select></label><div data-mi-payment hidden><label>Tempo per pagare dopo una rettifica<input type="number" name="reopened_payment_hours" min="1" max="168" value="<?php echo esc_attr( min( 168, max( 1, absint( $value( '_mi_reopened_payment_hours', 48 ) ) ) ) ); ?>"><small>Ore (da 1 a 168; predefinito 48). Si applica quando una rettifica riapre il pagamento e la scadenza precedente è assente o trascorsa. Le scadenze ancora future restano valide; la lista d’attesa usa il proprio termine.</small></label><label data-mi-deposit hidden>Percentuale caparra<input type="number" name="deposit_percentage" min="1" max="99" value="<?php echo esc_attr( min( 99, max( 1, absint( $value( '_mi_deposit_percentage', 30 ) ) ) ) ); ?>"></label><fieldset><legend>Metodi accettati</legend><label class="mi-check"><input type="checkbox" name="payment_methods[]" value="BANK_TRANSFER" <?php checked( in_array( 'BANK_TRANSFER', $payment_methods_selected, true ) ); ?>> Bonifico</label><label class="mi-check"><input type="checkbox" name="payment_methods[]" value="CARD" <?php checked( in_array( 'CARD', $payment_methods_selected, true ) ); ?>> Carta</label><label class="mi-check"><input type="checkbox" name="payment_methods[]" value="CASH" <?php checked( in_array( 'CASH', $payment_methods_selected, true ) ); ?>> Contanti</label></fieldset></div></section>
		<section class="mi-wizard-step"><span class="mi-portal-eyebrow">8 di 8</span><h2><?php echo $is_editing ? 'Controlla le modifiche' : 'Controlla e crea la bozza'; ?></h2><label>Se vuoi, indica un nome abbreviato per il link dell’evento<input name="public_slug" maxlength="60" pattern="[a-zA-Z0-9]+(?:-[a-zA-Z0-9]+)*" value="<?php echo esc_attr( $is_editing ? get_post_meta( $existing_event_id, '_mi_public_slug', true ) : '' ); ?>" placeholder="cammino27" autocomplete="off"><small>Per esempio: <?php echo esc_html( home_url( '/v/cammino27' ) ); ?>. Usa lettere senza accenti, numeri e trattini. Il nome deve essere libero. Lascia vuoto per mantenere il link attuale o usare quello automatico. I link già assegnati restano riservati.</small></label><label class="mi-check"><input type="checkbox" name="event_qr_enabled" value="1" <?php checked( $value( '_mi_event_qr_enabled', '0' ), '1' ); ?>> Genera il QR delle iscrizioni con il logo del gruppo</label><p class="mi-portal-muted">Dopo la pubblicazione potrai scaricare il PNG. È necessario un logo del gruppo; il QR si aggiorna con il link e il logo correnti.</p><label>Pagina dopo l’iscrizione (facoltativa)<input type="url" name="completion_url" value="<?php echo esc_attr( $value( '_mi_completion_url' ) ); ?>" placeholder="https://…"><small>Lascia vuoto per tornare alla homepage. Il pulsante Termina e il ritorno automatico dopo 15 secondi conducono a questa pagina.</small></label><details class="mi-confirmation-email"><summary>Vuoi personalizzare l’email di conferma dell’iscrizione?</summary><div><p>Puoi modificare il messaggio che sarà preparato per chi si iscrive. In modalità ANTEPRIMA non viene inviata alcuna email.</p><label>Oggetto<input name="confirmation_email_subject" maxlength="180" value="<?php echo esc_attr( $email_settings['subject'] ); ?>" required></label><label>Testo dell’email<textarea name="confirmation_email_text" rows="12" maxlength="5000" required><?php echo esc_textarea( $email_settings['text'] ); ?></textarea></label><p class="mi-portal-muted" data-mi-email-free-placeholders hidden>Puoi usare: <code>{{sottoscrittore.nome_completo}}</code>, <code>{{sottoscrittore.nome}}</code>, <code>{{evento.titolo}}</code>, <code>{{evento.data}}</code>, <code>{{evento.luogo}}</code>, <code>{{ordine.codice}}</code> e <code>{{ordine.riepilogo}}</code>.</p><p class="mi-portal-muted" data-mi-email-paid-placeholders>Puoi usare: <code>{{sottoscrittore.nome_completo}}</code>, <code>{{sottoscrittore.nome}}</code>, <code>{{evento.titolo}}</code>, <code>{{evento.data}}</code>, <code>{{evento.luogo}}</code>, <code>{{ordine.codice}}</code>, <code>{{ordine.riepilogo}}</code>, <code>{{ordine.riepilogo_economico}}</code>, <code>{{pagamento.istruzioni}}</code>, <code>{{pagamento.scadenza}}</code> e <code>{{pagamento.causale}}</code>.</p><div class="mi-confirmation-email__preview"><strong data-mi-confirmation-subject></strong><pre data-mi-confirmation-text></pre></div></div></details><div class="mi-wizard-review" data-mi-review></div><?php if ( $is_editing ) : ?><p class="mi-action-progress" role="status" aria-live="polite" hidden>Salvataggio in corso. Al termine sarai riportato alla pagina Gestisci eventi.</p><button class="mi-primary" type="submit">Salva modifiche</button><?php else : ?><p>Nulla sarà pubblicato automaticamente e non partirà alcuna email. Dopo il salvataggio passerai alla schermata “Attiva l’evento”.</p><button class="mi-primary" type="submit">Crea la bozza e vai ad Attiva l’evento</button><?php endif; ?></section>
		<div class="mi-wizard-actions"><button type="button" class="mi-secondary" data-mi-back disabled>Indietro</button><button type="button" class="mi-primary" data-mi-next>Continua</button></div></form><?php
		$wizard_markup = ob_get_clean();
		echo str_replace( '<details class="mi-confirmation-email">', self::event_email_appearance_fields( $configuration_id, $activity_id ) . '<details class="mi-confirmation-email">', $wizard_markup );
	}

	private static function event_email_appearance_fields( $event_id, $group_id ) {
		$style = $event_id ? (array) get_post_meta( $event_id, '_mi_email_style', true ) : array();
		$resolved = $event_id ? MI_Modello_Email::stile_risolto( $event_id ) : MI_Modello_Email::stile_default();
		$identity = ! empty( array_intersect_key( $style, array_flip( array( 'identity_name', 'identity_detail', 'signature' ) ) ) );
		$colors = ! empty( array_intersect_key( $style, array_flip( array( 'primary_color', 'secondary_color' ) ) ) );
		$source = $group_id ? 'Gruppo: ' . get_the_title( $group_id ) : 'Default parrocchia';
		ob_start(); ?>
		<details class="mi-email-appearance"><summary>Aspetto email</summary><input type="hidden" name="event_email_style_present" value="1"><label>Logo nelle email<select name="event_email_logo_mode"><option value="INHERIT" <?php selected( ! array_key_exists( 'logo_enabled', $style ) , true ); ?>>Automatico / eredita</option><option value="SHOW" <?php selected( array_key_exists( 'logo_enabled', $style ) && ! empty( $style['logo_enabled'] ) , true ); ?>>Mostra</option><option value="HIDE" <?php selected( array_key_exists( 'logo_enabled', $style ) && empty( $style['logo_enabled'] ) , true ); ?>>Nascondi</option></select></label><p><strong>Usa lo stile ereditato</strong> · <?php echo esc_html( $source ); ?></p><p class="mi-portal-muted"><?php echo $event_id && get_post_thumbnail_id( $event_id ) ? 'Banner email: immagine dell’evento.' : 'Banner email: banner del gruppo o default parrocchia.'; ?> L’indirizzo per le risposte si imposta nella scheda Gruppi.</p><label class="mi-check"><input type="checkbox" name="event_email_identity_enabled" value="1" <?php checked( $identity ); ?>> Personalizza identità e firma</label><div class="mi-wizard-grid"><label>Nome visualizzato<input name="event_email_identity_name" maxlength="120" value="<?php echo esc_attr( $style['identity_name'] ?? '' ); ?>"></label><label>Dettaglio<input name="event_email_identity_detail" maxlength="180" value="<?php echo esc_attr( $style['identity_detail'] ?? '' ); ?>"></label><label>Firma<input name="event_email_signature" maxlength="240" value="<?php echo esc_attr( $style['signature'] ?? '' ); ?>"></label></div><label class="mi-check"><input type="checkbox" name="event_email_colors_enabled" value="1" <?php checked( $colors ); ?>> Personalizza colori</label><div class="mi-wizard-grid"><label>Colore principale<input type="color" name="event_email_primary_color" value="<?php echo esc_attr( $style['primary_color'] ?? $resolved['primary_color'] ); ?>"></label><label>Colore CTA<input type="color" name="event_email_secondary_color" value="<?php echo esc_attr( $style['secondary_color'] ?? $resolved['secondary_color'] ); ?>"></label></div><label class="mi-check"><input type="checkbox" name="event_email_banner_enabled" value="1" <?php checked( ! empty( $style['banner_url'] ) ); ?>> Sostituisci soltanto il banner</label><label>URL HTTPS del banner<input type="url" name="event_email_banner_url" value="<?php echo esc_attr( $style['banner_url'] ?? '' ); ?>" placeholder="https://…"></label></details>
		<?php return ob_get_clean();
	}

	private static function render_field_choices( $fields, $enabled = array(), $required = array() ) {
		foreach ( $fields as $key => $field ) {
			echo '<div class="mi-field-choice"><label class="mi-check"><input type="checkbox" name="participant_fields[]" value="' . esc_attr( $key ) . '" data-mi-field="' . esc_attr( $key ) . '" ' . checked( in_array( $key, $enabled, true ), true, false ) . '> ' . esc_html( $field['label'] ) . '</label><label class="mi-check mi-field-required"><input type="checkbox" name="participant_required[]" value="' . esc_attr( $key ) . '" data-mi-required="' . esc_attr( $key ) . '" ' . checked( in_array( $key, $required, true ), true, false ) . '> Obbligatorio</label><small>' . esc_html( $field['help'] ?? '' ) . '</small></div>';
		}
	}

	private static function format_date( $value, $format = 'd/m/Y H:i' ) {
		if ( ! $value ) return 'Data da definire';
		$date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', (string) $value, wp_timezone() );
		return $date instanceof DateTimeImmutable ? wp_date( $format, $date->getTimestamp(), wp_timezone() ) : (string) $value;
	}
	private static function date_badge( $value ) {
		if ( ! $value ) return array( 'month' => 'DATA', 'day' => '—' );
		$date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', (string) $value, wp_timezone() );
		if ( ! $date instanceof DateTimeImmutable ) return array( 'month' => 'DATA', 'day' => '—' );
		return array(
			'month' => mb_strtoupper( rtrim( wp_date( 'M', $date->getTimestamp(), wp_timezone() ), '.' ) ),
			'day'   => wp_date( 'd', $date->getTimestamp(), wp_timezone() ),
		);
	}
	private static function date_timestamp( $value ) {
		if ( ! $value ) return 0;
		$date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', (string) $value, wp_timezone() );
		return $date instanceof DateTimeImmutable ? $date->getTimestamp() : 0;
	}
	public static function is_past_event( $value ) {
		$timestamp = self::date_timestamp( $value );
		if ( $timestamp <= 0 ) return false;
		$today = ( new DateTimeImmutable( '@' . current_time( 'timestamp', true ) ) )->setTimezone( wp_timezone() )->setTime( 0, 0 );
		return $timestamp < $today->getTimestamp();
	}
	private static function registration_deadline_passed( $value ) {
		$timestamp = self::date_timestamp( $value );
		return $timestamp > 0 && $timestamp < current_time( 'timestamp', true );
	}
	private static function format_utc_date( $value ) {
		if ( ! $value ) return 'Data non disponibile';
		$date = DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', (string) $value, new DateTimeZone( 'UTC' ) );
		return $date instanceof DateTimeImmutable ? wp_date( 'd/m/Y H:i', $date->getTimestamp(), wp_timezone() ) : (string) $value;
	}
	private static function format_money( $cents ) { return number_format( max( 0, (int) $cents ) / 100, 2, ',', '.' ) . ' €'; }
	private static function group_cover_url( $activity_id, $size = 'large' ) {
		$activity_id = absint( $activity_id );
		if ( ! $activity_id ) return '';
		$cover_id = absint( get_post_meta( $activity_id, '_mi_group_cover_image_id', true ) );
		if ( ! $cover_id ) $cover_id = get_post_thumbnail_id( $activity_id );
		if ( $cover_id ) return esc_url( (string) wp_get_attachment_image_url( $cover_id, $size ) );
		$external_cover = esc_url( (string) get_post_meta( $activity_id, '_mi_group_cover_image_url', true ) );
		return $external_cover ?: esc_url( (string) get_post_meta( $activity_id, '_mi_group_logo_url', true ) );
	}
	private static function group_logo_url( $activity_id, $size = 'thumbnail' ) {
		$activity_id = absint( $activity_id );
		if ( ! $activity_id ) return '';
		$logo_id = get_post_thumbnail_id( $activity_id );
		if ( $logo_id ) return esc_url( (string) wp_get_attachment_image_url( $logo_id, $size ) );
		return esc_url( (string) get_post_meta( $activity_id, '_mi_group_logo_url', true ) );
	}
	private static function draft_configuration_complete( $event_id ) {
		$event = get_post( $event_id );
		if ( ! $event || ! trim( (string) $event->post_title ) ) return false;
		if ( ! self::valid_portal_date( (string) get_post_meta( $event_id, '_mi_event_starts_at', true ) ) ) return false;
		if ( ! self::valid_portal_date( (string) get_post_meta( $event_id, '_mi_registration_closes_at', true ) ) ) return false;
		if ( absint( get_post_meta( $event_id, '_mi_capacity', true ) ) < 1 ) return false;
		return true;
	}
	private static function draft_initial_step( $event_id ) {
		// La configurazione copiata richiede la verifica iniziale di titolo, gruppo e date.
		if ( get_post_meta( $event_id, '_mi_duplicate_request', true ) ) return 0;
		$event = get_post( $event_id );
		if ( ! $event || ! trim( (string) $event->post_title ) ) return 0;
		if ( ! self::valid_portal_date( (string) get_post_meta( $event_id, '_mi_event_starts_at', true ) ) || ! self::valid_portal_date( (string) get_post_meta( $event_id, '_mi_registration_closes_at', true ) ) || absint( get_post_meta( $event_id, '_mi_capacity', true ) ) < 1 ) return 3;
		return 7;
	}
	private static function event_outputs_panel( $event_id ) {
		if ( ! $event_id || ! MI_Access::can_access_event( $event_id ) ) return;
		$event = get_post( $event_id );
		$event_title = $event ? trim( (string) $event->post_title ) : '';
		if ( ! $event_title ) $event_title = 'Evento';
		$group_id = absint( get_post_meta( $event_id, '_mi_activity_id', true ) );
		$group_title = $group_id ? trim( (string) get_the_title( $group_id ) ) : '';
		if ( ! $group_title ) $group_title = 'Parrocchia Sant’Eugenio';
		$group_logo_id = $group_id ? get_post_thumbnail_id( $group_id ) : 0;
		$group_logo = $group_logo_id ? (string) wp_get_attachment_image_url( $group_logo_id, 'thumbnail' ) : '';
		if ( ! $group_logo && $group_id ) $group_logo = esc_url( (string) get_post_meta( $group_id, '_mi_group_logo_url', true ) );
		$group_initials = implode( '', array_map( static function ( $word ) { return function_exists( 'mb_substr' ) ? mb_substr( $word, 0, 1 ) : substr( $word, 0, 1 ); }, array_slice( preg_split( '/\s+/', $group_title ) ?: array(), 0, 2 ) ) );
		$ticket_types = get_post_meta( $event_id, '_mi_ticket_types', true );
		if ( ! is_array( $ticket_types ) || empty( $ticket_types ) ) {
			$pricing_mode = (string) get_post_meta( $event_id, '_mi_pricing_mode', true );
			$fixed_price = max( 0, absint( get_post_meta( $event_id, '_mi_fixed_price_cents', true ) ) );
			update_post_meta( $event_id, '_mi_ticket_types', array( array( 'code' => 'standard', 'name' => 'ZERO' === $pricing_mode ? 'Iscrizione' : 'Quota di partecipazione', 'price_cents' => 'FIXED' === $pricing_mode ? $fixed_price : 0, 'max_per_order' => 20, 'capacity' => 0 ) ) );
		}
		$sheet_url = get_post_meta( $event_id, '_mi_operational_sheet_url', true ) ? esc_url( MI_Sheet_Open::url( $event_id ) ) : '';
		$sheet_missing = '1' === get_post_meta( $event_id, '_mi_sheet_missing', true );
		$registration_url = esc_url( (string) get_post_meta( $event_id, '_mi_registration_url', true ) );
		if ( ! $registration_url ) $registration_url = esc_url( MI_Shortcode::url_iscrizione( $event_id ) );
		// Genera il collegamento pubblico anche quando l'evento contiene un URL operativo.
		$balance_url = esc_url( add_query_arg( array( 'mi_status' => 'balance', 'evento' => $event_id ), home_url( '/' ) ) );
		$has_balance = 'DEPOSIT_BALANCE' === get_post_meta( $event_id, '_mi_economic_mode', true );
		$is_published = 'publish' === get_post_status( $event_id );
		$preview_url = wp_nonce_url( admin_url( 'admin-post.php?action=mi_anteprima_evento&event=' . $event_id ), 'mi_anteprima_evento_' . $event_id );
		echo '<section class="mi-event-outputs' . ( $is_published ? ' is-published' : '' ) . '" id="mi-produzioni-evento" tabindex="-1" data-mi-event-outputs>';
		echo '<header class="mi-event-outputs__header"><div class="mi-event-outputs__brand">' . ( $group_logo ? '<img src="' . esc_url( $group_logo ) . '" alt="">' : '<span aria-hidden="true">' . esc_html( strtoupper( $group_initials ?: 'SE' ) ) . '</span>' ) . '<div><small>Gruppo organizzatore</small><strong>' . esc_html( $group_title ) . '</strong></div></div><div class="mi-event-outputs__event"><span class="mi-portal-eyebrow">Passaggio conclusivo</span><h2>' . esc_html( $event_title ) . '</h2></div></header>';
		if ( ! $is_published ) {
			echo '<h3>Controlla e pubblica</h3>';
			echo '<p>Controlla il modulo. L’evento sarà pubblicato e verrà creato il foglio di calcolo per la registrazione delle iscrizioni.</p><ol><li><strong>Visualizza anteprima</strong><span class="mi-preview-action"><a href="' . esc_url( $preview_url ) . '" target="_blank" rel="noopener noreferrer">Apri l’anteprima del modulo di iscrizione <span aria-hidden="true">↗</span></a></span></li><li><strong>Pubblica evento</strong><span>Crea il foglio Google e attiva il modulo di iscrizione.</span></li></ol>';
		}
		if ( ! $is_published && ( current_user_can( 'mi_publish_events' ) || current_user_can( 'manage_options' ) ) ) {
			echo '<div class="mi-event-outputs__actions"><form method="post"><input type="hidden" name="mi_portal_action" value="publish_event_portal"><input type="hidden" name="event_id" value="' . esc_attr( $event_id ) . '">';
			wp_nonce_field( 'mi_portal_publish_event_' . $event_id, 'mi_portal_nonce' );
			echo '<button class="mi-primary" type="submit">Pubblica evento</button><span class="mi-action-progress" role="status" aria-live="polite" hidden></span></form></div>';
		} elseif ( $is_published ) {
			echo '<div class="mi-event-outputs__success"><span aria-hidden="true">✓</span><div><strong>L’evento è pubblicato</strong><p>Il modulo di iscrizione è pronto. Puoi condividerlo con le persone interessate.</p></div></div>';
			if ( class_exists( 'MI_Event_QR' ) ) MI_Event_QR::render( $event_id );
			echo '<div class="mi-event-outputs__grid"><article class="mi-output-card mi-output-card--public"><span class="mi-output-card__audience">Per i partecipanti</span><h3>Condividi il modulo di iscrizione</h3><label>Link per le iscrizioni<div class="mi-output-copy"><input type="url" readonly value="' . esc_attr( $registration_url ) . '"><button type="button" class="mi-primary" data-mi-copy="' . esc_attr( $registration_url ) . '">Copia link</button></div></label><a class="mi-secondary mi-output-link" href="' . $registration_url . '" target="_blank" rel="noopener noreferrer">Apri il modulo <span aria-hidden="true">↗</span></a></article>';
			echo '<article class="mi-output-card mi-output-card--internal"><span class="mi-output-card__audience">Per gli operatori</span><h3>Gestisci le iscrizioni</h3><p>Consulta e aggiorna i dati nel foglio Google dell’evento.</p><div class="mi-output-document"><span aria-hidden="true">▦</span><div><strong>Foglio iscrizioni</strong><small>' . esc_html( $event_title ) . '</small></div></div>' . ( $sheet_missing ? '<p class="mi-portal-notice mi-portal-error"><strong>Foglio non disponibile.</strong> Usa il comando qui sotto per ricrearlo dai dati conservati.</p>' : ( $sheet_url ? '<a class="mi-secondary mi-output-link" href="' . $sheet_url . '" target="_blank" rel="noopener noreferrer">Apri <span aria-hidden="true">↗</span></a><div class="mi-output-copy-action"><button type="button" class="mi-secondary mi-output-link" data-mi-copy="' . esc_attr( $sheet_url ) . '" data-mi-copy-success-label="Copiato">Copia il collegamento al foglio</button></div>' : '<p class="mi-portal-muted">Collegamento al foglio non ancora disponibile.</p>' ) );
			echo '<form method="post" class="mi-output-sheet-check"><input type="hidden" name="mi_portal_action" value="repair_event_sheet"><input type="hidden" name="event_id" value="' . esc_attr( $event_id ) . '">';
			wp_nonce_field( 'mi_portal_repair_event_sheet_' . $event_id, 'mi_portal_nonce' );
			echo '<button type="submit" class="mi-secondary mi-output-link">Verifica o ricrea il foglio Google</button></form></article></div>';
			if ( $has_balance ) echo '<div class="mi-output-balance"><h3>Controllo stato e saldo</h3>' . ( $balance_url ? '<a class="mi-secondary mi-output-link" href="' . $balance_url . '" target="_blank" rel="noopener noreferrer">Apri la pagina stato e saldo <span aria-hidden="true">↗</span></a><label>Collegamento per il pulsante Saldo<div class="mi-output-copy"><input type="url" readonly value="' . esc_attr( $balance_url ) . '"><button type="button" class="mi-secondary" data-mi-copy="' . esc_attr( $balance_url ) . '">Copia</button></div></label>' : '<p>Collegamento non ancora disponibile.</p>' ) . '</div>';
		}
		echo '</section>';
	}
	private static function base_url() {
		$url = ! empty( $_GET['mi_portal'] ) ? add_query_arg( 'mi_portal', '1', home_url( '/' ) ) : get_permalink();
		return class_exists( 'MI_Portal_PWA' ) ? MI_Portal_PWA::with_group_url( $url ) : $url;
	}
	private static function notice() {
		if ( empty( $_GET['mi_portal_message'] ) ) return;
		$error = ! empty( $_GET['mi_portal_error'] );
		$event_id = absint( $_GET['mi_portal_event'] ?? 0 );
		// Il pannello conclusivo contiene già stato e collegamenti dell'evento:
			// evitiamo di duplicare il riepilogo di pubblicazione nel riquadro sottostante.
		if ( ! $error && $event_id && ! empty( $_GET['mi_portal_outputs'] ) && 'publish' === get_post_status( $event_id ) ) return;
		echo '<div class="mi-portal-notice ' . ( $error ? 'mi-portal-error' : 'mi-portal-success' ) . '"><strong>' . esc_html( sanitize_text_field( wp_unslash( $_GET['mi_portal_message'] ) ) ) . '</strong>';
		if ( ! $error && $event_id && MI_Access::can_access_event( $event_id ) ) {
			// La bozza appartiene al percorso guidato della Segreteria: riprendiamo
			// lo stesso evento senza passare dall'editor interno di WordPress.
			$is_published = 'publish' === get_post_status( $event_id );
			if ( $is_published ) echo '<p>L’evento è pubblicato.</p>';
		}
		echo '</div>';
	}
}
