<?php

defined( 'ABSPATH' ) || exit;

final class MI_Workspace_Settings {
	public static function boot() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_mi_save_workspace', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mi_test_workspace', array( __CLASS__, 'test_connection' ) );
		add_action( 'admin_post_mi_test_workspace_schema', array( __CLASS__, 'test_schema' ) );
	}

	public static function menu() {
		add_submenu_page(
			'edit.php?post_type=' . MI_Event_Post_Type::EVENT_TYPE,
			'Collegamento Workspace',
			'Collegamento Workspace',
			'manage_options',
			'mi-workspace',
			array( __CLASS__, 'page' )
		);
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Accesso non consentito.', 'modulo-iscrizioni' ) );
		}
		$url = (string) get_option( 'mi_workspace_webapp_url', '' );
		$configured = MI_Workspace_Client::is_configured();
		$notice = isset( $_GET['mi_esito'] ) ? sanitize_key( wp_unslash( $_GET['mi_esito'] ) ) : '';
		$error_code = isset( $_GET['mi_codice'] ) ? sanitize_key( wp_unslash( $_GET['mi_codice'] ) ) : '';
		?>
		<div class="wrap">
			<h1>Collegamento Google Workspace</h1>
			<details><summary>Diagnostica aggiornamenti automatici</summary>
			<p>Avvio WordPress tramite visite: <strong><?php echo defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ? 'Disabilitato; il cron deve essere avviato da un servizio esterno, come l’attivatore Google configurato.' : 'Abilitato'; ?></strong></p>
			<p>Prossima elaborazione coda: <strong><?php $next = wp_next_scheduled( 'mi_sync_workspace_pending' ); echo esc_html( $next ? wp_date( 'd/m/Y H:i:s', $next ) : 'Non programmata' ); ?></strong></p>
			<p>Blocco cron: <strong><?php $cron_lock = get_transient( 'doing_cron' ); echo esc_html( $cron_lock ? max( 0, time() - (int) $cron_lock ) . ' secondi fa' : 'Libero' ); ?></strong></p>
			</details>
			<?php if ( 'salvato' === $notice ) : ?><div class="notice notice-success"><p>Configurazione salvata.</p></div><?php endif; ?>
			<?php if ( 'ping_ok' === $notice ) : ?><div class="notice notice-success"><p>Collegamento firmato verificato. Workspace è in modalità ANTEPRIMA.</p></div><?php endif; ?>
			<?php if ( 'ping_errore' === $notice ) : ?><div class="notice notice-error"><p>Collegamento non riuscito. Codice diagnostico: <code><?php echo esc_html( $error_code ?: 'non_disponibile' ); ?></code>.</p></div><?php endif; ?>
			<?php if ( 'schema_ok' === $notice ) : ?><div class="notice notice-success"><p>Progetto Apps Script autonomo verificato: proiezione diretta disponibile.</p></div><?php endif; ?>
			<?php if ( 'schema_errore' === $notice ) : ?><div class="notice notice-error"><p>La distribuzione non conferma il progetto Apps Script autonomo e il prelievo firmato delle proiezioni. Verifica l’URL e lo stato della configurazione.</p></div><?php endif; ?>
			<p>Il segreto salvato non viene mai mostrato. Inseriscilo nuovamente soltanto per sostituirlo.</p>
			<p><strong>URL per la procedura guidata Sheets:</strong><br><code><?php echo esc_html( rest_url( MI_REST_Controller::NAMESPACE . '/workspace/commands' ) ); ?></code></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="mi_save_workspace">
				<?php wp_nonce_field( 'mi_save_workspace' ); ?>
				<table class="form-table"><tbody>
				<tr><th scope="row"><label for="mi_workspace_webapp_url">URL Web App</label></th><td><input class="regular-text code" type="url" id="mi_workspace_webapp_url" name="mi_workspace_webapp_url" value="<?php echo esc_attr( $url ); ?>" required autocomplete="off"></td></tr>
				<tr><th scope="row"><label for="mi_workspace_shared_secret">Nuovo segreto condiviso</label></th><td><input class="regular-text" type="password" id="mi_workspace_shared_secret" name="mi_workspace_shared_secret" value="" minlength="32" autocomplete="new-password"><p class="description"><?php echo $configured ? 'Un segreto è già configurato.' : 'Configura un segreto casuale di almeno 32 caratteri.'; ?></p></td></tr>
				<tr><th scope="row"><label for="mi_email_segreteria_eventi">Email segreteria eventi</label></th><td><input class="regular-text" type="email" id="mi_email_segreteria_eventi" name="mi_email_segreteria_eventi" value="<?php echo esc_attr( get_option( 'mi_email_segreteria_eventi', get_option( 'admin_email', '' ) ) ); ?>"><p class="description">Riceve sempre gli avvisi interni di pubblicazione, annullamento ed eliminazione dell’evento. Li ricevono anche il contatto del gruppo e l’operatore assegnato, se presente; gli indirizzi coincidenti ricevono una sola email. Non modifica il mittente del sito né i permessi Google.</p></td></tr>
				</tbody></table>
				<?php submit_button( 'Salva configurazione' ); ?>
			</form>
			<?php if ( $configured ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="mi_test_workspace">
				<?php wp_nonce_field( 'mi_test_workspace' ); ?>
				<?php submit_button( 'Verifica collegamento firmato', 'secondary' ); ?>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="mi_test_workspace_schema">
				<?php wp_nonce_field( 'mi_test_workspace_schema' ); ?>
				<?php submit_button( 'Verifica proiezione diretta', 'secondary' ); ?>
			</form>
			<?php endif; ?>
		</div>
		<?php
	}

	public static function save() {
		self::authorize( 'mi_save_workspace' );
		$email_segreteria = sanitize_email( wp_unslash( $_POST['mi_email_segreteria_eventi'] ?? '' ) );
		if ( ! empty( $_POST['mi_email_segreteria_eventi'] ) && ! is_email( $email_segreteria ) ) wp_die( 'Email della segreteria non valida.' );
		$url = esc_url_raw( wp_unslash( $_POST['mi_workspace_webapp_url'] ?? '' ) );
		if ( ! preg_match( '#^https://script\.google\.com/macros/s/[A-Za-z0-9_-]+/exec$#', $url ) ) {
			wp_die( esc_html__( 'URL Web App non valido.', 'modulo-iscrizioni' ) );
		}
		update_option( 'mi_workspace_webapp_url', $url, false );
		update_option( 'mi_email_segreteria_eventi', $email_segreteria, false );
		$secret = (string) wp_unslash( $_POST['mi_workspace_shared_secret'] ?? '' );
		if ( '' !== $secret ) {
			if ( strlen( $secret ) < 32 || strlen( $secret ) > 200 ) {
				wp_die( esc_html__( 'Il segreto deve contenere da 32 a 200 caratteri.', 'modulo-iscrizioni' ) );
			}
			update_option( 'mi_workspace_shared_secret', $secret, false );
		}
		wp_safe_redirect( self::page_url( 'salvato' ) );
		exit;
	}

	public static function test_connection() {
		self::authorize( 'mi_test_workspace' );
		$result = MI_Workspace_Client::ping();
		$url = self::page_url( is_wp_error( $result ) ? 'ping_errore' : 'ping_ok' );
		if ( is_wp_error( $result ) ) $url = add_query_arg( 'mi_codice', sanitize_key( $result->get_error_code() ), $url );
		wp_safe_redirect( $url );
		exit;
	}

	public static function test_schema() {
		self::authorize( 'mi_test_workspace_schema' );
		$result = MI_Workspace_Client::stato_schema();
		$valid = self::supports_direct_projection( $result );
		wp_safe_redirect( self::page_url( $valid ? 'schema_ok' : 'schema_errore' ) );
		exit;
	}

	private static function supports_direct_projection( $result ) {
		return ! is_wp_error( $result ) && is_array( $result ) && ! empty( $result['direct_projection'] ) && ! empty( $result['standalone'] ) && ! empty( $result['projection_pull'] ) && isset( $result['central_workbook'] ) && false === $result['central_workbook'];
	}

	private static function authorize( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Accesso non consentito.', 'modulo-iscrizioni' ) );
		check_admin_referer( $action );
	}

	private static function page_url( $result ) {
		return add_query_arg( array( 'post_type' => MI_Event_Post_Type::EVENT_TYPE, 'page' => 'mi-workspace', 'mi_esito' => $result ), admin_url( 'edit.php' ) );
	}
}
