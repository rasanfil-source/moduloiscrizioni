<?php
/**
 * Plugin Name: Modulo Iscrizioni
 * Description: Gestione essenziale di gruppi, eventi, capienza e iscrizioni.
 * Version: 3.26.243
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Author: HappyDuck
 * Text Domain: modulo-iscrizioni
 */

defined( 'ABSPATH' ) || exit;

define( 'MI_VERSION', '3.26.243' );
define( 'MI_PLUGIN_FILE', __FILE__ );
define( 'MI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'MI_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once MI_PLUGIN_DIR . 'includes/class-mi-assets.php';
add_filter( 'script_loader_src', array( 'MI_Assets', 'filter_url' ) );
add_filter( 'style_loader_src', array( 'MI_Assets', 'filter_url' ) );

require_once MI_PLUGIN_DIR . 'includes/class-mi-activator.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-field-schema.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-extra-services.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-event-post-type.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-event-activity-migration.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-access.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-admin.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-modello-email.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-code-image.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-event-qr.php';
MI_Event_QR::boot();
require_once MI_PLUGIN_DIR . 'includes/class-mi-spedizione-email.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-booking-update-email.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-workspace-client.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-workspace-settings.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-registration-service.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-event-projection.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-event-read-cache.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-rest-controller.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-shortcode.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-portal-payments.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-payment-ledger.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-portal.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-portal-pwa.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-public-balance.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-event-duplicator.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-event-deletion.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-portal-management.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-sheet-open.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-management-service.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-management-list.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-attendance-report.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-site-performance.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-integrazione-divi.php';
require_once MI_PLUGIN_DIR . 'includes/class-mi-plugin.php';

register_activation_hook( __FILE__, array( 'MI_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'MI_Activator', 'deactivate' ) );

MI_Plugin::instance()->boot();
add_action( 'template_redirect', array( 'MI_Public_Balance', 'route' ), -110 );
